﻿using OfficeOpenXml;
using OfficeOpenXml.Style;
using System.Windows.Forms;
using System.IO;
using System.Drawing;
using shershulya22.Models;

namespace shershulya22
{
    public class ExcelHelper
    {
        public static void Create(List<TransferHistory> history)
        {
            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;

            using (var package = new ExcelPackage())
            {
                ExcelWorksheet worksheet = package.Workbook.Worksheets.Add("История переводов");

                // Устанавливаем шрифт для ВСЕГО листа
                worksheet.Cells.Style.Font.Name = "Century Gothic";
                worksheet.Cells.Style.Font.Size = 11;

                // Заголовки
                int row = 1;
                worksheet.Cells[row, 1].Value = "Дата перевода";
                worksheet.Cells[row, 2].Value = "Перевод со счета";
                worksheet.Cells[row, 3].Value = "Перевод на счет";
                worksheet.Cells[row, 4].Value = "Сумма";
                worksheet.Cells[row, 5].Value = "Комментарий";

                // Форматирование заголовков
                using (var range = worksheet.Cells[row, 1, row, 5])
                {
                    range.Style.Font.Bold = true;
                    range.Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
                    range.Style.VerticalAlignment = ExcelVerticalAlignment.Center;
                }

                row++;

                // Данные
                foreach (var product in history)
                {
                    worksheet.Cells[row, 1].Value = product.Date.ToString("dd.MM.yyyy");
                    worksheet.Cells[row, 2].Value = product.FromAccount;
                    worksheet.Cells[row, 3].Value = product.ToAccount;
                    worksheet.Cells[row, 4].Value = product.Amount;
                    worksheet.Cells[row, 5].Value = product.Description;
                    row++;
                }

                // Убедимся, что ВСЕ ячейки имеют нужный шрифт
                worksheet.Cells[worksheet.Dimension.Address].Style.Font.Name = "Century Gothic";
                worksheet.Cells[worksheet.Dimension.Address].Style.Font.Size = 11;

                // Границы для всех ячеек с данными
                using (var range = worksheet.Cells[1, 1, row - 1, 5])
                {
                    range.Style.Border.Top.Style = ExcelBorderStyle.Thin;
                    range.Style.Border.Left.Style = ExcelBorderStyle.Thin;
                    range.Style.Border.Right.Style = ExcelBorderStyle.Thin;
                    range.Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                }

                // Автоподбор ширины столбцов
                worksheet.Cells[worksheet.Dimension.Address].AutoFitColumns();

                // Стандартная ширина (если нужно)
                for (int i = 1; i <= 5; i++)
                {
                    if (worksheet.Column(i).Width > 30)
                    {
                        worksheet.Column(i).Width = 20;
                    }
                }

                // Диалог сохранения файла
                SaveFileDialog saveFileDialog = new SaveFileDialog
                {
                    Filter = "Excel files (*.xlsx)|*.xlsx",
                    FileName = "История переводов.xlsx",
                    Title = "Сохранить файл"
                };

                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    FileInfo fileInfo = new FileInfo(saveFileDialog.FileName);
                    package.SaveAs(fileInfo);
                    System.Diagnostics.Process.Start("explorer.exe", $"/select,\"{fileInfo.FullName}\"");
                }
            }
        }

        public static void Create(List<TransactionDTO> transactions)
        {
            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;

            using (var package = new ExcelPackage())
            {
                ExcelWorksheet worksheet = package.Workbook.Worksheets.Add("Транзакции");

                // Устанавливаем шрифт для ВСЕГО листа
                worksheet.Cells.Style.Font.Name = "Century Gothic";
                worksheet.Cells.Style.Font.Size = 11;

                // Заголовки
                int row = 1;
                worksheet.Cells[row, 1].Value = "Дата";
                worksheet.Cells[row, 2].Value = "Категория";
                worksheet.Cells[row, 3].Value = "Счет";
                worksheet.Cells[row, 4].Value = "Сумма";
                worksheet.Cells[row, 5].Value = "Комментарий";

                // Форматирование заголовков
                using (var range = worksheet.Cells[row, 1, row, 5])
                {
                    range.Style.Font.Bold = true;
                    range.Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
                    range.Style.VerticalAlignment = ExcelVerticalAlignment.Center;
                }

                row++;

                // Данные
                foreach (var product in transactions)
                {
                    worksheet.Cells[row, 1].Value = DateTime.Parse(product.Date).ToString("dd.MM.yyyy");
                    worksheet.Cells[row, 2].Value = product.Category;
                    worksheet.Cells[row, 3].Value = product.Account;
                    worksheet.Cells[row, 4].Value = product.Amount;
                    worksheet.Cells[row, 5].Value = product.Comment;
                    row++;
                }

                // Убедимся, что ВСЕ ячейки имеют нужный шрифт
                worksheet.Cells[worksheet.Dimension.Address].Style.Font.Name = "Century Gothic";
                worksheet.Cells[worksheet.Dimension.Address].Style.Font.Size = 11;

                // Границы для всех ячеек с данными
                using (var range = worksheet.Cells[1, 1, row - 1, 5])
                {
                    range.Style.Border.Top.Style = ExcelBorderStyle.Thin;
                    range.Style.Border.Left.Style = ExcelBorderStyle.Thin;
                    range.Style.Border.Right.Style = ExcelBorderStyle.Thin;
                    range.Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                }

                // Автоподбор ширины столбцов
                worksheet.Cells[worksheet.Dimension.Address].AutoFitColumns();

                // Стандартная ширина (если нужно)
                for (int i = 1; i <= 5; i++)
                {
                    if (worksheet.Column(i).Width > 30)
                    {
                        worksheet.Column(i).Width = 20;
                    }
                }

                // Диалог сохранения файла
                SaveFileDialog saveFileDialog = new SaveFileDialog
                {
                    Filter = "Excel files (*.xlsx)|*.xlsx",
                    FileName = "Транзакции.xlsx",
                    Title = "Сохранить файл"
                };

                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    FileInfo fileInfo = new FileInfo(saveFileDialog.FileName);
                    package.SaveAs(fileInfo);
                    System.Diagnostics.Process.Start("explorer.exe", $"/select,\"{fileInfo.FullName}\"");
                }
            }
        }
    }
}