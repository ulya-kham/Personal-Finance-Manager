﻿using System.Configuration;
using System.Net;
using System.Net.Mail;

namespace shershulya22
{
    public class MailHelper
    {
        public static void Send(string to, string messageText)
        {
            string subject = "Личный учет финансов";

            var smtpHost = ConfigurationManager.AppSettings["SMTP_Host"];
            var smtpPort = int.Parse(ConfigurationManager.AppSettings["SMTP_Port"]);
            var email = ConfigurationManager.AppSettings["Email"];
            var appPasword = ConfigurationManager.AppSettings["ApplicationPassword"];


            MailMessage message = new MailMessage(email, to, subject, messageText);
            SmtpClient smtp = new SmtpClient(smtpHost, smtpPort); 

            smtp.Credentials = new NetworkCredential(email, appPasword);
            smtp.EnableSsl = true;

            try
            {
                smtp.Send(message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
    }
}
