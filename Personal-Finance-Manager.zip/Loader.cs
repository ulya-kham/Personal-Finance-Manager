﻿using shershulya22.Repositories;

namespace shershulya22
{
    internal class Loader
    {
        private static Loader? _instance;
        public UserRepository UserRepository { get; private set; }
        public AccountRepository AccountRepository { get; private set; }
        public TransferRepository TransferRepository { get; private set; }
        public CategoryRepository CategoryRepository { get; private set; }
        public RecPaymentRepository RecPaymentRepository { get; private set; }
        public ReminderRepository ReminderRepository { get; private set; }
        public TransactionRepository TransactionRepository { get; private set; }
        public static Loader Instance
        {
            get
            {
                if (_instance == null)
                    _instance = new Loader();
                return _instance;
            }
        }
        public Loader()
        {
            var context = new AppDbContext();
            AccountRepository = new AccountRepository(context);
            UserRepository = new UserRepository(context);
            TransferRepository = new TransferRepository(context);
            CategoryRepository = new CategoryRepository(context);
            RecPaymentRepository = new RecPaymentRepository(context);
            ReminderRepository = new ReminderRepository(context);
            TransactionRepository = new TransactionRepository(context);
        }
    }
}
