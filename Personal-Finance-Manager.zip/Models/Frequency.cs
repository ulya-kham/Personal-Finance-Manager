﻿using System.ComponentModel;

namespace shershulya22.Models
{
    public enum Frequency
    {
        [Description("Каждый день")]
        EveryDay = 1,
        [Description("Каждую неделю")]
        EveryWeek = 2,
        [Description("Каждые две недели")]
        Every2Week = 3,
        [Description("Каждый месяц")]
        EveryMonth = 4,
        [Description("Каждые два месяца")]
        Every2Month = 5,
        [Description("Каждые полгода")]
        Every6Month = 6,
        [Description("Каждый год")]
        EveryYear = 7
    }
}
