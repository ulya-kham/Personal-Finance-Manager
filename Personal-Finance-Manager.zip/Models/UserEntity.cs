﻿using System.ComponentModel.DataAnnotations;

namespace shershulya22.Models
{
    public class UserEntity
    {
        public Guid Id { get; set; } = Guid.NewGuid();
        public string Name { get; set; } = string.Empty;
        [EmailAddress]
        public string Email { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty;

        public virtual ICollection<AccountEntity> Accounts { get; set; }
        public virtual ICollection<CategoryEntity> Categories { get; set; }
        public virtual ICollection<TransactionEntity> Transactions { get; set; }
        public virtual ICollection<TransferEntity> Transfers { get; set; }
        public virtual ICollection<RecurringPaymentEntity> RecurringPayments { get; set; }
        public virtual ICollection<ReminderEntity> Reminders { get; set; }
    }
}
