﻿namespace shershulya22.Models
{
    public class ReminderEntity
    {
        public Guid Id { get; set; } = Guid.NewGuid();
        public Guid UserId { get; set; }
        public string Name { get; set; }
        public Frequency Frequency { get; set; }
        public DateTime StartDate { get; set; }
        public string Comment { get; set; }
        public bool IsOff { get; set; } = false;
        public DateTime? LastExecutionDate { get; set; }

        public virtual UserEntity User { get; set; }
    }
}
