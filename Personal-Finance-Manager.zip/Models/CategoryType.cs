﻿namespace shershulya22.Models
{
    public enum CategoryType
    {
        Minus = 1,
        Plus = 2
    }
}
