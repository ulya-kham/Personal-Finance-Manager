﻿namespace shershulya22.Models
{
    public class CategoryDTO
    {
        public Guid Id { get; set; }
        public string CategoryName { get; set; }
        public decimal? PlannedAmount { get; set; }

        public static CategoryDTO Map(CategoryEntity entity)
        {
            return new CategoryDTO
            {
                Id = entity.Id,
                CategoryName = entity.CategoryName,
                PlannedAmount = entity.PlannedAmount
            };
        }
    }
}
