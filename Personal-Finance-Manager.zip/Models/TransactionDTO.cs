﻿namespace shershulya22.Models
{
    public class TransactionDTO
    {
        public Guid Id { get; set; }
        public string Date { get; set; }
        public string Category { get; set; }
        public string Account { get; set; }
        public decimal Amount { get; set; }
        public string Comment { get; set; }
        public static TransactionDTO Map(TransactionEntity entity)
        {
            return new TransactionDTO
            {
                Id = entity.Id,
                Date = entity.Date.ToString("yyyy-MM-dd"),
                Category = entity.Category.CategoryName,
                Account = entity.Account.Name,
                Amount = entity.Amount,
                Comment = entity.Comment
            };
        }
    }
}
