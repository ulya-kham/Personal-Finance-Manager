﻿namespace shershulya22.Models
{
    public class TransferHistory
    {
        public Guid Id { get; set; }
        public DateTime Date { get; set; }
        public string FromAccount { get; set; }
        public string ToAccount { get; set; }
        public decimal Amount { get; set; }
        public string Description { get; set; } 

        public static TransferHistory Map(TransferEntity entity)
        {
            return new TransferHistory
            {
                Id = entity.Id,
                Date = entity.Date,
                Description = entity.Description,
                Amount = entity.Amount,
                ToAccount = entity.ToAccount.Name,
                FromAccount = entity.FromAccount.Name
            };
        }
    }
}
