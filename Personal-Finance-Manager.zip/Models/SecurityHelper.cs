﻿using System.Security.Cryptography;
using System.Text;

namespace shershulya22.Models
{
    public static class SecurityHelper
    {
        
            public static string HashPassword(string password)
            {
                using (var sha = SHA256.Create())
                {
                    var bytes = Encoding.UTF8.GetBytes(password);
                    var hash = sha.ComputeHash(bytes);
                    return Convert.ToBase64String(hash);
                }
            }

            public static bool VerifyPassword(string inputPassword, string storedHashedPassword)
            {
                var hashedInput = HashPassword(inputPassword);
                return hashedInput == storedHashedPassword;
            }
        public static string GenerateTemporaryPassword(int length = 8)
        {
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
            var random = new Random();
            return new string(Enumerable.Repeat(chars, length)
                .Select(s => s[random.Next(s.Length)]).ToArray());
        }

    }
}
