﻿namespace shershulya22.Models
{
    public class AccountEntity
    {
        public Guid Id { get; set; } = Guid.NewGuid();
        public Guid UserId { get; set; }
        public string Name { get; set; } = string.Empty;
        public decimal Balance { get; set; }
        public bool IsPublic { get; set; } = true;

        public virtual UserEntity User { get; set; }
        public virtual ICollection<TransactionEntity> Transactions { get; set; }
    }
}
