﻿namespace shershulya22.Models
{
    public class TransactionEntity
    {
        public Guid Id { get; set; } = Guid.NewGuid();
        public Guid UserId { get; set; }
        public Guid AccountId { get; set; }
        public Guid CategoryId { get; set; }
        public decimal Amount { get; set; }
        public DateTime Date { get; set; }
        public string Comment { get; set; } = string.Empty;
        public CategoryType Type { get; set; }

        public virtual UserEntity User { get; set; }
        public virtual AccountEntity Account { get; set; }
        public virtual CategoryEntity Category { get; set; }
    }
}
