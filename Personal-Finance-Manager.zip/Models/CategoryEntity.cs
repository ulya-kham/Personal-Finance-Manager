﻿namespace shershulya22.Models
{
    public class CategoryEntity
    {
        public Guid Id { get; set; } = Guid.NewGuid();
        public Guid UserId { get; set; }
        public string CategoryName { get; set; } = string.Empty;
        public CategoryType Type { get; set; }
        public decimal? PlannedAmount { get; set; }

        public virtual UserEntity User { get; set; }
        public virtual ICollection<TransactionEntity> Transactions { get; set; } = new HashSet<TransactionEntity>();
        public virtual ICollection<RecurringPaymentEntity> RecurringPayments { get; set; } = new HashSet<RecurringPaymentEntity>();
    }
}
