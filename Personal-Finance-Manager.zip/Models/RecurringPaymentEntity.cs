﻿namespace shershulya22.Models
{
    public class RecurringPaymentEntity
    {
        public Guid Id { get; set; } = Guid.NewGuid();
        public Guid UserId { get; set; }
        public string Name { get; set; }
        public Guid AccountId { get; set; }
        public Guid CategoryId { get; set; }
        public decimal Amount { get; set; }
        public Frequency Frequency { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public string Comment { get; set; }
        public bool IsOff { get; set; } = false;
        public DateTime? LastExecutionDate { get; set; }

        public virtual UserEntity User { get; set; }
        public virtual AccountEntity Account { get; set; }
        public virtual CategoryEntity Category { get; set; }
    }
}
