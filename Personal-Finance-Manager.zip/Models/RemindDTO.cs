﻿namespace shershulya22.Models
{
    public class RemindDTO
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public bool IsActive { get; set; }

        public static RemindDTO Map(ReminderEntity entity) 
            => new RemindDTO { Id = entity.Id, Name = entity.Name, IsActive = entity.IsOff };
    }
}
