﻿namespace shershulya22.Models
{
    public class TransferEntity
    {
        public Guid Id { get; set; } = Guid.NewGuid();
        public Guid UserId { get; set; }
        public Guid FromAccountId { get; set; }
        public Guid ToAccountId { get; set; }
        public decimal Amount { get; set; }
        public DateTime Date { get; set; }
        public string Description { get; set; } = string.Empty;

        public virtual UserEntity User { get; set; }
        public virtual AccountEntity FromAccount { get; set; }
        public virtual AccountEntity ToAccount { get; set; }
    }
}
