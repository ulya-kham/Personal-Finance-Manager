﻿namespace shershulya22.Models
{
    public class RecPaymentDTO
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public bool IsOff { get; set; }
        public static RecPaymentDTO Map(RecurringPaymentEntity entity) 
            => new RecPaymentDTO { Id = entity.Id, Name = entity.Name, IsOff = entity.IsOff };
    }
}
