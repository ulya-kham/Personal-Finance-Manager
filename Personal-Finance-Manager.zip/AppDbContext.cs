﻿using Microsoft.EntityFrameworkCore;
using shershulya22.Models;
using System.Configuration;

namespace shershulya22
{
    public class AppDbContext : DbContext
    {
        public DbSet<UserEntity> Users => Set<UserEntity>();
        public DbSet<AccountEntity> Accounts => Set<AccountEntity>();
        public DbSet<CategoryEntity> Categories => Set<CategoryEntity>();
        public DbSet<TransactionEntity> Transactions => Set<TransactionEntity>();
        public DbSet<TransferEntity> Transfers => Set<TransferEntity>();
        public DbSet<RecurringPaymentEntity> RecurringPayments => Set<RecurringPaymentEntity>();
        public DbSet<ReminderEntity> Reminders  => Set<ReminderEntity>();
        public AppDbContext()
        {
            Database.EnsureCreated();
        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["MySQLConnectionString"].ConnectionString;
            optionsBuilder.UseMySQL(connectionString);
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Конфигурация User
            modelBuilder.Entity<UserEntity>(entity =>
            {
                entity.HasKey(u => u.Id);

                entity.Property(u => u.Email)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.HasIndex(u => u.Email).IsUnique();

                entity.Property(u => u.Password)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(u => u.Name)
                    .IsRequired()
                    .HasMaxLength(50);
            });

            modelBuilder.Entity<UserEntity>().HasData(
        new UserEntity { Name = "test", Email = "test@example.com", Password = "test" });

            // Конфигурация Account
            modelBuilder.Entity<AccountEntity>(entity =>
            {
                entity.HasKey(a => a.Id);

                entity.Property(a => a.Name)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(a => a.Balance)
                    .IsRequired()
                    .HasColumnType("decimal(15,2)");


                entity.HasOne(a => a.User)
                    .WithMany(u => u.Accounts)
                    .HasForeignKey(a => a.UserId)
                    .OnDelete(DeleteBehavior.Restrict);
            });

            // Конфигурация Category
            modelBuilder.Entity<CategoryEntity>(entity =>
            {
                entity.HasKey(c => c.Id);

                entity.Property(c => c.CategoryName)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(c => c.Type)
                    .IsRequired()
                    .HasMaxLength(10);

                entity.Property(c => c.PlannedAmount)
                    .HasColumnType("decimal(15,2)");

                entity.HasOne(c => c.User)
                    .WithMany(u => u.Categories)
                    .HasForeignKey(c => c.UserId)
                    .OnDelete(DeleteBehavior.Restrict);
            });

            // Конфигурация Transaction
            modelBuilder.Entity<TransactionEntity>(entity =>
            {
                entity.HasKey(t => t.Id);

                entity.Property(t => t.Amount)
                    .IsRequired()
                    .HasColumnType("decimal(15,2)");

                entity.Property(t => t.Date)
                    .IsRequired();

                entity.Property(t => t.Type)
                    .IsRequired()
                    .HasMaxLength(10);

                entity.HasOne(t => t.User)
                    .WithMany(u => u.Transactions)
                    .HasForeignKey(t => t.UserId)
                    .OnDelete(DeleteBehavior.Restrict);

                entity.HasOne(t => t.Account)
                    .WithMany(a => a.Transactions)
                    .HasForeignKey(t => t.AccountId)
                    .OnDelete(DeleteBehavior.Restrict);

                entity.HasOne(t => t.Category)
                    .WithMany(c => c.Transactions)
                    .HasForeignKey(t => t.CategoryId)
                    .OnDelete(DeleteBehavior.Restrict);
            });

            // Конфигурация Transfer
            modelBuilder.Entity<TransferEntity>(entity =>
            {
                entity.HasKey(t => t.Id);

                entity.Property(t => t.Amount)
                    .IsRequired()
                    .HasColumnType("decimal(15,2)");

                entity.Property(t => t.Date)
                    .IsRequired();

                entity.HasOne(t => t.User)
                    .WithMany(u => u.Transfers)
                    .HasForeignKey(t => t.UserId)
                    .OnDelete(DeleteBehavior.Restrict);

                entity.HasOne(t => t.FromAccount)
                    .WithMany()
                    .HasForeignKey(t => t.FromAccountId)
                    .OnDelete(DeleteBehavior.Restrict);

                entity.HasOne(t => t.ToAccount)
                    .WithMany()
                    .HasForeignKey(t => t.ToAccountId)
                    .OnDelete(DeleteBehavior.Restrict);
            });

            // Конфигурация RecurringPayment
            modelBuilder.Entity<RecurringPaymentEntity>(entity =>
            {
                entity.HasKey(r => r.Id);

                entity.Property(r => r.Name)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(r => r.Amount)
                    .IsRequired()
                    .HasColumnType("decimal(15,2)");

                entity.Property(r => r.Frequency)
                    .IsRequired()
                    .HasMaxLength(20);

                entity.Property(r => r.StartDate)
                    .IsRequired();

                entity.Property(r => r.IsOff)
                    .IsRequired()
                    .HasDefaultValue(true);

                entity.HasOne(r => r.User)
                    .WithMany(u => u.RecurringPayments)
                    .HasForeignKey(r => r.UserId)
                    .OnDelete(DeleteBehavior.Restrict);

                entity.HasOne(r => r.Account)
                    .WithMany()
                    .HasForeignKey(r => r.AccountId)
                    .OnDelete(DeleteBehavior.Restrict);

                entity.HasOne(r => r.Category)
                    .WithMany(c => c.RecurringPayments)
                    .HasForeignKey(r => r.CategoryId)
                    .OnDelete(DeleteBehavior.Restrict);
            });

            // Конфигурация Reminder
            modelBuilder.Entity<ReminderEntity>(entity =>
            {
                entity.HasKey(r => r.Id);

                entity.Property(r => r.Name)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(r => r.Frequency)
                    .IsRequired()
                    .HasMaxLength(20);

                entity.Property(r => r.StartDate)
                    .IsRequired();

                entity.Property(r => r.IsOff)
                    .IsRequired()
                    .HasDefaultValue(true);

                entity.HasOne(r => r.User)
                    .WithMany(u => u.Reminders)
                    .HasForeignKey(r => r.UserId)
                    .OnDelete(DeleteBehavior.Restrict);
            });
        }
    }
}
