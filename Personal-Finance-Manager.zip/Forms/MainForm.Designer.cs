﻿namespace shershulya22.Forms
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            LeftPanel = new Panel();
            pictureBox1 = new PictureBox();
            SettingsBtn = new Button();
            RemindrBtn = new Button();
            RecPaymentBtn = new Button();
            CategoryBtn = new Button();
            AccountBtn = new Button();
            MainBtn = new Button();
            label2 = new Label();
            label1 = new Label();
            MainPanel = new Panel();
            LeftPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // LeftPanel
            // 
            LeftPanel.BackColor = Color.FromArgb(255, 242, 204);
            LeftPanel.Controls.Add(pictureBox1);
            LeftPanel.Controls.Add(SettingsBtn);
            LeftPanel.Controls.Add(RemindrBtn);
            LeftPanel.Controls.Add(RecPaymentBtn);
            LeftPanel.Controls.Add(CategoryBtn);
            LeftPanel.Controls.Add(AccountBtn);
            LeftPanel.Controls.Add(MainBtn);
            LeftPanel.Controls.Add(label2);
            LeftPanel.Controls.Add(label1);
            LeftPanel.Dock = DockStyle.Left;
            LeftPanel.Location = new Point(5, 5);
            LeftPanel.Name = "LeftPanel";
            LeftPanel.Padding = new Padding(10, 30, 10, 30);
            LeftPanel.Size = new Size(382, 740);
            LeftPanel.TabIndex = 0;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(38, 426);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(300, 236);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 8;
            pictureBox1.TabStop = false;
            // 
            // SettingsBtn
            // 
            SettingsBtn.Dock = DockStyle.Bottom;
            SettingsBtn.FlatAppearance.BorderSize = 0;
            SettingsBtn.FlatStyle = FlatStyle.Flat;
            SettingsBtn.Font = new Font("Century Gothic", 18F, FontStyle.Regular, GraphicsUnit.Point, 204);
            SettingsBtn.Location = new Point(10, 668);
            SettingsBtn.Name = "SettingsBtn";
            SettingsBtn.Size = new Size(362, 42);
            SettingsBtn.TabIndex = 7;
            SettingsBtn.Text = "Настройки";
            SettingsBtn.UseVisualStyleBackColor = true;
            // 
            // RemindrBtn
            // 
            RemindrBtn.Dock = DockStyle.Top;
            RemindrBtn.FlatAppearance.BorderSize = 0;
            RemindrBtn.FlatStyle = FlatStyle.Flat;
            RemindrBtn.Font = new Font("Century Gothic", 18F);
            RemindrBtn.Location = new Point(10, 366);
            RemindrBtn.Name = "RemindrBtn";
            RemindrBtn.Size = new Size(362, 54);
            RemindrBtn.TabIndex = 6;
            RemindrBtn.Text = "Напоминания";
            RemindrBtn.UseVisualStyleBackColor = true;
            // 
            // RecPaymentBtn
            // 
            RecPaymentBtn.Dock = DockStyle.Top;
            RecPaymentBtn.FlatAppearance.BorderSize = 0;
            RecPaymentBtn.FlatStyle = FlatStyle.Flat;
            RecPaymentBtn.Font = new Font("Century Gothic", 18F);
            RecPaymentBtn.Location = new Point(10, 312);
            RecPaymentBtn.Name = "RecPaymentBtn";
            RecPaymentBtn.Size = new Size(362, 54);
            RecPaymentBtn.TabIndex = 5;
            RecPaymentBtn.Text = "Регулярные платежи";
            RecPaymentBtn.UseVisualStyleBackColor = true;
            // 
            // CategoryBtn
            // 
            CategoryBtn.Dock = DockStyle.Top;
            CategoryBtn.FlatAppearance.BorderSize = 0;
            CategoryBtn.FlatStyle = FlatStyle.Flat;
            CategoryBtn.Font = new Font("Century Gothic", 18F);
            CategoryBtn.Location = new Point(10, 258);
            CategoryBtn.Name = "CategoryBtn";
            CategoryBtn.Size = new Size(362, 54);
            CategoryBtn.TabIndex = 4;
            CategoryBtn.Text = "Категории";
            CategoryBtn.UseVisualStyleBackColor = true;
            // 
            // AccountBtn
            // 
            AccountBtn.BackColor = Color.FromArgb(255, 242, 204);
            AccountBtn.Dock = DockStyle.Top;
            AccountBtn.FlatAppearance.BorderSize = 0;
            AccountBtn.FlatStyle = FlatStyle.Flat;
            AccountBtn.Font = new Font("Century Gothic", 18F);
            AccountBtn.Location = new Point(10, 204);
            AccountBtn.Name = "AccountBtn";
            AccountBtn.Size = new Size(362, 54);
            AccountBtn.TabIndex = 3;
            AccountBtn.Text = "Счета";
            AccountBtn.UseVisualStyleBackColor = false;
            // 
            // MainBtn
            // 
            MainBtn.BackColor = Color.FromArgb(248, 203, 173);
            MainBtn.Dock = DockStyle.Top;
            MainBtn.FlatAppearance.BorderSize = 0;
            MainBtn.FlatStyle = FlatStyle.Flat;
            MainBtn.Font = new Font("Century Gothic", 18F);
            MainBtn.Location = new Point(10, 150);
            MainBtn.Name = "MainBtn";
            MainBtn.Size = new Size(362, 54);
            MainBtn.TabIndex = 2;
            MainBtn.Text = "Главная";
            MainBtn.UseVisualStyleBackColor = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Dock = DockStyle.Top;
            label2.Font = new Font("Century Gothic", 15.75F, FontStyle.Italic, GraphicsUnit.Point, 204);
            label2.Location = new Point(10, 66);
            label2.Name = "label2";
            label2.Padding = new Padding(0, 10, 0, 50);
            label2.Size = new Size(293, 84);
            label2.TabIndex = 1;
            label2.Text = "Текущий баланс: 0,00 руб.";
            label2.Click += label2_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Dock = DockStyle.Top;
            label1.Font = new Font("Century Gothic", 21.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label1.Location = new Point(10, 30);
            label1.Name = "label1";
            label1.Size = new Size(272, 36);
            label1.TabIndex = 0;
            label1.Text = "Имя пользователя";
            // 
            // MainPanel
            // 
            MainPanel.BackColor = Color.White;
            MainPanel.Dock = DockStyle.Fill;
            MainPanel.Location = new Point(387, 5);
            MainPanel.Name = "MainPanel";
            MainPanel.Padding = new Padding(5);
            MainPanel.Size = new Size(882, 740);
            MainPanel.TabIndex = 1;
            // 
            // MainForm
            // 
            AutoScaleMode = AutoScaleMode.None;
            ClientSize = new Size(1274, 750);
            Controls.Add(MainPanel);
            Controls.Add(LeftPanel);
            Font = new Font("Tahoma", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "MainForm";
            Padding = new Padding(5);
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Личный учёт финансов";
            LeftPanel.ResumeLayout(false);
            LeftPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel LeftPanel;
        private Button MainBtn;
        private Label label2;
        private Label label1;
        private Button SettingsBtn;
        private Button RemindrBtn;
        private Button RecPaymentBtn;
        private Button CategoryBtn;
        private Button AccountBtn;
        private Panel MainPanel;
        private PictureBox pictureBox1;
    }
}