﻿using shershulya22.Models;

namespace shershulya22.Forms
{
    public partial class NewbieForm: Form
    {
        public NewbieForm()
        {
            InitializeComponent();
            textBox1.TextChanged += (s, e) => textBox1.Text = textBox1.Text.Replace('.', ',');
            new List<Control> { this, label1 }.ForEach(x =>
            {
                x.MouseDown += (s, a) =>
                {
                    x.Capture = false; Capture = false; Message m = Message.Create(Handle, 0xA1, new IntPtr(2), IntPtr.Zero); base.WndProc(ref m);
                };
            });
            EnterBtn.Click += async (s, e) =>
            {
                var canParse = decimal.TryParse(textBox1.Text, out decimal amount);
                if (!canParse && !string.IsNullOrEmpty(textBox1.Text))
                {
                    MessageBox.Show("Не могу понять сумму!");
                    return;
                }
                if (amount <= 0)
                {
                    MessageBox.Show("Сумма должна быть положительна");
                    return;
                }
                var account = new AccountEntity { UserId = Program.CurrentUser, Name = "Основной", Balance = amount };
                await Loader.Instance.AccountRepository.Add(account);
                new MainForm().Show();
                Hide();
            };
        }
    }
}
