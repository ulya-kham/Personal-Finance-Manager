﻿using shershulya22.Models;
using System.Text;



namespace shershulya22.Forms
{
    public partial class RegForm: Form
    {
        public RegForm()
        {
            InitializeComponent();
            new List<Control> { this, label1 }.ForEach(x =>
            {
                x.MouseDown += (s, a) =>
                {
                    x.Capture = false; Capture = false; Message m = Message.Create(Handle, 0xA1, new IntPtr(2), IntPtr.Zero); base.WndProc(ref m);
                };
            });
            pictureBox1.Click += (s, e) => Close();
            EnterBtn.Click += async (s, e) =>
            {
                if (textBox3.Text != textBox4.Text)
                {
                    MessageBox.Show("Пароли не совпадают");
                    return;
                }
                var userExits = await Loader.Instance.UserRepository.UserExist(textBox1.Text);
                if (userExits)
                {
                    MessageBox.Show("Пользователь с таким Email уже зарегистрирован");
                    return;
                }
                var entity = new UserEntity
                {
                    Email = textBox1.Text,
                    Name = textBox2.Text,
                    Password = SecurityHelper.HashPassword(textBox3.Text)
                };
                var error = await Loader.Instance.UserRepository.Add(entity);
                if (!string.IsNullOrEmpty(error))
                    MessageBox.Show(error);
                else
                {
                    await Loader.Instance.CategoryRepository.AddOnStart(entity.Id);
                    MailHelper.Send(entity.Email, "Вы успешно зарегистрировались в приложении «Личный учет финансов»");
                    Program.CurrentUser = entity.Id;
                    Hide();
                    new NewbieForm().Show();
                }
            };

        }
    }
}
