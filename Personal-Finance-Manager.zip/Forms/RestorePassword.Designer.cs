﻿namespace shershulya22.Forms
{
    partial class RestorePassword
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RestorePassword));
            pictureBox1 = new PictureBox();
            label1 = new Label();
            textBox1 = new TextBox();
            EnterBtn = new Button();
            label2 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(12, 12);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(48, 48);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Century Gothic", 24F, FontStyle.Bold);
            label1.Location = new Point(144, 64);
            label1.Name = "label1";
            label1.Size = new Size(409, 38);
            label1.TabIndex = 1;
            label1.Text = "Восстановление пароля";
            // 
            // textBox1
            // 
            textBox1.Font = new Font("Century Gothic", 18F);
            textBox1.Location = new Point(113, 139);
            textBox1.Name = "textBox1";
            textBox1.PlaceholderText = "Введите электронную почту";
            textBox1.Size = new Size(478, 37);
            textBox1.TabIndex = 2;
            // 
            // EnterBtn
            // 
            EnterBtn.BackColor = Color.DarkSeaGreen;
            EnterBtn.FlatStyle = FlatStyle.Flat;
            EnterBtn.Font = new Font("Century Gothic", 18F);
            EnterBtn.Location = new Point(204, 280);
            EnterBtn.Name = "EnterBtn";
            EnterBtn.Size = new Size(304, 50);
            EnterBtn.TabIndex = 1;
            EnterBtn.Text = "Отправить письмо";
            EnterBtn.UseVisualStyleBackColor = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Century Gothic", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label2.Location = new Point(21, 195);
            label2.Name = "label2";
            label2.Size = new Size(657, 48);
            label2.TabIndex = 3;
            label2.Text = "На вашу почту будет направлено письмо с новым паролем.\r\nИспользуйте его при авторизации в приложении";
            label2.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // RestorePassword
            // 
            AutoScaleMode = AutoScaleMode.None;
            BackColor = Color.FromArgb(226, 240, 217);
            ClientSize = new Size(707, 363);
            Controls.Add(label2);
            Controls.Add(EnterBtn);
            Controls.Add(textBox1);
            Controls.Add(label1);
            Controls.Add(pictureBox1);
            Font = new Font("Century Gothic", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "RestorePassword";
            StartPosition = FormStartPosition.CenterParent;
            Text = "Восстановление пароля";
            Load += RestorePassword_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private Label label1;
        private TextBox textBox1;
        private Button EnterBtn;
        private Label label2;
    }
}