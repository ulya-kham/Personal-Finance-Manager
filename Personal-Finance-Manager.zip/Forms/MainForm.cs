﻿using Microsoft.EntityFrameworkCore;
using shershulya22.Controls;
using shershulya22.Models;

namespace shershulya22.Forms
{
    public partial class MainForm : Form
    {
        private string _currentEmail;
        public MainForm()
        {
            InitializeComponent();
            SetActionForButtons();

            new List<Control> { this, LeftPanel, label1, label2, MainPanel }.ForEach(x =>
            {
                x.MouseDown += (s, a) =>
                {
                    x.Capture = false; Capture = false; Message m = Message.Create(Handle, 0xA1, new IntPtr(2), IntPtr.Zero); base.WndProc(ref m);
                };
            });

            Load += async (s, e) =>
            {
                using (var dbContext = new AppDbContext())
                {
                    var user = await dbContext.Users.AsNoTracking().FirstOrDefaultAsync(x => x.Id == Program.CurrentUser);
                    _currentEmail = user.Email;
                    label1.Text = user.Name;
                }
                await CheckAndCreatePaymentsAsync();
                await CheckAndSendRemindersAsync();
                GlobalEvents.RecalculateBalance(s);
                OpenPage<MainControl>();
            };
            GlobalEvents.OnBalanceChanged += GlobalEvents_OnBalanceChanged;
            GlobalEvents.OnNeedBalanceRecalculate += GlobalEvents_OnNeedBalanceRecalculate;
            GlobalEvents.OnNameChanged += GlobalEvents_OnNameChanged;
            GlobalEvents.OnTansactionControlNeedShow += (s, e) => OpenPage<TransactionControl>(e.Type, e.Period, e.Start, e.End, e.IsPeriod);

            GlobalEvents.OnMainControlNeedShow += (s, e) => OpenPage<MainControl>();
            GlobalEvents.OnMinusAddControlNeedShow += (s, e) => OpenPage<AddMinus>();
            GlobalEvents.OnPlusAddControlNeedShow += (s, e) => OpenPage<AddPlus>();

            GlobalEvents.OnAccountControlNeedShow += (s, e) => OpenPage<AccountControl>();
            GlobalEvents.OnAccountEditControlNeedShow += (s, e) => OpenPage<AddAccount>(e.Id);
            GlobalEvents.OnAccountAddControlNeedShow += (s, e) => OpenPage<AddAccount>();
            GlobalEvents.OnTransferAddControlNeedShow += (s, e) => OpenPage<AddTransfer>();
            GlobalEvents.OnHistoryControlNeedShow += (s, e) => OpenPage<Controls.TransferHistory>();

            GlobalEvents.OnCategoryControlNeedShow += (s, e) => OpenPage<CategoryControl>();
            GlobalEvents.OnCategoryEditControlNeedShow += (s, e) => OpenPage<AddCategory>(e.Id);
            GlobalEvents.OnCategoryAddControlNeedShow += (s, e) => OpenPage<AddCategory>();

            GlobalEvents.OnRecPaymentControlNeedShow += (s, e) => OpenPage<RecPaymentControl>();
            GlobalEvents.OnRecPaymentEditControlNeedShow += (s, e) => OpenPage<CreateRecurringPayment>(e.Id);
            GlobalEvents.OnRecPaymentAddControlNeedShow += (s, e) => OpenPage<CreateRecurringPayment>();

            GlobalEvents.OnReminderControlNeedShow += (s, e) => OpenPage<ReminderControl>();
            GlobalEvents.OnReminderEditControlNeedShow += (s, e) => OpenPage<CreateReminder>(e.Id);
            GlobalEvents.OnReminderAddControlNeedShow += (s, e) => OpenPage<CreateReminder>();

        }

        private async void GlobalEvents_OnNameChanged(object? sender, EventArgs e)
        {
            using (var dbContext = new AppDbContext())
            {
                var user = await dbContext.Users.AsNoTracking().FirstOrDefaultAsync(x => x.Id == Program.CurrentUser);
                label1.Text = user.Name;
            }
        }

        private async void GlobalEvents_OnNeedBalanceRecalculate(object? sender, EventArgs e)
        {
            using (var dbContext = new AppDbContext())
            {
                var balance = await dbContext.Accounts
                    .Where(x => x.UserId == Program.CurrentUser && x.IsPublic).AsNoTracking()
                    .SumAsync(x => x.Balance);

                label2.Text = $"Текущий баланс: {balance} руб.";
            }
        }

        private async void GlobalEvents_OnBalanceChanged(object? sender, BalanceChangedEventArgs e)
        {
            using (var dbContext = new AppDbContext())
            {
                await dbContext.Accounts
                    .Where(x => x.Id == e.AccountId)
                    .ExecuteUpdateAsync(s => s
                        .SetProperty(p => p.Balance, p => p.Balance + e.Amount));

                GlobalEvents.RecalculateBalance(sender);
            }
        }

        private void SetActionForButtons()
        {
            foreach (var btn in LeftPanel.Controls)
                if (btn.GetType() == typeof(Button))
                    (btn as Button).Click += (s, e) => ChooseButton(s as Button);
        }

        private void ChooseButton(Button button)
        {
            foreach (var btn in LeftPanel.Controls)
            {
                if (btn.GetType() == typeof(Button))
                    (btn as Button).BackColor = Color.FromArgb(255, 242, 204);
            }
            button.BackColor = Color.FromArgb(248, 203, 173);
            MainPanel.Controls.Clear();
            switch (button.Name)
            {
                case "SettingsBtn":
                    OpenPage<SettingsControl>();
                    break;
                case "RemindrBtn":
                    OpenPage<ReminderControl>();
                    break;
                case "RecPaymentBtn":
                    OpenPage<RecPaymentControl>();
                    break;
                case "CategoryBtn":
                    OpenPage<CategoryControl>();
                    break;
                case "AccountBtn":
                    OpenPage<AccountControl>();
                    break;
                case "MainBtn":
                    OpenPage<MainControl>();
                    break;
            }
        }

        private void OpenPage<T>() where T : UserControl, new()
        {
            MainPanel.Controls.Clear();
            var page = new T();
            page.Dock = DockStyle.Fill;
            MainPanel.Controls.Add(page);
        }
        private void OpenPage<T>(Guid id) where T : UserControl
        {
            MainPanel.Controls.Clear();
            var page = (T)Activator.CreateInstance(typeof(T), id);
            page.Dock = DockStyle.Fill;
            MainPanel.Controls.Add(page);
        }
        private void OpenPage<T>(CategoryType type, DatePeriod period, DateTime start, DateTime end, bool isPeriod) where T : UserControl
        {
            MainPanel.Controls.Clear();
            var page = (T)Activator.CreateInstance(typeof(T), type, period, start, end, isPeriod);
            page.Dock = DockStyle.Fill;
            MainPanel.Controls.Add(page);
        }
        public async Task CheckAndSendRemindersAsync()
        {
            using (var dbContext = new AppDbContext())
            {
                var now = DateTime.Now;
                var reminders = await dbContext.Reminders
                    .Where(r => r.UserId == Program.CurrentUser && !r.IsOff)
                    .ToListAsync();

                foreach (var reminder in reminders)
                {
                    var lastExecution = reminder.LastExecutionDate ?? reminder.StartDate;

                    var shouldSend = reminder.Frequency switch
                    {
                        Frequency.EveryDay => (now - lastExecution).TotalDays >= 1,
                        Frequency.EveryWeek => (now - lastExecution).TotalDays >= 7,
                        Frequency.Every2Week => (now - lastExecution).TotalDays >= 14,
                        Frequency.EveryMonth => lastExecution.AddMonths(1) <= now,
                        Frequency.Every2Month => lastExecution.AddMonths(2) <= now,
                        Frequency.Every6Month => lastExecution.AddMonths(6) <= now,
                        Frequency.EveryYear => lastExecution.AddYears(1) <= now,
                        _ => false
                    };

                    if (shouldSend)
                    {
                        MessageBox.Show($"{reminder.Name}: {reminder.Comment}");
                        MailHelper.Send(_currentEmail, $"{reminder.Name}: {reminder.Comment}");
                        reminder.LastExecutionDate = now;
                    }
                }
                await dbContext.SaveChangesAsync();
            }
        }
        public async Task CheckAndCreatePaymentsAsync()
        {
            using (var dbContext = new AppDbContext())
            {
                var now = DateTime.Now;
                var payments = await dbContext.RecurringPayments
                    .Where(r => r.UserId == Program.CurrentUser && !r.IsOff)
                    .ToListAsync();

                foreach (var payment in payments)
                {
                    var lastExecution = payment.LastExecutionDate ?? payment.StartDate;

                    // Проверка по частоте
                    var shouldExecute = payment.Frequency switch
                    {
                        Frequency.EveryDay => (now - lastExecution).TotalDays >= 1,
                        Frequency.EveryWeek => (now - lastExecution).TotalDays >= 7,
                        Frequency.Every2Week => (now - lastExecution).TotalDays >= 14,
                        Frequency.EveryMonth => lastExecution.AddMonths(1) <= now,
                        Frequency.Every2Month => lastExecution.AddMonths(2) <= now,
                        Frequency.Every6Month => lastExecution.AddMonths(6) <= now,
                        Frequency.EveryYear => lastExecution.AddYears(1) <= now,
                        _ => false
                    };

                    var isWithinRange = !payment.EndDate.HasValue || now.Date <= payment.EndDate.Value.Date;

                    if (shouldExecute && isWithinRange)
                    {
                        var transaction = new TransactionEntity
                        {
                            CategoryId = payment.CategoryId,
                            Comment = payment.Comment,
                            Amount = payment.Amount,
                            UserId = payment.UserId,
                            AccountId = payment.AccountId,
                            Type = CategoryType.Minus,
                            Date = now
                        };
                        await Loader.Instance.TransactionRepository.Add(transaction);
                        payment.LastExecutionDate = now;
                    }
                }
                await dbContext.SaveChangesAsync();
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
