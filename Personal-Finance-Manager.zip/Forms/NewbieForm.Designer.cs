﻿namespace shershulya22.Forms
{
    partial class NewbieForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            textBox1 = new TextBox();
            EnterBtn = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Century Gothic", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label1.Location = new Point(16, 53);
            label1.Name = "label1";
            label1.Size = new Size(600, 32);
            label1.TabIndex = 1;
            label1.Text = "Введите текущую сумму на вашем счёте:";
            // 
            // textBox1
            // 
            textBox1.Font = new Font("Century Gothic", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            textBox1.Location = new Point(82, 125);
            textBox1.Name = "textBox1";
            textBox1.PlaceholderText = "0,00";
            textBox1.Size = new Size(478, 33);
            textBox1.TabIndex = 2;
            // 
            // EnterBtn
            // 
            EnterBtn.BackColor = Color.DarkSeaGreen;
            EnterBtn.FlatStyle = FlatStyle.Flat;
            EnterBtn.Font = new Font("Century Gothic", 21.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            EnterBtn.Location = new Point(208, 211);
            EnterBtn.Name = "EnterBtn";
            EnterBtn.Size = new Size(200, 50);
            EnterBtn.TabIndex = 1;
            EnterBtn.Text = "Далее";
            EnterBtn.UseVisualStyleBackColor = false;
            // 
            // NewbieForm
            // 
            AutoScaleMode = AutoScaleMode.None;
            BackColor = Color.FromArgb(226, 240, 217);
            ClientSize = new Size(628, 306);
            Controls.Add(EnterBtn);
            Controls.Add(textBox1);
            Controls.Add(label1);
            Font = new Font("Tahoma", 12F, FontStyle.Regular, GraphicsUnit.Point, 204);
            FormBorderStyle = FormBorderStyle.None;
            Name = "NewbieForm";
            StartPosition = FormStartPosition.CenterParent;
            Text = "RegForm";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label label1;
        private TextBox textBox1;
        private Button EnterBtn;
    }
}