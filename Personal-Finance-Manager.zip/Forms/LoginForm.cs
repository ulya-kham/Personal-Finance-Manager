﻿using System.Configuration;

namespace shershulya22.Forms
{
    public partial class LoginForm: Form
    {
        private bool _usePasswordChar;
        public LoginForm()
        {
            InitializeComponent();
            new List<Control> { this, label1, label2}.ForEach(x =>
            {
                x.MouseDown += (s, a) =>
                {
                    x.Capture = false; Capture = false; Message m = Message.Create(Handle, 0xA1, new IntPtr(2), IntPtr.Zero); base.WndProc(ref m);
                };
            });
            Load += (s, e) =>
            {
                bool saveLastLogin = bool.Parse(ConfigurationManager.AppSettings["SaveLastLogin"]);
                if (saveLastLogin) 
                {
                    textBox1.Text = ConfigurationManager.AppSettings["LastLogin"];
                }
            };
            pictureBox1.Click += (s, e) => textBox2.UseSystemPasswordChar = _usePasswordChar = !_usePasswordChar;
            CloseButton.Click += (s, e) => Close();
            EnterBtn.Click += async (s, e) =>
            {
                if (string.IsNullOrEmpty(textBox1.Text) || string.IsNullOrEmpty(textBox2.Text))
                {
                    MessageBox.Show("Заполните поля логин и пароль");
                    return;
                }
                var userExist = await Loader.Instance.UserRepository.UserExist(textBox1.Text);
                if (!userExist)
                {
                    MessageBox.Show("Пользователь не найден!");
                    return;
                }
                var user = await Loader.Instance.UserRepository.Auth(textBox1.Text, textBox2.Text);
                if (user == null)
                {
                    MessageBox.Show("Неверный пароль!");
                    return;
                }

                Program.CurrentUser = user.Id;

                Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
                config.AppSettings.Settings["SaveLastLogin"].Value = checkBox1.Checked.ToString().ToLower();
                config.AppSettings.Settings["LastLogin"].Value = textBox1.Text;
                config.Save(ConfigurationSaveMode.Modified);
                ConfigurationManager.RefreshSection("appSettings");

                //Enter
                Hide();
                new MainForm().Show();
            };
            RegLink.Click += (s, e) => new RegForm().ShowDialog();
            linkLabel1.Click += (s, e) => new RestorePassword().ShowDialog();
        }
    }
}
