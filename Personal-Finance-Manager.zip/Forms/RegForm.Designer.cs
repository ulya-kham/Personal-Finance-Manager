﻿namespace shershulya22.Forms
{
    partial class RegForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RegForm));
            pictureBox1 = new PictureBox();
            label1 = new Label();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            textBox3 = new TextBox();
            textBox4 = new TextBox();
            EnterBtn = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(12, 12);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(48, 48);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Century Gothic", 24F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label1.Location = new Point(192, 49);
            label1.Name = "label1";
            label1.Size = new Size(224, 38);
            label1.TabIndex = 1;
            label1.Text = "Регистрация";
            // 
            // textBox1
            // 
            textBox1.Font = new Font("Century Gothic", 18F);
            textBox1.Location = new Point(33, 131);
            textBox1.Name = "textBox1";
            textBox1.PlaceholderText = "Введите электронную почту";
            textBox1.Size = new Size(543, 37);
            textBox1.TabIndex = 2;
            // 
            // textBox2
            // 
            textBox2.Font = new Font("Century Gothic", 18F);
            textBox2.Location = new Point(33, 183);
            textBox2.Name = "textBox2";
            textBox2.PlaceholderText = "Введите ваше имя";
            textBox2.Size = new Size(543, 37);
            textBox2.TabIndex = 3;
            // 
            // textBox3
            // 
            textBox3.Font = new Font("Century Gothic", 18F);
            textBox3.Location = new Point(33, 235);
            textBox3.Name = "textBox3";
            textBox3.PlaceholderText = "Придумайте пароль";
            textBox3.Size = new Size(543, 37);
            textBox3.TabIndex = 4;
            textBox3.UseSystemPasswordChar = true;
            // 
            // textBox4
            // 
            textBox4.Font = new Font("Century Gothic", 18F);
            textBox4.Location = new Point(33, 287);
            textBox4.Name = "textBox4";
            textBox4.PlaceholderText = "Повторите пароль";
            textBox4.Size = new Size(543, 37);
            textBox4.TabIndex = 5;
            textBox4.UseSystemPasswordChar = true;
            // 
            // EnterBtn
            // 
            EnterBtn.BackColor = Color.DarkSeaGreen;
            EnterBtn.FlatStyle = FlatStyle.Flat;
            EnterBtn.Font = new Font("Century Gothic", 18F, FontStyle.Regular, GraphicsUnit.Point, 204);
            EnterBtn.Location = new Point(304, 371);
            EnterBtn.Name = "EnterBtn";
            EnterBtn.Size = new Size(272, 50);
            EnterBtn.TabIndex = 1;
            EnterBtn.Text = "Зарегистрироваться";
            EnterBtn.UseVisualStyleBackColor = false;
            // 
            // RegForm
            // 
            AutoScaleMode = AutoScaleMode.None;
            BackColor = Color.FromArgb(226, 240, 217);
            ClientSize = new Size(611, 464);
            Controls.Add(EnterBtn);
            Controls.Add(textBox4);
            Controls.Add(textBox3);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(label1);
            Controls.Add(pictureBox1);
            Font = new Font("Century Gothic", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "RegForm";
            StartPosition = FormStartPosition.CenterParent;
            Text = "Регистрация";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private Label label1;
        private TextBox textBox1;
        private TextBox textBox2;
        private TextBox textBox3;
        private TextBox textBox4;
        private Button EnterBtn;
    }
}