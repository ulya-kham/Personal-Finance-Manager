﻿namespace shershulya22.Forms
{
    public partial class RestorePassword : Form
    {
        public RestorePassword()
        {
            InitializeComponent();
            new List<Control> { this, label1 }.ForEach(x =>
            {
                x.MouseDown += (s, a) =>
                {
                    x.Capture = false; Capture = false;
                    Message m = Message.Create(Handle, 0xA1, new IntPtr(2), IntPtr.Zero);
                    base.WndProc(ref m);
                };
            });

            // Закрытие
            pictureBox1.Click += (s, e) => Close();

            // Восстановление пароля
            EnterBtn.Click += async (s, e) =>
            {
                var email = textBox1.Text.Trim();
                if (string.IsNullOrEmpty(email))
                {
                    MessageBox.Show("Введите email");
                    return;
                }

                var exist = await Loader.Instance.UserRepository.UserExist(email);
                if (!exist)
                {
                    MessageBox.Show("Пользователь с указанной почтой не существует!");
                    return;
                }

                var result = await Loader.Instance.UserRepository.ResetPassword(email);
                if (result != null)
                {
                    MessageBox.Show("Ошибка при восстановлении пароля: " + result);
                }
                else
                {
                    MessageBox.Show("Временный пароль отправлен на почту.\nПожалуйста, проверьте почтовый ящик.");
                    Close();
                }
            };
        

        }

        private void RestorePassword_Load(object sender, EventArgs e)
        {

        }
    }
}
