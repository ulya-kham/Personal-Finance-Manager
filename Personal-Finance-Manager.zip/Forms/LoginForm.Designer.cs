﻿namespace shershulya22.Forms
{
    partial class LoginForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LoginForm));
            label1 = new Label();
            label2 = new Label();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            EnterBtn = new Button();
            pictureBox1 = new PictureBox();
            checkBox1 = new CheckBox();
            linkLabel1 = new LinkLabel();
            RegLink = new LinkLabel();
            CloseButton = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Century Gothic", 26.25F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label1.Location = new Point(112, 53);
            label1.Name = "label1";
            label1.Size = new Size(847, 41);
            label1.TabIndex = 0;
            label1.Text = "Добро пожаловать в «Личный учёт финансов»";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Century Gothic", 24F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label2.Location = new Point(202, 126);
            label2.Name = "label2";
            label2.Size = new Size(677, 39);
            label2.TabIndex = 1;
            label2.Text = "Для авторизации введите логин и пароль";
            // 
            // textBox1
            // 
            textBox1.BackColor = Color.White;
            textBox1.Font = new Font("Century Gothic", 20.25F);
            textBox1.Location = new Point(205, 223);
            textBox1.Name = "textBox1";
            textBox1.PlaceholderText = "Логин";
            textBox1.Size = new Size(674, 41);
            textBox1.TabIndex = 2;
            // 
            // textBox2
            // 
            textBox2.BackColor = Color.White;
            textBox2.Font = new Font("Century Gothic", 20.25F);
            textBox2.Location = new Point(205, 310);
            textBox2.Name = "textBox2";
            textBox2.PlaceholderText = "Пароль";
            textBox2.Size = new Size(674, 41);
            textBox2.TabIndex = 3;
            textBox2.UseSystemPasswordChar = true;
            // 
            // EnterBtn
            // 
            EnterBtn.BackColor = Color.FromArgb(226, 240, 217);
            EnterBtn.FlatStyle = FlatStyle.Flat;
            EnterBtn.Font = new Font("Century Gothic", 26.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            EnterBtn.ForeColor = Color.Black;
            EnterBtn.Location = new Point(429, 427);
            EnterBtn.Name = "EnterBtn";
            EnterBtn.Size = new Size(237, 60);
            EnterBtn.TabIndex = 1;
            EnterBtn.Text = "Войти";
            EnterBtn.UseVisualStyleBackColor = false;
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.FromArgb(255, 242, 204);
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(904, 310);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(55, 41);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 5;
            pictureBox1.TabStop = false;
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.Checked = true;
            checkBox1.CheckState = CheckState.Checked;
            checkBox1.Font = new Font("Century Gothic", 18F, FontStyle.Regular, GraphicsUnit.Point, 204);
            checkBox1.Location = new Point(643, 357);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(236, 34);
            checkBox1.TabIndex = 6;
            checkBox1.Text = "Запомнить логин";
            checkBox1.UseVisualStyleBackColor = true;
            // 
            // linkLabel1
            // 
            linkLabel1.ActiveLinkColor = Color.Black;
            linkLabel1.AutoSize = true;
            linkLabel1.Font = new Font("Century Gothic", 18F);
            linkLabel1.LinkColor = Color.Black;
            linkLabel1.Location = new Point(852, 482);
            linkLabel1.Name = "linkLabel1";
            linkLabel1.Size = new Size(210, 30);
            linkLabel1.TabIndex = 7;
            linkLabel1.TabStop = true;
            linkLabel1.Text = "Забыли пароль?";
            linkLabel1.VisitedLinkColor = Color.Black;
            // 
            // RegLink
            // 
            RegLink.ActiveLinkColor = Color.Black;
            RegLink.AutoSize = true;
            RegLink.Font = new Font("Century Gothic", 18F);
            RegLink.LinkColor = Color.Black;
            RegLink.Location = new Point(576, 529);
            RegLink.Name = "RegLink";
            RegLink.Size = new Size(486, 30);
            RegLink.TabIndex = 8;
            RegLink.TabStop = true;
            RegLink.Text = "Зарегистрировать нового пользователя";
            RegLink.VisitedLinkColor = Color.Black;
            // 
            // CloseButton
            // 
            CloseButton.BackColor = Color.FromArgb(255, 128, 128);
            CloseButton.FlatAppearance.BorderSize = 0;
            CloseButton.FlatStyle = FlatStyle.Flat;
            CloseButton.ForeColor = Color.White;
            CloseButton.Location = new Point(1057, -1);
            CloseButton.Name = "CloseButton";
            CloseButton.Padding = new Padding(2, 0, 0, 0);
            CloseButton.Size = new Size(35, 36);
            CloseButton.TabIndex = 9;
            CloseButton.Text = "X";
            CloseButton.UseVisualStyleBackColor = false;
            // 
            // LoginForm
            // 
            AutoScaleMode = AutoScaleMode.None;
            BackColor = Color.FromArgb(255, 242, 204);
            ClientSize = new Size(1091, 589);
            Controls.Add(CloseButton);
            Controls.Add(RegLink);
            Controls.Add(linkLabel1);
            Controls.Add(checkBox1);
            Controls.Add(pictureBox1);
            Controls.Add(EnterBtn);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(label2);
            Controls.Add(label1);
            Font = new Font("Century Gothic", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            FormBorderStyle = FormBorderStyle.None;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "LoginForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "LoginForm";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox textBox1;
        private TextBox textBox2;
        private Button EnterBtn;
        private PictureBox pictureBox1;
        private CheckBox checkBox1;
        private LinkLabel linkLabel1;
        private LinkLabel RegLink;
        private Button CloseButton;
    }
}