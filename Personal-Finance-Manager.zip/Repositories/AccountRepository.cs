﻿using Microsoft.EntityFrameworkCore;
using shershulya22.Models;

namespace shershulya22.Repositories
{
    public class AccountRepository(AppDbContext dbContext)
    {
        public async Task<List<AccountEntity>> GetAllForUser(Guid userId)
            => await dbContext.Accounts.Where(x=>x.UserId == userId).AsNoTracking().ToListAsync();

        public async Task Add(AccountEntity account)
        {
            await dbContext.Accounts.AddAsync(account);
            await dbContext.SaveChangesAsync();
        }

        public async Task<AccountEntity?> GetById(Guid id) 
            => await dbContext.Accounts.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id);

        public async Task Delete(Guid id)
        {
            var account = await dbContext.Accounts.FirstOrDefaultAsync(x => x.Id == id);
            if (account != null)
            {
                dbContext.Accounts.Remove(account);
                await dbContext.SaveChangesAsync();
            }
        }

        public async Task Update(AccountEntity account)
        {
            await dbContext.Accounts
           .Where(x => x.Id == account.Id)
           .ExecuteUpdateAsync(s => s
           .SetProperty(p => p.Name, p => account.Name)
           .SetProperty(p => p.Balance, p => account.Balance)
           .SetProperty(p => p.IsPublic, p => account.IsPublic));
        }
    }
}
