﻿using Microsoft.EntityFrameworkCore;
using shershulya22.Models;

namespace shershulya22.Repositories
{
    public class CategoryRepository(AppDbContext dbContext)
    {
        public async Task AddOnStart(Guid userId)
        {
            var category1 = new CategoryEntity() { CategoryName = "Здоровье", Type = CategoryType.Minus, UserId = userId };
            var category2 = new CategoryEntity() { CategoryName = "Досуг", Type = CategoryType.Minus, UserId = userId };
            var category3 = new CategoryEntity() { CategoryName = "Образование", Type = CategoryType.Minus, UserId = userId };
            var category4 = new CategoryEntity() { CategoryName = "Дом", Type = CategoryType.Minus, UserId = userId };
            var category5 = new CategoryEntity() { CategoryName = "Кафе", Type = CategoryType.Minus, UserId = userId };
            var category6 = new CategoryEntity() { CategoryName = "Подарки", Type = CategoryType.Minus, UserId = userId };
            var category7 = new CategoryEntity() { CategoryName = "Продукты", Type = CategoryType.Minus, UserId = userId };
            var category8 = new CategoryEntity() { CategoryName = "Семья", Type = CategoryType.Minus, UserId = userId };
            var category9 = new CategoryEntity() { CategoryName = "Другое", Type = CategoryType.Minus, UserId = userId };

            var category10 = new CategoryEntity() { CategoryName = "Зарплата", Type = CategoryType.Plus, UserId = userId };
            var category11 = new CategoryEntity() { CategoryName = "Подарок", Type = CategoryType.Plus, UserId = userId };
            var category12 = new CategoryEntity() { CategoryName = "Проценты", Type = CategoryType.Plus, UserId = userId };
            var category13 = new CategoryEntity() { CategoryName = "Другое", Type = CategoryType.Plus, UserId = userId };
            await dbContext.Categories.AddRangeAsync(
                category1, category2, category3, category4, 
                category5, category6, category7, category8, 
                category9, category10, category11, category12, category13);
            await dbContext.SaveChangesAsync();
        }

        public async Task<List<CategoryDTO>> GetAllForUserByType(Guid userId, CategoryType type)
        {
            var categories = await dbContext.Categories
                                                .Where(x => x.UserId == userId && x.Type == type)
                                                .AsNoTracking()
                                                .ToListAsync();

            return categories.Select(CategoryDTO.Map).ToList();
        }

        public async Task Add(CategoryEntity entity)
        {
            await dbContext.Categories.AddAsync(entity);
            await dbContext.SaveChangesAsync();
        }

        public async Task<CategoryEntity?> GetById(Guid id) 
            => await dbContext.Categories.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id);

        public async Task Delete(Guid id)
        {
            var category = await dbContext.Categories.FirstOrDefaultAsync(x => x.Id == id);
            if (category != null)
            {
                dbContext.Categories.Remove(category);
                await dbContext.SaveChangesAsync();
            }
        }

        public async Task Update(CategoryEntity account)
        {
            await dbContext.Categories
           .Where(x => x.Id == account.Id)
           .ExecuteUpdateAsync(s => s
           .SetProperty(p => p.CategoryName, p => account.CategoryName)
           .SetProperty(p => p.Type, p => account.Type)
           .SetProperty(p => p.PlannedAmount, p => account.PlannedAmount));
        }
    }
}
