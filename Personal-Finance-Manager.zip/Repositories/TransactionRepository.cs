﻿using Microsoft.EntityFrameworkCore;
using shershulya22.Models;

namespace shershulya22.Repositories
{
    public class TransactionRepository(AppDbContext dbContext)
    {
        public async Task Add(TransactionEntity entity)
        {
            await dbContext.Transactions.AddAsync(entity);
            await dbContext.SaveChangesAsync();
        }
        public async Task<List<TransactionDTO>> GetTransactions(Guid userId, CategoryType type, DateTime start, DateTime end, string filterText = null)
        {
            var query = dbContext.Transactions
                                    .Include(x => x.Account)
                                    .Include(x => x.Category)
                                    .Where(x => x.UserId == userId && x.Type == type && x.Date >= start && x.Date <= end);

            if (!string.IsNullOrWhiteSpace(filterText))
            {
                filterText = $"%{filterText}%";

                query = query.Where(x =>
                    EF.Functions.Like(x.Comment, filterText) ||
                    EF.Functions.Like(x.Account.Name, filterText) ||
                    EF.Functions.Like(x.Category.CategoryName, filterText) ||
                    EF.Functions.Like(x.Amount.ToString(), filterText) ||
                    EF.Functions.Like(x.Date.ToString(), filterText)
                );
            }

            var transfers = await query
                .OrderBy(x => x.Date)
                .AsNoTracking()
                .ToListAsync();

            return transfers.Select(TransactionDTO.Map).ToList();
        }
    }
}
