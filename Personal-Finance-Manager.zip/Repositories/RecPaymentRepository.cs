﻿using Microsoft.EntityFrameworkCore;
using shershulya22.Models;

namespace shershulya22.Repositories
{
    public class RecPaymentRepository(AppDbContext dbContext)
    {
        public async Task<List<RecPaymentDTO>> GetAllForUser(Guid userId)
        {
            var reminders = await dbContext.RecurringPayments
                                                .Where(x => x.UserId == userId)
                                                .AsNoTracking()
                                                .ToListAsync();
            return reminders.Select(RecPaymentDTO.Map).ToList();
        }
        public async Task Add(RecurringPaymentEntity entity)
        {
            await dbContext.RecurringPayments.AddAsync(entity);
            await dbContext.SaveChangesAsync();
        }

        public async Task Delete(Guid id)
        {
            var category = await dbContext.RecurringPayments.FirstOrDefaultAsync(x => x.Id == id);
            if (category != null)
            {
                dbContext.RecurringPayments.Remove(category);
                await dbContext.SaveChangesAsync();
            }
        }
        public async Task Update(RecurringPaymentEntity entity)
        {
            await dbContext.RecurringPayments
           .Where(x => x.Id == entity.Id)
           .ExecuteUpdateAsync(s => s
           .SetProperty(p => p.Name, p => entity.Name)
           .SetProperty(p => p.AccountId, p => entity.AccountId)
           .SetProperty(p => p.Frequency, p => entity.Frequency)
           .SetProperty(p => p.CategoryId, p => entity.CategoryId)
           .SetProperty(p => p.Amount, p => entity.Amount)
           .SetProperty(p => p.StartDate, p => entity.StartDate)
           .SetProperty(p => p.EndDate, p => entity.EndDate)
           .SetProperty(p => p.Comment, p => entity.Comment)
           );
        }
        public async Task UpdateActivity(Guid id, bool isOff)
        {
            await dbContext.RecurringPayments
           .Where(x => x.Id == id)
           .ExecuteUpdateAsync(s => s
           .SetProperty(p => p.IsOff, p => isOff));
        }
        public async Task<RecurringPaymentEntity?> GetById(Guid id)
            => await dbContext.RecurringPayments.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id);
    }
}
