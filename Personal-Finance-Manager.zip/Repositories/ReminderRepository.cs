﻿using Microsoft.EntityFrameworkCore;
using shershulya22.Models;

namespace shershulya22.Repositories
{
    public class ReminderRepository(AppDbContext dbContext)
    {
        public async Task<List<RemindDTO>> GetAllForUser(Guid userId)
        {
            var reminders = await dbContext.Reminders
                                                .Where(x => x.UserId == userId)
                                                .AsNoTracking()
                                                .ToListAsync();
            return reminders.Select(RemindDTO.Map).ToList();
        }
        public async Task Add(ReminderEntity entity)
        {
            await dbContext.Reminders.AddAsync(entity);
            await dbContext.SaveChangesAsync();
        }
        public async Task Delete(Guid id)
        {
            var category = await dbContext.Reminders.FirstOrDefaultAsync(x => x.Id == id);
            if (category != null)
            {
                dbContext.Reminders.Remove(category);
                await dbContext.SaveChangesAsync();
            }
        }
        public async Task Update(ReminderEntity entity)
        {
            await dbContext.Reminders
           .Where(x => x.Id == entity.Id)
           .ExecuteUpdateAsync(s => s
           .SetProperty(p => p.Name, p => entity.Name)
           .SetProperty(p => p.Frequency, p => entity.Frequency)
           .SetProperty(p => p.StartDate, p => entity.StartDate)
           .SetProperty(p => p.Comment, p => entity.Comment)
           );
        }
        public async Task UpdateActivity(Guid id, bool isOff)
        {
            await dbContext.Reminders
           .Where(x => x.Id == id)
           .ExecuteUpdateAsync(s => s
           .SetProperty(p => p.IsOff, p => isOff));
        }

        public async Task<ReminderEntity?> GetById(Guid id) 
            => await dbContext.Reminders.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id);
    }
}
