﻿using Microsoft.EntityFrameworkCore;
using shershulya22.Models;

namespace shershulya22.Repositories
{
    public class TransferRepository(AppDbContext dbContext)
    {
        public async Task Add(TransferEntity transfer)
        {
            await dbContext.Transfers.AddAsync(transfer);
            await dbContext.SaveChangesAsync();
        }

        public async Task<List<TransferHistory>> GetHistory(Guid userId)
        {
            var transfers = await dbContext.Transfers
                .Include(x=>x.FromAccount)
                .Include(x=>x.ToAccount)
                .Where(x => x.UserId == userId)
                .OrderBy(x=>x.Date)
                .AsNoTracking()
                .ToListAsync();
            return transfers.Select(TransferHistory.Map).ToList();
        }
    }
}
