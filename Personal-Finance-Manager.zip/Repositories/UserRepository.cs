﻿using Microsoft.EntityFrameworkCore;
using shershulya22.Models;
using System.ComponentModel.DataAnnotations;

namespace shershulya22.Repositories
{
    public class UserRepository(AppDbContext dbContext)
    {
        public async Task<UserEntity?> Auth(string email, string password)
        {
            var user = await dbContext.Users.AsNoTracking().FirstOrDefaultAsync(u => u.Email == email);
            if (user == null) return null;

            if (!SecurityHelper.VerifyPassword(password, user.Password))
                return null;

            return user;
        }
        public async Task<bool> UserExist(string email)
            => await dbContext.Users.AsNoTracking().AnyAsync(user => user.Email == email);

        public async Task<string> UserPassword(string email)
            => (await dbContext.Users.AsNoTracking().FirstOrDefaultAsync(user => user.Email == email))!.Password;

        public async Task<string?> Add(UserEntity user)
        {
            try
            {
                var validationContext = new ValidationContext(user);
                Validator.ValidateObject(user, validationContext, validateAllProperties: true);

                // Хэширование пароля перед сохранением
                user.Password = SecurityHelper.HashPassword(user.Password);

                await dbContext.Users.AddAsync(user);
                await dbContext.SaveChangesAsync();
                return string.Empty;
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }
        public async Task UpdateName(Guid userId, string name)
        {
            await dbContext.Users
           .Where(x => x.Id == userId)
           .ExecuteUpdateAsync(s => s
           .SetProperty(p => p.Name, p => name));
        }
        public async Task UpdatePassword(Guid userId, string password)
        {
            string hashedPassword = SecurityHelper.HashPassword(password);

            await dbContext.Users
               .Where(x => x.Id == userId)
               .ExecuteUpdateAsync(s => s
               .SetProperty(p => p.Password, p => hashedPassword));
        }
        public async Task<string?> ResetPassword(string email)
        {
            var user = await dbContext.Users.FirstOrDefaultAsync(u => u.Email == email);
            if (user == null) return "Пользователь не найден";

            var tempPassword = SecurityHelper.GenerateTemporaryPassword();
            var hashedPassword = SecurityHelper.HashPassword(tempPassword);

            user.Password = hashedPassword;
            await dbContext.SaveChangesAsync();

            // Отправляем временный пароль на email
            MailHelper.Send(user.Email, $"Ваш временный пароль: {tempPassword}\nРекомендуется сменить его после входа в систему.");

            return null;
        }
    }
}
