﻿namespace shershulya22.Controls
{
    partial class MainControl
    {
        /// <summary> 
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainControl));
            dataGrid = new DataGridView();
            Column1 = new DataGridViewTextBoxColumn();
            Column2 = new DataGridViewTextBoxColumn();
            Column3 = new DataGridViewTextBoxColumn();
            PlusBtn = new Button();
            MinusBtn = new Button();
            DatePanel = new Panel();
            DatePickPanel = new Panel();
            LeftArrow = new PictureBox();
            pictureBox1 = new PictureBox();
            TransControl = new PictureBox();
            DateLabel = new Label();
            RightArrow = new PictureBox();
            PeriodPanel = new Panel();
            dateTimePicker2 = new DateTimePicker();
            label3 = new Label();
            dateTimePicker1 = new DateTimePicker();
            label2 = new Label();
            PeriodBtn = new Button();
            YearBtn = new Button();
            MonthBtn = new Button();
            WeekBtn = new Button();
            DayBtn = new Button();
            AddBtn = new Button();
            DiagramPanel = new Panel();
            labelTotal = new Label();
            ((System.ComponentModel.ISupportInitialize)dataGrid).BeginInit();
            DatePanel.SuspendLayout();
            DatePickPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)LeftArrow).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)TransControl).BeginInit();
            ((System.ComponentModel.ISupportInitialize)RightArrow).BeginInit();
            PeriodPanel.SuspendLayout();
            SuspendLayout();
            // 
            // dataGrid
            // 
            dataGrid.BackgroundColor = Color.White;
            dataGrid.BorderStyle = BorderStyle.None;
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = SystemColors.Control;
            dataGridViewCellStyle1.Font = new Font("Century Gothic", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 204);
            dataGridViewCellStyle1.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            dataGrid.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            dataGrid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGrid.Columns.AddRange(new DataGridViewColumn[] { Column1, Column2, Column3 });
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = SystemColors.Window;
            dataGridViewCellStyle2.Font = new Font("Century Gothic", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            dataGridViewCellStyle2.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = SystemColors.Window;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.ControlText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.False;
            dataGrid.DefaultCellStyle = dataGridViewCellStyle2;
            dataGrid.Location = new Point(31, 554);
            dataGrid.Name = "dataGrid";
            dataGrid.RowHeadersVisible = false;
            dataGrid.Size = new Size(819, 167);
            dataGrid.TabIndex = 18;
            // 
            // Column1
            // 
            Column1.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            Column1.DataPropertyName = "CategoryName";
            Column1.HeaderText = "Название категории";
            Column1.Name = "Column1";
            Column1.Width = 211;
            // 
            // Column2
            // 
            Column2.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            Column2.DataPropertyName = "Percent";
            Column2.HeaderText = "%";
            Column2.Name = "Column2";
            Column2.Width = 51;
            // 
            // Column3
            // 
            Column3.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            Column3.DataPropertyName = "DisplayAmount";
            Column3.HeaderText = "Сумма";
            Column3.Name = "Column3";
            // 
            // PlusBtn
            // 
            PlusBtn.BackColor = SystemColors.ButtonHighlight;
            PlusBtn.FlatAppearance.BorderSize = 0;
            PlusBtn.FlatStyle = FlatStyle.Flat;
            PlusBtn.Font = new Font("Century Gothic", 20.25F);
            PlusBtn.Location = new Point(648, 23);
            PlusBtn.Name = "PlusBtn";
            PlusBtn.Size = new Size(205, 50);
            PlusBtn.TabIndex = 20;
            PlusBtn.Text = "Доходы";
            PlusBtn.UseVisualStyleBackColor = false;
            // 
            // MinusBtn
            // 
            MinusBtn.BackColor = Color.FromArgb(251, 229, 214);
            MinusBtn.FlatAppearance.BorderSize = 0;
            MinusBtn.FlatStyle = FlatStyle.Flat;
            MinusBtn.Font = new Font("Century Gothic", 20.25F);
            MinusBtn.Location = new Point(34, 23);
            MinusBtn.Name = "MinusBtn";
            MinusBtn.Size = new Size(205, 50);
            MinusBtn.TabIndex = 19;
            MinusBtn.Text = "Расходы";
            MinusBtn.UseVisualStyleBackColor = false;
            // 
            // DatePanel
            // 
            DatePanel.BackColor = SystemColors.ButtonHighlight;
            DatePanel.Controls.Add(DatePickPanel);
            DatePanel.Controls.Add(PeriodPanel);
            DatePanel.Controls.Add(PeriodBtn);
            DatePanel.Controls.Add(YearBtn);
            DatePanel.Controls.Add(MonthBtn);
            DatePanel.Controls.Add(WeekBtn);
            DatePanel.Controls.Add(DayBtn);
            DatePanel.Location = new Point(34, 78);
            DatePanel.Name = "DatePanel";
            DatePanel.Size = new Size(819, 100);
            DatePanel.TabIndex = 21;
            // 
            // DatePickPanel
            // 
            DatePickPanel.Controls.Add(LeftArrow);
            DatePickPanel.Controls.Add(pictureBox1);
            DatePickPanel.Controls.Add(TransControl);
            DatePickPanel.Controls.Add(DateLabel);
            DatePickPanel.Controls.Add(RightArrow);
            DatePickPanel.Dock = DockStyle.Bottom;
            DatePickPanel.Location = new Point(0, 0);
            DatePickPanel.Name = "DatePickPanel";
            DatePickPanel.Padding = new Padding(0, 0, 100, 0);
            DatePickPanel.Size = new Size(819, 50);
            DatePickPanel.TabIndex = 22;
            // 
            // LeftArrow
            // 
            LeftArrow.Dock = DockStyle.Left;
            LeftArrow.Image = (Image)resources.GetObject("LeftArrow.Image");
            LeftArrow.Location = new Point(94, 0);
            LeftArrow.Name = "LeftArrow";
            LeftArrow.Size = new Size(50, 50);
            LeftArrow.SizeMode = PictureBoxSizeMode.Zoom;
            LeftArrow.TabIndex = 33;
            LeftArrow.TabStop = false;
            // 
            // pictureBox1
            // 
            pictureBox1.Dock = DockStyle.Left;
            pictureBox1.Location = new Point(50, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(44, 50);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 32;
            pictureBox1.TabStop = false;
            // 
            // TransControl
            // 
            TransControl.Dock = DockStyle.Left;
            TransControl.Image = (Image)resources.GetObject("TransControl.Image");
            TransControl.Location = new Point(0, 0);
            TransControl.Name = "TransControl";
            TransControl.Size = new Size(50, 50);
            TransControl.SizeMode = PictureBoxSizeMode.Zoom;
            TransControl.TabIndex = 30;
            TransControl.TabStop = false;
            // 
            // DateLabel
            // 
            DateLabel.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            DateLabel.Font = new Font("Century Gothic", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 204);
            DateLabel.ForeColor = Color.FromArgb(140, 140, 140);
            DateLabel.Location = new Point(141, 0);
            DateLabel.Name = "DateLabel";
            DateLabel.Size = new Size(528, 50);
            DateLabel.TabIndex = 29;
            DateLabel.Text = "Март 2025 год";
            DateLabel.TextAlign = ContentAlignment.MiddleCenter;
            DateLabel.Click += DateLabel_Click;
            // 
            // RightArrow
            // 
            RightArrow.Dock = DockStyle.Right;
            RightArrow.Image = (Image)resources.GetObject("RightArrow.Image");
            RightArrow.Location = new Point(669, 0);
            RightArrow.Name = "RightArrow";
            RightArrow.Size = new Size(50, 50);
            RightArrow.SizeMode = PictureBoxSizeMode.Zoom;
            RightArrow.TabIndex = 28;
            RightArrow.TabStop = false;
            // 
            // PeriodPanel
            // 
            PeriodPanel.AccessibleRole = AccessibleRole.TitleBar;
            PeriodPanel.Controls.Add(dateTimePicker2);
            PeriodPanel.Controls.Add(label3);
            PeriodPanel.Controls.Add(dateTimePicker1);
            PeriodPanel.Controls.Add(label2);
            PeriodPanel.Dock = DockStyle.Bottom;
            PeriodPanel.Font = new Font("Century Gothic", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            PeriodPanel.Location = new Point(0, 50);
            PeriodPanel.Name = "PeriodPanel";
            PeriodPanel.Padding = new Padding(100, 10, 0, 0);
            PeriodPanel.Size = new Size(819, 50);
            PeriodPanel.TabIndex = 23;
            // 
            // dateTimePicker2
            // 
            dateTimePicker2.Dock = DockStyle.Left;
            dateTimePicker2.Location = new Point(499, 10);
            dateTimePicker2.Name = "dateTimePicker2";
            dateTimePicker2.Size = new Size(200, 31);
            dateTimePicker2.TabIndex = 3;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Dock = DockStyle.Left;
            label3.Location = new Point(389, 10);
            label3.Name = "label3";
            label3.Padding = new Padding(10, 0, 10, 0);
            label3.Size = new Size(110, 22);
            label3.TabIndex = 2;
            label3.Text = "Дата по:";
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Dock = DockStyle.Left;
            dateTimePicker1.Location = new Point(189, 10);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(200, 31);
            dateTimePicker1.TabIndex = 1;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Dock = DockStyle.Left;
            label2.Location = new Point(100, 10);
            label2.Name = "label2";
            label2.Padding = new Padding(0, 0, 10, 0);
            label2.Size = new Size(89, 22);
            label2.TabIndex = 0;
            label2.Text = "Дата с:";
            label2.Click += label2_Click;
            // 
            // PeriodBtn
            // 
            PeriodBtn.FlatAppearance.BorderSize = 0;
            PeriodBtn.FlatStyle = FlatStyle.Flat;
            PeriodBtn.Location = new Point(692, 0);
            PeriodBtn.Name = "PeriodBtn";
            PeriodBtn.Size = new Size(110, 31);
            PeriodBtn.TabIndex = 26;
            PeriodBtn.Text = "Период";
            PeriodBtn.UseVisualStyleBackColor = true;
            // 
            // YearBtn
            // 
            YearBtn.FlatAppearance.BorderSize = 0;
            YearBtn.FlatStyle = FlatStyle.Flat;
            YearBtn.Location = new Point(540, 3);
            YearBtn.Name = "YearBtn";
            YearBtn.Size = new Size(75, 31);
            YearBtn.TabIndex = 25;
            YearBtn.Text = "Год";
            YearBtn.UseVisualStyleBackColor = true;
            // 
            // MonthBtn
            // 
            MonthBtn.BackColor = Color.FromArgb(222, 235, 247);
            MonthBtn.FlatAppearance.BorderSize = 0;
            MonthBtn.FlatStyle = FlatStyle.Flat;
            MonthBtn.Location = new Point(367, 3);
            MonthBtn.Name = "MonthBtn";
            MonthBtn.Size = new Size(89, 31);
            MonthBtn.TabIndex = 24;
            MonthBtn.Text = "Месяц";
            MonthBtn.UseVisualStyleBackColor = false;
            // 
            // WeekBtn
            // 
            WeekBtn.FlatAppearance.BorderSize = 0;
            WeekBtn.FlatStyle = FlatStyle.Flat;
            WeekBtn.Location = new Point(176, 3);
            WeekBtn.Name = "WeekBtn";
            WeekBtn.Size = new Size(93, 31);
            WeekBtn.TabIndex = 23;
            WeekBtn.Text = "Неделя";
            WeekBtn.UseVisualStyleBackColor = true;
            // 
            // DayBtn
            // 
            DayBtn.FlatAppearance.BorderSize = 0;
            DayBtn.FlatStyle = FlatStyle.Flat;
            DayBtn.Location = new Point(3, 3);
            DayBtn.Name = "DayBtn";
            DayBtn.Size = new Size(75, 31);
            DayBtn.TabIndex = 22;
            DayBtn.Text = "День";
            DayBtn.UseVisualStyleBackColor = true;
            // 
            // AddBtn
            // 
            AddBtn.FlatAppearance.BorderSize = 0;
            AddBtn.FlatStyle = FlatStyle.Flat;
            AddBtn.Image = (Image)resources.GetObject("AddBtn.Image");
            AddBtn.ImageAlign = ContentAlignment.TopCenter;
            AddBtn.Location = new Point(756, 318);
            AddBtn.Name = "AddBtn";
            AddBtn.Size = new Size(113, 64);
            AddBtn.TabIndex = 22;
            AddBtn.Text = "Добавить";
            AddBtn.TextAlign = ContentAlignment.BottomCenter;
            AddBtn.UseVisualStyleBackColor = true;
            // 
            // DiagramPanel
            // 
            DiagramPanel.Location = new Point(34, 186);
            DiagramPanel.Name = "DiagramPanel";
            DiagramPanel.Size = new Size(716, 336);
            DiagramPanel.TabIndex = 23;
            // 
            // labelTotal
            // 
            labelTotal.AutoSize = true;
            labelTotal.Font = new Font("Century Gothic", 18F, FontStyle.Bold, GraphicsUnit.Point, 204);
            labelTotal.Location = new Point(339, 37);
            labelTotal.Name = "labelTotal";
            labelTotal.Size = new Size(84, 28);
            labelTotal.TabIndex = 24;
            labelTotal.Text = "label1";
            // 
            // MainControl
            // 
            AutoScaleDimensions = new SizeF(96F, 96F);
            AutoScaleMode = AutoScaleMode.Dpi;
            BackColor = SystemColors.ButtonHighlight;
            Controls.Add(labelTotal);
            Controls.Add(DiagramPanel);
            Controls.Add(AddBtn);
            Controls.Add(DatePanel);
            Controls.Add(PlusBtn);
            Controls.Add(MinusBtn);
            Controls.Add(dataGrid);
            Font = new Font("Century Gothic", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            Name = "MainControl";
            Size = new Size(886, 744);
            Load += MainControl_Load;
            ((System.ComponentModel.ISupportInitialize)dataGrid).EndInit();
            DatePanel.ResumeLayout(false);
            DatePickPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)LeftArrow).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)TransControl).EndInit();
            ((System.ComponentModel.ISupportInitialize)RightArrow).EndInit();
            PeriodPanel.ResumeLayout(false);
            PeriodPanel.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGrid;
        private Button PlusBtn;
        private Button MinusBtn;
        private Panel DatePanel;
        private Button PeriodBtn;
        private Button YearBtn;
        private Button MonthBtn;
        private Button WeekBtn;
        private Button DayBtn;
        private PictureBox RightArrow;
        private Label DateLabel;
        private Panel DatePickPanel;
        private Panel PeriodPanel;
        private DateTimePicker dateTimePicker2;
        private Label label3;
        private DateTimePicker dateTimePicker1;
        private Label label2;
        private Button AddBtn;
        private DataGridViewTextBoxColumn Column1;
        private DataGridViewTextBoxColumn Column2;
        private DataGridViewTextBoxColumn Column3;
        private Panel DiagramPanel;
        private PictureBox LeftArrow;
        private PictureBox pictureBox1;
        private PictureBox TransControl;
        private Label labelTotal;
    }
}
