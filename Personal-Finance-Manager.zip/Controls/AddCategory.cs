﻿using shershulya22.Models;

namespace shershulya22.Controls
{
    public partial class AddCategory: UserControl
    {
        private CategoryEntity? _categoryEntity;
        public AddCategory()
        {
            InitializeComponent();
            pictureBox1.Click += (s, e) => Close();
            textBox2.TextChanged += (s, e) => textBox2.Text = textBox2.Text.Replace('.', ',');
            AddBtn.Click += async (s, e) => await Add();
        }
        public AddCategory(Guid id)
        {
            InitializeComponent();
            label1.Text = "Редактировать категорию";
            textBox2.TextChanged += (s, e) => textBox2.Text = textBox2.Text.Replace('.', ',');
            Load += async (s, e) =>
            {
                _categoryEntity = await Loader.Instance.CategoryRepository.GetById(id);
                if (_categoryEntity == null)
                    return;
                textBox1.Text = _categoryEntity.CategoryName;
                textBox2.Text = _categoryEntity.PlannedAmount?.ToString();
                radioButton1.Checked = _categoryEntity.Type == CategoryType.Minus;
                radioButton2.Checked = _categoryEntity.Type == CategoryType.Plus;
                DeleteBtn.Visible = true;
                AddBtn.Text = "Изменить категорию";
            };
            pictureBox1.Click += (s, e) => Close();
            AddBtn.Click += async (s, e) => await Update();
            DeleteBtn.Click += async (s, e) =>
            {
                var dialog = MessageBox.Show("Вы хотите удалить эту категорию?", "Предупреждение", MessageBoxButtons.YesNo);
                if (dialog != DialogResult.Yes)
                    return;
                await Loader.Instance.CategoryRepository.Delete(id);
                GlobalEvents.ShowCategoryControl(this);
            };
        }
        private void Close()
        {
            var dialog = MessageBox.Show("Вы уверены, что хотите уйти с Создание категории?", "Предупреждение", MessageBoxButtons.YesNo);
            if (dialog != DialogResult.Yes)
                return;
            GlobalEvents.ShowCategoryControl(this);
        }
        private async Task Add()
        {
            if (string.IsNullOrEmpty(textBox1.Text))
            {
                MessageBox.Show("Заполните название категории");
                return;
            }
            var canParse = decimal.TryParse(textBox2.Text, out decimal amount);
            if (!canParse && !string.IsNullOrEmpty(textBox2.Text))
            {
                MessageBox.Show("Не могу понять сумму!");
                return;
            }
            if(amount < 0)
            {
                MessageBox.Show("Сумма должна быть положительна");
                return;
            }
            var category = new CategoryEntity
            {
                CategoryName = textBox1.Text,
                Type = radioButton1.Checked ? CategoryType.Minus : CategoryType.Plus,
                UserId = Program.CurrentUser,
                PlannedAmount = string.IsNullOrEmpty(textBox2.Text) ? null : amount
            };
            await Loader.Instance.CategoryRepository.Add(category);
            GlobalEvents.ShowCategoryControl(this);
        }
        private async Task Update()
        {
            if (string.IsNullOrEmpty(textBox1.Text))
            {
                MessageBox.Show("Заполните название категории");
                return;
            }
            var canParse = decimal.TryParse(textBox2.Text, out decimal amount);
            if (!canParse && !string.IsNullOrEmpty(textBox2.Text))
            {
                MessageBox.Show("Не могу понять сумму!");
                return;
            }
            if (amount < 0)
            {
                MessageBox.Show("Сумма должна быть положительна");
                return;
            }
            var category = new CategoryEntity
            {
                Id = _categoryEntity.Id,
                CategoryName = textBox1.Text,
                Type = radioButton1.Checked ? CategoryType.Minus : CategoryType.Plus,
                PlannedAmount = string.IsNullOrEmpty(textBox2.Text) ? null : amount
            };
            await Loader.Instance.CategoryRepository.Update(category);
            GlobalEvents.ShowCategoryControl(this);
        }
    }
}
