﻿namespace shershulya22.Controls
{
    partial class AddCategory
    {
        /// <summary> 
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddCategory));
            pictureBox1 = new PictureBox();
            label1 = new Label();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            label2 = new Label();
            label3 = new Label();
            radioButton1 = new RadioButton();
            radioButton2 = new RadioButton();
            AddBtn = new Button();
            DeleteBtn = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(4, 6);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(48, 48);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 4;
            pictureBox1.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Century Gothic", 26.25F, FontStyle.Bold);
            label1.Location = new Point(251, 53);
            label1.Name = "label1";
            label1.Size = new Size(387, 41);
            label1.TabIndex = 3;
            label1.Text = "Создание категории";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(160, 156);
            textBox1.Name = "textBox1";
            textBox1.PlaceholderText = "Название категории";
            textBox1.Size = new Size(566, 41);
            textBox1.TabIndex = 5;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(160, 395);
            textBox2.Name = "textBox2";
            textBox2.PlaceholderText = "руб. в месяц";
            textBox2.Size = new Size(566, 41);
            textBox2.TabIndex = 6;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(160, 229);
            label2.Name = "label2";
            label2.Size = new Size(59, 33);
            label2.TabIndex = 7;
            label2.Text = "Тип";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(160, 356);
            label3.Name = "label3";
            label3.Size = new Size(566, 33);
            label3.TabIndex = 8;
            label3.Text = "Планирую тратить / Планируемый доход";
            // 
            // radioButton1
            // 
            radioButton1.AutoSize = true;
            radioButton1.Checked = true;
            radioButton1.Location = new Point(160, 268);
            radioButton1.Name = "radioButton1";
            radioButton1.Size = new Size(149, 37);
            radioButton1.TabIndex = 9;
            radioButton1.TabStop = true;
            radioButton1.Text = "Расходы";
            radioButton1.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            radioButton2.AutoSize = true;
            radioButton2.Location = new Point(436, 268);
            radioButton2.Name = "radioButton2";
            radioButton2.Size = new Size(136, 37);
            radioButton2.TabIndex = 10;
            radioButton2.Text = "Доходы";
            radioButton2.UseVisualStyleBackColor = true;
            // 
            // AddBtn
            // 
            AddBtn.BackColor = Color.FromArgb(226, 240, 217);
            AddBtn.FlatStyle = FlatStyle.Flat;
            AddBtn.Font = new Font("Century Gothic", 20.25F);
            AddBtn.Location = new Point(160, 579);
            AddBtn.Name = "AddBtn";
            AddBtn.Size = new Size(315, 50);
            AddBtn.TabIndex = 15;
            AddBtn.Text = "Добавить категорию";
            AddBtn.UseVisualStyleBackColor = false;
            // 
            // DeleteBtn
            // 
            DeleteBtn.BackColor = Color.FromArgb(251, 229, 214);
            DeleteBtn.FlatStyle = FlatStyle.Flat;
            DeleteBtn.Font = new Font("Century Gothic", 20.25F);
            DeleteBtn.Location = new Point(512, 579);
            DeleteBtn.Name = "DeleteBtn";
            DeleteBtn.Size = new Size(214, 50);
            DeleteBtn.TabIndex = 16;
            DeleteBtn.Text = "Удалить";
            DeleteBtn.UseVisualStyleBackColor = false;
            DeleteBtn.Visible = false;
            // 
            // AddCategory
            // 
            AutoScaleMode = AutoScaleMode.None;
            BackColor = Color.White;
            Controls.Add(DeleteBtn);
            Controls.Add(AddBtn);
            Controls.Add(radioButton2);
            Controls.Add(radioButton1);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(pictureBox1);
            Controls.Add(label1);
            Font = new Font("Century Gothic", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            Name = "AddCategory";
            Size = new Size(886, 744);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private Label label1;
        private TextBox textBox1;
        private TextBox textBox2;
        private Label label2;
        private Label label3;
        private RadioButton radioButton1;
        private RadioButton radioButton2;
        private Button AddBtn;
        private Button DeleteBtn;
    }
}
