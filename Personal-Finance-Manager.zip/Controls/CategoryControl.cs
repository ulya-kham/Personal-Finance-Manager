﻿using shershulya22.Models;

namespace shershulya22.Controls
{
    public partial class CategoryControl: UserControl
    {
        public CategoryControl()
        {
            InitializeComponent();
            Load += async (s, e) =>
            {
                await LoadData(CategoryType.Minus);
            };
            MinusBtn.Click += async (s, e) =>
            {
                MinusBtn.BackColor = Color.FromArgb(251, 229, 214);
                PlusBtn.BackColor = SystemColors.ControlLightLight;
                plannedAmountDataGridViewTextBoxColumn.HeaderText = "Планируется тратить";
                await LoadData(CategoryType.Minus);
            };
            PlusBtn.Click += async (s, e) =>
            {
                PlusBtn.BackColor = Color.FromArgb(226, 240, 217);
                plannedAmountDataGridViewTextBoxColumn.HeaderText = "Планируется доход в месяц";
                MinusBtn.BackColor = SystemColors.ControlLightLight;
                await LoadData(CategoryType.Plus);
            };
            dataGrid.CellDoubleClick += (s, e) =>
            {
                var guid = Guid.Parse(dataGrid[0, e.RowIndex].Value.ToString());
                GlobalEvents.ShowEditControl(this, guid, GlobalEvents.GetCategoryEditControlHandler());
            };
            AddBtn.Click += (s, e) => GlobalEvents.ShowAddControl(this, GlobalEvents.GetCategoryAddControlHandler());
        }
        private async Task LoadData(CategoryType type)
        {
            var categories = await Loader.Instance.CategoryRepository.GetAllForUserByType(Program.CurrentUser, type);
            dataGrid.DataSource = categories;
        }
    }
}
