﻿namespace shershulya22.Controls
{
    partial class SettingsControl
    {
        /// <summary> 
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SettingsControl));
            label1 = new Label();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            ExitBtn = new Button();
            NameBtn = new Button();
            PasswordBtn = new Button();
            pictureBox1 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Century Gothic", 26.25F, FontStyle.Bold);
            label1.Location = new Point(336, 39);
            label1.Name = "label1";
            label1.Size = new Size(212, 41);
            label1.TabIndex = 6;
            label1.Text = "Настройки";
            // 
            // textBox1
            // 
            textBox1.Font = new Font("Century Gothic", 18F);
            textBox1.Location = new Point(84, 127);
            textBox1.Name = "textBox1";
            textBox1.PlaceholderText = "Изменить имя";
            textBox1.Size = new Size(550, 37);
            textBox1.TabIndex = 7;
            // 
            // textBox2
            // 
            textBox2.Font = new Font("Century Gothic", 18F);
            textBox2.Location = new Point(84, 198);
            textBox2.Name = "textBox2";
            textBox2.PlaceholderText = "Изменить пароль";
            textBox2.Size = new Size(550, 37);
            textBox2.TabIndex = 8;
            // 
            // ExitBtn
            // 
            ExitBtn.BackColor = Color.FromArgb(251, 229, 214);
            ExitBtn.FlatStyle = FlatStyle.Flat;
            ExitBtn.Font = new Font("Century Gothic", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            ExitBtn.Location = new Point(577, 669);
            ExitBtn.Name = "ExitBtn";
            ExitBtn.Size = new Size(285, 50);
            ExitBtn.TabIndex = 21;
            ExitBtn.Text = "Выйти из профиля";
            ExitBtn.UseVisualStyleBackColor = false;
            // 
            // NameBtn
            // 
            NameBtn.BackColor = Color.FromArgb(222, 235, 247);
            NameBtn.FlatStyle = FlatStyle.Flat;
            NameBtn.Font = new Font("Century Gothic", 18F);
            NameBtn.Location = new Point(676, 127);
            NameBtn.Name = "NameBtn";
            NameBtn.Size = new Size(186, 37);
            NameBtn.TabIndex = 22;
            NameBtn.Text = "Изменить";
            NameBtn.UseVisualStyleBackColor = false;
            // 
            // PasswordBtn
            // 
            PasswordBtn.BackColor = Color.FromArgb(222, 235, 247);
            PasswordBtn.FlatStyle = FlatStyle.Flat;
            PasswordBtn.Font = new Font("Century Gothic", 18F);
            PasswordBtn.Location = new Point(676, 198);
            PasswordBtn.Name = "PasswordBtn";
            PasswordBtn.Size = new Size(186, 37);
            PasswordBtn.TabIndex = 23;
            PasswordBtn.Text = "Изменить";
            PasswordBtn.UseVisualStyleBackColor = false;
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.Transparent;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(140, 267);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(622, 396);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 24;
            pictureBox1.TabStop = false;
            // 
            // SettingsControl
            // 
            AutoScaleMode = AutoScaleMode.None;
            BackColor = Color.White;
            Controls.Add(pictureBox1);
            Controls.Add(PasswordBtn);
            Controls.Add(NameBtn);
            Controls.Add(ExitBtn);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(label1);
            Font = new Font("Tahoma", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            Name = "SettingsControl";
            Size = new Size(886, 744);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox textBox1;
        private TextBox textBox2;
        private Button ExitBtn;
        private Button NameBtn;
        private Button PasswordBtn;
        private PictureBox pictureBox1;
    }
}
