﻿namespace shershulya22.Controls
{
    partial class AddAccount
    {
        /// <summary> 
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddAccount));
            label1 = new Label();
            pictureBox1 = new PictureBox();
            NameTB = new TextBox();
            SumTB = new TextBox();
            checkBox1 = new CheckBox();
            AddBtn = new Button();
            DeleteBtn = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Century Gothic", 26.25F, FontStyle.Bold);
            label1.Location = new Point(261, 70);
            label1.Name = "label1";
            label1.Size = new Size(352, 41);
            label1.TabIndex = 1;
            label1.Text = "Добавление счета";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(27, 18);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(48, 48);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 2;
            pictureBox1.TabStop = false;
            // 
            // NameTB
            // 
            NameTB.Font = new Font("Century Gothic", 18F);
            NameTB.Location = new Point(190, 201);
            NameTB.Name = "NameTB";
            NameTB.PlaceholderText = "Имя счета";
            NameTB.Size = new Size(470, 37);
            NameTB.TabIndex = 3;
            // 
            // SumTB
            // 
            SumTB.Font = new Font("Century Gothic", 18F, FontStyle.Bold, GraphicsUnit.Point, 204);
            SumTB.Location = new Point(190, 269);
            SumTB.Name = "SumTB";
            SumTB.PlaceholderText = "Сумма руб.";
            SumTB.Size = new Size(470, 37);
            SumTB.TabIndex = 4;
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.Checked = true;
            checkBox1.CheckState = CheckState.Checked;
            checkBox1.Font = new Font("Century Gothic", 18F);
            checkBox1.Location = new Point(190, 333);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(378, 34);
            checkBox1.TabIndex = 5;
            checkBox1.Text = "Учитывать в общем балансе";
            checkBox1.UseVisualStyleBackColor = true;
            // 
            // AddBtn
            // 
            AddBtn.BackColor = Color.FromArgb(226, 240, 217);
            AddBtn.FlatStyle = FlatStyle.Flat;
            AddBtn.Font = new Font("Century Gothic", 20.25F);
            AddBtn.Location = new Point(190, 584);
            AddBtn.Name = "AddBtn";
            AddBtn.Size = new Size(237, 50);
            AddBtn.TabIndex = 6;
            AddBtn.Text = "Добавить счет";
            AddBtn.UseVisualStyleBackColor = false;
            // 
            // DeleteBtn
            // 
            DeleteBtn.BackColor = Color.FromArgb(251, 229, 214);
            DeleteBtn.FlatStyle = FlatStyle.Flat;
            DeleteBtn.Font = new Font("Century Gothic", 20.25F);
            DeleteBtn.Location = new Point(460, 584);
            DeleteBtn.Name = "DeleteBtn";
            DeleteBtn.Size = new Size(200, 50);
            DeleteBtn.TabIndex = 7;
            DeleteBtn.Text = "Удалить";
            DeleteBtn.UseVisualStyleBackColor = false;
            DeleteBtn.Visible = false;
            // 
            // AddAccount
            // 
            AutoScaleMode = AutoScaleMode.None;
            BackColor = Color.White;
            Controls.Add(DeleteBtn);
            Controls.Add(AddBtn);
            Controls.Add(checkBox1);
            Controls.Add(SumTB);
            Controls.Add(NameTB);
            Controls.Add(pictureBox1);
            Controls.Add(label1);
            Font = new Font("Tahoma", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            Name = "AddAccount";
            Size = new Size(886, 744);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private PictureBox pictureBox1;
        private TextBox NameTB;
        private TextBox SumTB;
        private CheckBox checkBox1;
        private Button AddBtn;
        private Button DeleteBtn;
    }
}
