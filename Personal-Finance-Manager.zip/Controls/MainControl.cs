﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using shershulya22.Models;
using Microsoft.EntityFrameworkCore;

namespace shershulya22.Controls
{
    public partial class MainControl : UserControl
    {
        private DatePeriod _currentPeriod;
        private CategoryType _currentCategory;
        private CategoryType CurrentCategory
        {
            get => _currentCategory;
            set
            {
                _currentCategory = value;
                LoadData();
            }
        }
        private DateTime _startDate;
        private DateTime _endDate;

        private void LoadData()
        {
            using (var dbContext = new AppDbContext())
            {
                var start = _startDate;
                var end = _endDate;
                var cat = _currentCategory;

                var transactions = dbContext.Transactions
                .Where(t => t.UserId == Program.CurrentUser &&
                            t.Type == _currentCategory &&
                            t.Date >= _startDate && t.Date <= _endDate)
                .Include(t => t.Category)
                .ToList();

                var groupedByCategory = transactions
                    .GroupBy(t => t.Category)
                    .Select(g => new
                    {
                        CategoryName = g.Key.CategoryName,
                        PlannedAmount = g.Key.PlannedAmount,
                        TotalSpent = g.Sum(t => t.Amount)
                    })
                    .ToList();

                var totalSpentAll = groupedByCategory.Sum(g => g.TotalSpent);
                labelTotal.Text = _currentCategory == CategoryType.Minus
               ? $"Итого: {totalSpentAll:F2} руб."
               : $"Итого: {totalSpentAll:F2} руб.";

                var result = groupedByCategory.Select(g => new
                {
                    g.CategoryName,
                    Percent = $"{(totalSpentAll > 0 ? Math.Round((g.TotalSpent / totalSpentAll) * 100, 2) : 0)} %",
                    DisplayAmount = g.PlannedAmount.HasValue
                        ? (_currentPeriod == DatePeriod.Year || _currentPeriod == DatePeriod.Month ? $"{g.TotalSpent:F2} руб. из {(_currentPeriod == DatePeriod.Year ? 12 : 1) * g.PlannedAmount:F2} руб." : $"{g.TotalSpent:F2} руб.")
                        : $"{g.TotalSpent:F2} руб."
                }).ToList();


                dataGrid.DataSource = result;

                var chartData = result.Select(x => (x.CategoryName, x.Percent)).ToList();
                var donutChart = new DonutChart(chartData);
                donutChart.Dock = DockStyle.Fill;
                DiagramPanel.Controls.Clear();
                DiagramPanel.Controls.Add(donutChart);
            }
        }

        public MainControl()
        {
            InitializeComponent();
            //   dataGrid.CellPainting -= DataGrid_CellPainting; // защита от дублирования
            dataGrid.CellPainting += DataGrid_CellPainting;
            PeriodPanel.Visible = false;
            DatePickPanel.Visible = true;
            _endDate = DateTime.Now;
            _startDate = new DateTime(_endDate.Year, _endDate.Month, 1, 0, 0, 0);

            DateLabel.Text = $"{_endDate.ToString("MMMM")} {_endDate.Year} год";
            _currentPeriod = DatePeriod.Month;
            CurrentCategory = CategoryType.Minus;
            LoadData();
            SetActionForButtons();
            LeftArrow.Click += (s, e) => LeftArrowAction();
            RightArrow.Click += (s, e) => RightArrowAction();
            MinusBtn.Click += (s, e) =>
            {
                CurrentCategory = CategoryType.Minus;
                MinusBtn.BackColor = Color.FromArgb(251, 229, 214);
                PlusBtn.BackColor = SystemColors.ButtonHighlight;
            };
            PlusBtn.Click += (s, e) =>
            {
                CurrentCategory = CategoryType.Plus;
                PlusBtn.BackColor = Color.FromArgb(226, 240, 217);
                MinusBtn.BackColor = SystemColors.ButtonHighlight;
            };
            dateTimePicker1.ValueChanged += (s, e) =>
            {
                var start = dateTimePicker1.Value.Date;
                var end = dateTimePicker2.Value.Date;
                _startDate = new DateTime(start.Year, start.Month, start.Day, 0, 0, 0);
                _endDate = new DateTime(end.Year, end.Month, end.Day, 23, 59, 59);
                LoadData();
            };
            dateTimePicker2.ValueChanged += (s, e) =>
            {
                var start = dateTimePicker1.Value.Date;
                var end = dateTimePicker2.Value.Date;
                _startDate = new DateTime(start.Year, start.Month, start.Day, 0, 0, 0);
                _endDate = new DateTime(end.Year, end.Month, end.Day, 23, 59, 59);
                LoadData();
            };
            AddBtn.Click += (s, e) =>
            {
                if (CurrentCategory == CategoryType.Minus)
                    GlobalEvents.ShowAddControl(this, GlobalEvents.GetMinusAddControlHandler());
                else
                    GlobalEvents.ShowAddControl(this, GlobalEvents.GetPlusAddControlHandler());
            };
            TransControl.Click += (s, e) => GlobalEvents.ShowTransactionControl(this, CurrentCategory, _currentPeriod, _startDate, _endDate, PeriodPanel.Visible);

        }

        private void SetActionForButtons()
        {
            foreach (var btn in DatePanel.Controls)
                if (btn.GetType() == typeof(Button))
                    (btn as Button).Click += (s, e) => ChooseButton(s as Button);
        }
        private void ChooseButton(Button button)
        {
            foreach (var btn in DatePanel.Controls)
            {
                if (btn.GetType() == typeof(Button))
                    (btn as Button).BackColor = Color.FromArgb(255, 255, 255);
            }
            button.BackColor = Color.FromArgb(222, 235, 247);
            switch (button.Name)
            {
                case "DayBtn":
                    {
                        PeriodPanel.Visible = false;
                        DatePickPanel.Visible = true;
                        var now = DateTime.Now;
                        _startDate = new DateTime(now.Year, now.Month, now.Day, 0, 0, 0);
                        _endDate = new DateTime(now.Year, now.Month, now.Day, 23, 59, 59);
                        DateLabel.Text = $"{_startDate:dd MMMM} {_startDate.Year} год";
                        _currentPeriod = DatePeriod.Day;
                    }
                    break;
                case "WeekBtn":
                    {
                        PeriodPanel.Visible = false;
                        DatePickPanel.Visible = true;
                        var now = DateTime.Now;
                        int diffToMonday = (now.DayOfWeek - DayOfWeek.Monday + 7) % 7;
                        var monday = now.AddDays(-diffToMonday).Date;
                        _startDate = new DateTime(monday.Year, monday.Month, monday.Day, 0, 0, 0);
                        var sunday = _startDate.AddDays(6);
                        _endDate = new DateTime(sunday.Year, sunday.Month, sunday.Day, 23, 59, 59);
                        string weekStart = _startDate.ToString("dd MMMM");
                        string weekEnd = _endDate.ToString("dd MMMM");
                        DateLabel.Text = $"{weekStart} – {weekEnd} {_startDate.Year} года";
                        _currentPeriod = DatePeriod.Week;
                    }
                    break;
                case "MonthBtn":
                    {
                        PeriodPanel.Visible = false;
                        DatePickPanel.Visible = true;
                        var now = DateTime.Now;
                        _startDate = new DateTime(now.Year, now.Month, 1, 0, 0, 0);
                        int lastDay = DateTime.DaysInMonth(now.Year, now.Month);
                        _endDate = new DateTime(now.Year, now.Month, lastDay, 23, 59, 59);
                        DateLabel.Text = $"{_startDate:MMMM} {_startDate.Year} год";
                        _currentPeriod = DatePeriod.Month;
                    }
                    break;
                case "YearBtn":
                    {
                        PeriodPanel.Visible = false;
                        DatePickPanel.Visible = true;
                        var now = DateTime.Now;
                        _startDate = new DateTime(now.Year, 1, 1, 0, 0, 0);
                        _endDate = new DateTime(now.Year, 12, 31, 23, 59, 59);
                        DateLabel.Text = $"{now.Year} год";
                        _currentPeriod = DatePeriod.Year;
                    }
                    break;
                case "PeriodBtn":
                    {
                        PeriodPanel.Visible = true;
                        DatePickPanel.Visible = false;
                    }
                    break;
            }
            LoadData();
        }

        private void LeftArrowAction()
        {
            switch (_currentPeriod)
            {
                case DatePeriod.Day:
                    _endDate = _endDate.AddDays(-1);
                    _startDate = new DateTime(_endDate.Year, _endDate.Month, _endDate.Day, 0, 0, 0);
                    _endDate = new DateTime(_endDate.Year, _endDate.Month, _endDate.Day, 23, 59, 59);
                    DateLabel.Text = $"{_startDate:dd MMMM} {_startDate.Year} год";
                    break;

                case DatePeriod.Week:
                    _endDate = _endDate.AddDays(-7);
                    int diff = (_endDate.DayOfWeek - DayOfWeek.Monday + 7) % 7;
                    _startDate = _endDate.AddDays(-diff).Date;
                    _startDate = new DateTime(_startDate.Year, _startDate.Month, _startDate.Day, 0, 0, 0);
                    _endDate = _startDate.AddDays(6);
                    _endDate = new DateTime(_endDate.Year, _endDate.Month, _endDate.Day, 23, 59, 59);
                    DateLabel.Text = $"{_startDate:dd MMMM} – {_endDate:dd MMMM} {_startDate.Year} года";
                    break;

                case DatePeriod.Month:
                    _endDate = _endDate.AddMonths(-1);
                    _startDate = new DateTime(_endDate.Year, _endDate.Month, 1, 0, 0, 0);
                    var lastDay = DateTime.DaysInMonth(_endDate.Year, _endDate.Month);
                    _endDate = new DateTime(_endDate.Year, _endDate.Month, lastDay, 23, 59, 59);
                    DateLabel.Text = $"{_startDate:MMMM} {_startDate.Year} год";
                    break;

                case DatePeriod.Year:
                    _endDate = _endDate.AddYears(-1);
                    _startDate = new DateTime(_endDate.Year, 1, 1, 0, 0, 0);
                    _endDate = new DateTime(_endDate.Year, 12, 31, 23, 59, 59);
                    DateLabel.Text = $"{_startDate.Year} год";
                    break;
            }
            LoadData();
        }
        private void RightArrowAction()
        {
            switch (_currentPeriod)
            {
                case DatePeriod.Day:
                    _endDate = _endDate.AddDays(1);
                    _startDate = new DateTime(_endDate.Year, _endDate.Month, _endDate.Day, 0, 0, 0);
                    _endDate = new DateTime(_endDate.Year, _endDate.Month, _endDate.Day, 23, 59, 59);
                    DateLabel.Text = $"{_startDate:dd MMMM} {_startDate.Year} год";
                    break;

                case DatePeriod.Week:
                    _endDate = _endDate.AddDays(7);
                    int diff = (_endDate.DayOfWeek - DayOfWeek.Monday + 7) % 7;
                    _startDate = _endDate.AddDays(-diff).Date;
                    _startDate = new DateTime(_startDate.Year, _startDate.Month, _startDate.Day, 0, 0, 0);
                    _endDate = _startDate.AddDays(6);
                    _endDate = new DateTime(_endDate.Year, _endDate.Month, _endDate.Day, 23, 59, 59);
                    DateLabel.Text = $"{_startDate:dd MMMM} – {_endDate:dd MMMM} {_startDate.Year} года";
                    break;

                case DatePeriod.Month:
                    _endDate = _endDate.AddMonths(1);
                    _startDate = new DateTime(_endDate.Year, _endDate.Month, 1, 0, 0, 0);
                    var lastDay = DateTime.DaysInMonth(_endDate.Year, _endDate.Month);
                    _endDate = new DateTime(_endDate.Year, _endDate.Month, lastDay, 23, 59, 59);
                    DateLabel.Text = $"{_startDate:MMMM} {_startDate.Year} год";
                    break;

                case DatePeriod.Year:
                    _endDate = _endDate.AddYears(1);
                    _startDate = new DateTime(_endDate.Year, 1, 1, 0, 0, 0);
                    _endDate = new DateTime(_endDate.Year, 12, 31, 23, 59, 59);
                    DateLabel.Text = $"{_startDate.Year} год";
                    break;
            }
            LoadData();
        }
        private void DataGrid_CellPainting(object sender, DataGridViewCellPaintingEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex >= 0 && dataGrid.Columns[e.ColumnIndex].HeaderText == "Сумма")
            {
                e.Handled = true;
                e.PaintBackground(e.CellBounds, true);

                var value = e.FormattedValue?.ToString();
                if (string.IsNullOrWhiteSpace(value))
                    return;

                var graphics = e.Graphics;
                var parts = value.Split(new[] { " из " }, StringSplitOptions.None);

                using var font = e.CellStyle.Font;
                var textColor = e.CellStyle.ForeColor;

                var spentText = parts[0]; // потрачено
                var plannedText = parts.Length > 1 ? "из " + parts[1] : string.Empty; // планируемая сумма

                // Вычисляем ширину первой части текста
                var spentSize = TextRenderer.MeasureText(spentText, font);
                var plannedSize = TextRenderer.MeasureText(plannedText, font);

                // Координаты
                var totalWidth = spentSize.Width + plannedSize.Width + 4;
                var startX = e.CellBounds.X + (e.CellBounds.Width - totalWidth) / 2;
                var startY = e.CellBounds.Y + (e.CellBounds.Height - spentSize.Height) / 2;

                // Отрисовка потраченной суммы
                TextRenderer.DrawText(graphics, spentText, font, new Point(startX, startY), textColor);

                // Вычисление чисел из текста для сравнения
                if (parts.Length > 1 &&
                    decimal.TryParse(parts[0].Replace(" руб.", "").Trim(), out var spent) &&
                    decimal.TryParse(parts[1].Replace(" руб.", "").Trim(), out var planned))
                {
                    Color plannedColor = spent > planned ? Color.LightCoral : Color.Gray;

                    // Отрисовка планируемой суммы
                    TextRenderer.DrawText(graphics, plannedText, font,
                        new Point(startX + spentSize.Width + 4, startY), plannedColor);
                }
                else
                {
                    // Если нет планируемой суммы, отрисовать как обычно
                    TextRenderer.DrawText(graphics, plannedText, font,
                        new Point(startX + spentSize.Width + 4, startY), textColor);
                }

                e.Paint(e.ClipBounds, DataGridViewPaintParts.Border);
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void DateLabel_Click(object sender, EventArgs e)
        {

        }

        private void MainControl_Load(object sender, EventArgs e)
        {

        }
    }

    public enum DatePeriod
    {
        Day,
        Week,
        Month,
        Year
    }
}
