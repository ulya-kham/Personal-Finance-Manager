﻿using shershulya22.Models;
using System.ComponentModel;
using System.Data;

namespace shershulya22.Controls
{
    public partial class TransactionControl: UserControl
    {
        private List<TransactionDTO> _transactions;
        private DatePeriod _currentPeriod;
        private CategoryType _currentCategory;
        private CategoryType CurrentCategory
        {
            get => _currentCategory;
            set
            {
                _currentCategory = value;
                LoadData();
            }
        }
        private DateTime _startDate;
        private DateTime _endDate;

        private async Task LoadData()
        {
            _transactions =  await Loader.Instance.TransactionRepository.GetTransactions(Program.CurrentUser, CurrentCategory, _startDate, _endDate);
            dataGrid.DataSource = ToDataTable(_transactions);
        }
        private DataTable ToDataTable<T>(List<T> items)
        {
            var table = new DataTable(typeof(T).Name);
            var props = TypeDescriptor.GetProperties(typeof(T));

            foreach (PropertyDescriptor prop in props)
                table.Columns.Add(prop.Name, Nullable.GetUnderlyingType(prop.PropertyType) ?? prop.PropertyType);

            foreach (T item in items)
            {
                var row = table.NewRow();
                foreach (PropertyDescriptor prop in props)
                    row[prop.Name] = prop.GetValue(item) ?? DBNull.Value;
                table.Rows.Add(row);
            }

            return table;
        }
        public TransactionControl(CategoryType type, DatePeriod period, DateTime start, DateTime end, bool isPeriod)
        {
            InitializeComponent();
            PeriodPanel.Visible = isPeriod;
            DatePickPanel.Visible = !isPeriod;
            _endDate = end;
            _startDate = start;
            _currentPeriod = period;
            CurrentCategory = type;
            DateLabel.Text = $"{_endDate.ToString("MMMM")} {_endDate.Year} год";
            
            LoadData();
            SetActionForButtons();
            textBox1.TextChanged += async (s, e) =>
            {
                string filterText = textBox1.Text.Trim();
                if (!string.IsNullOrEmpty(filterText))
                {
                    _transactions = await Loader.Instance.TransactionRepository.GetTransactions(Program.CurrentUser, CurrentCategory, _startDate, _endDate, filterText);
                    dataGrid.DataSource = ToDataTable(_transactions);
                }
                else
                {
                    _transactions = await Loader.Instance.TransactionRepository.GetTransactions(Program.CurrentUser, CurrentCategory, _startDate, _endDate);
                    dataGrid.DataSource = ToDataTable(_transactions);
                }
            };
            LeftArrow.Click += (s, e) => LeftArrowAction();
            RightArrow.Click += (s, e) => RightArrowAction();
            MinusBtn.Click += (s, e) =>
            {
                CurrentCategory = CategoryType.Minus;
                MinusBtn.BackColor = Color.FromArgb(251, 229, 214);
                PlusBtn.BackColor = SystemColors.ButtonHighlight;
            };
            PlusBtn.Click += (s, e) =>
            {
                CurrentCategory = CategoryType.Plus;
                PlusBtn.BackColor = Color.FromArgb(226, 240, 217);
                MinusBtn.BackColor = SystemColors.ButtonHighlight;
            };
            dateTimePicker1.ValueChanged += async (s, e) =>
            {
                var start = dateTimePicker1.Value.Date;
                var end = dateTimePicker2.Value.Date;
                _startDate = new DateTime(start.Year, start.Month, start.Day, 0, 0, 0);
                _endDate = new DateTime(end.Year, end.Month, end.Day, 23, 59, 59);
                await LoadData();
            };
            dateTimePicker2.ValueChanged += async (s, e) =>
            {
                var start = dateTimePicker1.Value.Date;
                var end = dateTimePicker2.Value.Date;
                _startDate = new DateTime(start.Year, start.Month, start.Day, 0, 0, 0);
                _endDate = new DateTime(end.Year, end.Month, end.Day, 23, 59, 59);
                await LoadData();
            };
            AddBtn.Click += (s, e) => 
            {
                ExcelHelper.Create(_transactions);
            };

        }

        private void SetActionForButtons()
        {
            foreach (var btn in DatePanel.Controls)
                if (btn.GetType() == typeof(Button))
                    (btn as Button).Click += (s, e) => ChooseButton(s as Button);
        }
        private void ChooseButton(Button button)
        {
            foreach (var btn in DatePanel.Controls)
            {
                if (btn.GetType() == typeof(Button))
                    (btn as Button).BackColor = Color.FromArgb(255, 255, 255);
            }
            button.BackColor = Color.FromArgb(222, 235, 247);
            switch (button.Name)
            {
                case "DayBtn":
                    {
                        PeriodPanel.Visible = false;
                        DatePickPanel.Visible = true;
                        var now = DateTime.Now;
                        _startDate = new DateTime(now.Year, now.Month, now.Day, 0, 0, 0);
                        _endDate = new DateTime(now.Year, now.Month, now.Day, 23, 59, 59);
                        DateLabel.Text = $"{_startDate:dd MMMM} {_startDate.Year} год";
                        _currentPeriod = DatePeriod.Day;
                    }
                    break;
                case "WeekBtn":
                    {
                        PeriodPanel.Visible = false;
                        DatePickPanel.Visible = true;
                        var now = DateTime.Now;
                        int diffToMonday = (now.DayOfWeek - DayOfWeek.Monday + 7) % 7;
                        var monday = now.AddDays(-diffToMonday).Date;
                        _startDate = new DateTime(monday.Year, monday.Month, monday.Day, 0, 0, 0);
                        var sunday = _startDate.AddDays(6);
                        _endDate = new DateTime(sunday.Year, sunday.Month, sunday.Day, 23, 59, 59);
                        string weekStart = _startDate.ToString("dd MMMM");
                        string weekEnd = _endDate.ToString("dd MMMM");
                        DateLabel.Text = $"{weekStart} – {weekEnd} {_startDate.Year} года";
                        _currentPeriod = DatePeriod.Week;
                    }
                    break;
                case "MonthBtn":
                    {
                        PeriodPanel.Visible = false;
                        DatePickPanel.Visible = true;
                        var now = DateTime.Now;
                        _startDate = new DateTime(now.Year, now.Month, 1, 0, 0, 0);
                        int lastDay = DateTime.DaysInMonth(now.Year, now.Month);
                        _endDate = new DateTime(now.Year, now.Month, lastDay, 23, 59, 59);
                        DateLabel.Text = $"{_startDate:MMMM} {_startDate.Year} год";
                        _currentPeriod = DatePeriod.Month;
                    }
                    break;
                case "YearBtn":
                    {
                        PeriodPanel.Visible = false;
                        DatePickPanel.Visible = true;
                        var now = DateTime.Now;
                        _startDate = new DateTime(now.Year, 1, 1, 0, 0, 0);
                        _endDate = new DateTime(now.Year, 12, 31, 23, 59, 59);
                        DateLabel.Text = $"{now.Year} год";
                        _currentPeriod = DatePeriod.Year;
                    }
                    break;
                case "PeriodBtn":
                    {
                        PeriodPanel.Visible = true;
                        DatePickPanel.Visible = false;
                    }
                    break;
            }
            LoadData();
        }

        private void LeftArrowAction()
        {
            switch (_currentPeriod)
            {
                case DatePeriod.Day:
                    _endDate = _endDate.AddDays(-1);
                    _startDate = new DateTime(_endDate.Year, _endDate.Month, _endDate.Day, 0, 0, 0);
                    _endDate = new DateTime(_endDate.Year, _endDate.Month, _endDate.Day, 23, 59, 59);
                    DateLabel.Text = $"{_startDate:dd MMMM} {_startDate.Year} год";
                    break;

                case DatePeriod.Week:
                    _endDate = _endDate.AddDays(-7);
                    int diff = (_endDate.DayOfWeek - DayOfWeek.Monday + 7) % 7;
                    _startDate = _endDate.AddDays(-diff).Date;
                    _startDate = new DateTime(_startDate.Year, _startDate.Month, _startDate.Day, 0, 0, 0);
                    _endDate = _startDate.AddDays(6);
                    _endDate = new DateTime(_endDate.Year, _endDate.Month, _endDate.Day, 23, 59, 59);
                    DateLabel.Text = $"{_startDate:dd MMMM} – {_endDate:dd MMMM} {_startDate.Year} года";
                    break;

                case DatePeriod.Month:
                    _endDate = _endDate.AddMonths(-1);
                    _startDate = new DateTime(_endDate.Year, _endDate.Month, 1, 0, 0, 0);
                    var lastDay = DateTime.DaysInMonth(_endDate.Year, _endDate.Month);
                    _endDate = new DateTime(_endDate.Year, _endDate.Month, lastDay, 23, 59, 59);
                    DateLabel.Text = $"{_startDate:MMMM} {_startDate.Year} год";
                    break;

                case DatePeriod.Year:
                    _endDate = _endDate.AddYears(-1);
                    _startDate = new DateTime(_endDate.Year, 1, 1, 0, 0, 0);
                    _endDate = new DateTime(_endDate.Year, 12, 31, 23, 59, 59);
                    DateLabel.Text = $"{_startDate.Year} год";
                    break;
            }
            LoadData();
        }
        private void RightArrowAction()
        {
            switch (_currentPeriod)
            {
                case DatePeriod.Day:
                    _endDate = _endDate.AddDays(1);
                    _startDate = new DateTime(_endDate.Year, _endDate.Month, _endDate.Day, 0, 0, 0);
                    _endDate = new DateTime(_endDate.Year, _endDate.Month, _endDate.Day, 23, 59, 59);
                    DateLabel.Text = $"{_startDate:dd MMMM} {_startDate.Year} год";
                    break;

                case DatePeriod.Week:
                    _endDate = _endDate.AddDays(7);
                    int diff = (_endDate.DayOfWeek - DayOfWeek.Monday + 7) % 7;
                    _startDate = _endDate.AddDays(-diff).Date;
                    _startDate = new DateTime(_startDate.Year, _startDate.Month, _startDate.Day, 0, 0, 0);
                    _endDate = _startDate.AddDays(6);
                    _endDate = new DateTime(_endDate.Year, _endDate.Month, _endDate.Day, 23, 59, 59);
                    DateLabel.Text = $"{_startDate:dd MMMM} – {_endDate:dd MMMM} {_startDate.Year} года";
                    break;

                case DatePeriod.Month:
                    _endDate = _endDate.AddMonths(1);
                    _startDate = new DateTime(_endDate.Year, _endDate.Month, 1, 0, 0, 0);
                    var lastDay = DateTime.DaysInMonth(_endDate.Year, _endDate.Month);
                    _endDate = new DateTime(_endDate.Year, _endDate.Month, lastDay, 23, 59, 59);
                    DateLabel.Text = $"{_startDate:MMMM} {_startDate.Year} год";
                    break;

                case DatePeriod.Year:
                    _endDate = _endDate.AddYears(1);
                    _startDate = new DateTime(_endDate.Year, 1, 1, 0, 0, 0);
                    _endDate = new DateTime(_endDate.Year, 12, 31, 23, 59, 59);
                    DateLabel.Text = $"{_startDate.Year} год";
                    break;
            }
            LoadData();
        }
    }
}
