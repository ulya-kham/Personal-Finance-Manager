﻿using shershulya22.Models;
using System.Security.Cryptography.Xml;

namespace shershulya22.Controls
{
    public partial class AddPlus : UserControl
    {
        public AddPlus()
        {
            InitializeComponent();
            Load += async (s, e) => await LoadData();
            textBox2.TextChanged += (s, e) => textBox2.Text.Replace('.', ',');
            pictureBox1.Click += (s, e) => Close();
            AddBtn.Click += async (s, e) =>
            {
                var canParse = decimal.TryParse(textBox2.Text, out decimal amount);
                if (!canParse && !string.IsNullOrEmpty(textBox2.Text))
                {
                    MessageBox.Show("Не могу понять сумму!");
                    return;
                }
                if (amount <= 0)
                {
                    MessageBox.Show("Сумма должна быть положительна");
                    return;
                }
                var transaction = new TransactionEntity
                {
                    CategoryId = Guid.Parse(comboBox3.SelectedValue.ToString()),
                    Comment = textBox3.Text,
                    Amount = amount,
                    UserId = Program.CurrentUser,
                    AccountId = Guid.Parse(comboBox1.SelectedValue.ToString()),
                    Type = CategoryType.Plus,
                    Date = dateTimePicker1.Value
                };
                await Loader.Instance.TransactionRepository.Add(transaction);
                GlobalEvents.ChangeBalance(this, transaction.AccountId, transaction.Amount);
                GlobalEvents.ShowMainControl(this);
            };
        }
        private void Close()
        {
            var dialog = MessageBox.Show("Вы уверены, что хотите уйти с Добавление доходов?", "Предупреждение", MessageBoxButtons.YesNo);
            if (dialog != DialogResult.Yes)
                return;
            GlobalEvents.ShowMainControl(this);
        }
        private async Task LoadData()
        {
            var accounts = await Loader.Instance.AccountRepository.GetAllForUser(Program.CurrentUser);
            var categories = await Loader.Instance.CategoryRepository.GetAllForUserByType(Program.CurrentUser, CategoryType.Plus);

            comboBox1.DataSource = accounts;
            comboBox1.DisplayMember = "Name";
            comboBox1.ValueMember = "Id";

            comboBox3.DataSource = categories;
            comboBox3.DisplayMember = "CategoryName";
            comboBox3.ValueMember = "Id";
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
