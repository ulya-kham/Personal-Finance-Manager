﻿namespace shershulya22.Controls
{
    partial class CreateRecurringPayment
    {
        /// <summary> 
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CreateRecurringPayment));
            pictureBox1 = new PictureBox();
            label1 = new Label();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            textBox3 = new TextBox();
            comboBox1 = new ComboBox();
            comboBox2 = new ComboBox();
            comboBox3 = new ComboBox();
            dateTimePicker1 = new DateTimePicker();
            dateTimePicker2 = new DateTimePicker();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            checkBox1 = new CheckBox();
            DeleteBtn = new Button();
            AddBtn = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(9, 4);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(48, 48);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 4;
            pictureBox1.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Century Gothic", 26.25F, FontStyle.Bold);
            label1.Location = new Point(157, 39);
            label1.Name = "label1";
            label1.Size = new Size(586, 41);
            label1.TabIndex = 3;
            label1.Text = "Создание регулярного платежа";
            // 
            // textBox1
            // 
            textBox1.Font = new Font("Century Gothic", 15.75F);
            textBox1.Location = new Point(170, 101);
            textBox1.Name = "textBox1";
            textBox1.PlaceholderText = "Наименование платежа";
            textBox1.Size = new Size(553, 33);
            textBox1.TabIndex = 5;
            // 
            // textBox2
            // 
            textBox2.Font = new Font("Century Gothic", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 204);
            textBox2.Location = new Point(170, 378);
            textBox2.Name = "textBox2";
            textBox2.PlaceholderText = "Сумма платежа";
            textBox2.Size = new Size(553, 33);
            textBox2.TabIndex = 6;
            // 
            // textBox3
            // 
            textBox3.Font = new Font("Century Gothic", 15.75F);
            textBox3.Location = new Point(170, 601);
            textBox3.Name = "textBox3";
            textBox3.PlaceholderText = "Комментарий";
            textBox3.Size = new Size(553, 33);
            textBox3.TabIndex = 7;
            // 
            // comboBox1
            // 
            comboBox1.Font = new Font("Century Gothic", 15.75F);
            comboBox1.FormattingEnabled = true;
            comboBox1.Location = new Point(170, 173);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(553, 32);
            comboBox1.TabIndex = 8;
            // 
            // comboBox2
            // 
            comboBox2.Font = new Font("Century Gothic", 15.75F);
            comboBox2.FormattingEnabled = true;
            comboBox2.Location = new Point(170, 245);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(553, 32);
            comboBox2.TabIndex = 9;
            // 
            // comboBox3
            // 
            comboBox3.Font = new Font("Century Gothic", 15.75F);
            comboBox3.FormattingEnabled = true;
            comboBox3.Location = new Point(170, 323);
            comboBox3.Name = "comboBox3";
            comboBox3.Size = new Size(553, 32);
            comboBox3.TabIndex = 10;
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Font = new Font("Century Gothic", 15.75F);
            dateTimePicker1.Location = new Point(170, 458);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(281, 33);
            dateTimePicker1.TabIndex = 11;
            // 
            // dateTimePicker2
            // 
            dateTimePicker2.Enabled = false;
            dateTimePicker2.Font = new Font("Century Gothic", 15.75F);
            dateTimePicker2.Location = new Point(170, 541);
            dateTimePicker2.Name = "dateTimePicker2";
            dateTimePicker2.Size = new Size(281, 33);
            dateTimePicker2.TabIndex = 12;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Century Gothic", 15.75F);
            label2.Location = new Point(170, 146);
            label2.Name = "label2";
            label2.Size = new Size(59, 24);
            label2.TabIndex = 13;
            label2.Text = "Счет";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Century Gothic", 15.75F);
            label3.Location = new Point(170, 218);
            label3.Name = "label3";
            label3.Size = new Size(174, 24);
            label3.TabIndex = 14;
            label3.Text = "Периодичность";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Century Gothic", 15.75F);
            label4.Location = new Point(170, 296);
            label4.Name = "label4";
            label4.Size = new Size(116, 24);
            label4.TabIndex = 15;
            label4.Text = "Категория";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Century Gothic", 15.75F);
            label5.Location = new Point(170, 431);
            label5.Name = "label5";
            label5.Size = new Size(245, 24);
            label5.TabIndex = 16;
            label5.Text = "Дата начала действия";
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.Font = new Font("Century Gothic", 15.75F);
            checkBox1.Location = new Point(170, 507);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(298, 28);
            checkBox1.TabIndex = 17;
            checkBox1.Text = "Дата окончания действия";
            checkBox1.UseVisualStyleBackColor = true;
            // 
            // DeleteBtn
            // 
            DeleteBtn.BackColor = Color.FromArgb(251, 229, 214);
            DeleteBtn.FlatStyle = FlatStyle.Flat;
            DeleteBtn.Font = new Font("Century Gothic", 20.25F);
            DeleteBtn.Location = new Point(507, 663);
            DeleteBtn.Name = "DeleteBtn";
            DeleteBtn.Size = new Size(200, 50);
            DeleteBtn.TabIndex = 19;
            DeleteBtn.Text = "Удалить";
            DeleteBtn.UseVisualStyleBackColor = false;
            DeleteBtn.Visible = false;
            // 
            // AddBtn
            // 
            AddBtn.BackColor = Color.FromArgb(226, 240, 217);
            AddBtn.FlatStyle = FlatStyle.Flat;
            AddBtn.Font = new Font("Century Gothic", 20.25F);
            AddBtn.Location = new Point(170, 663);
            AddBtn.Name = "AddBtn";
            AddBtn.Size = new Size(280, 50);
            AddBtn.TabIndex = 18;
            AddBtn.Text = "Добавить платеж";
            AddBtn.UseVisualStyleBackColor = false;
            // 
            // CreateRecurringPayment
            // 
            AutoScaleMode = AutoScaleMode.None;
            BackColor = Color.White;
            Controls.Add(DeleteBtn);
            Controls.Add(AddBtn);
            Controls.Add(checkBox1);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(dateTimePicker2);
            Controls.Add(dateTimePicker1);
            Controls.Add(comboBox3);
            Controls.Add(comboBox2);
            Controls.Add(comboBox1);
            Controls.Add(textBox3);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(pictureBox1);
            Controls.Add(label1);
            Font = new Font("Century Gothic", 18F, FontStyle.Regular, GraphicsUnit.Point, 204);
            Name = "CreateRecurringPayment";
            Size = new Size(886, 744);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private Label label1;
        private TextBox textBox1;
        private TextBox textBox2;
        private TextBox textBox3;
        private ComboBox comboBox1;
        private ComboBox comboBox2;
        private ComboBox comboBox3;
        private DateTimePicker dateTimePicker1;
        private DateTimePicker dateTimePicker2;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private CheckBox checkBox1;
        private Button DeleteBtn;
        private Button AddBtn;
    }
}
