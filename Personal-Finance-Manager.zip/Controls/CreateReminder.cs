﻿using shershulya22.Models;

namespace shershulya22.Controls
{
    public partial class CreateReminder: UserControl
    {
        private ReminderEntity _reminderEntity;
        public CreateReminder()
        {
            InitializeComponent();
            Load += (s, e) =>
            {
                comboBox1.DataSource = EnumHelper.GetEnumListWithDescription(typeof(Frequency));
                comboBox1.DisplayMember = "Value";
                comboBox1.ValueMember = "Key";
            };
            pictureBox1.Click += (s, e) => Close();
            AddBtn.Click += async (s, e) => await Add();
        }
        public CreateReminder(Guid reminderId)
        {
            InitializeComponent();
            Load += async (s, e) =>
            {
                _reminderEntity = await Loader.Instance.ReminderRepository.GetById(reminderId);
                comboBox1.DataSource = EnumHelper.GetEnumListWithDescription(typeof(Frequency));
                comboBox1.DisplayMember = "Value";
                comboBox1.ValueMember = "Key";

                textBox1.Text = _reminderEntity.Name;
                textBox2.Text = _reminderEntity.Comment;
                dateTimePicker1.Value = _reminderEntity.StartDate;
                comboBox1.SelectedValue = _reminderEntity.Frequency;
            };
            pictureBox1.Click += (s, e) => Close();
            AddBtn.Click += async (s, e) => await Update();

            
            DeleteBtn.Click += async (s, e) =>
            {
                var dialog = MessageBox.Show("Вы уверены, что хотите удалить напоминание?", "Предупреждение", MessageBoxButtons.YesNo);
                if (dialog != DialogResult.Yes)
                    return;
                await Loader.Instance.ReminderRepository.Delete(reminderId);
                GlobalEvents.ShowRecPaymentControl(this);
            };
            DeleteBtn.Visible = true;
            AddBtn.Text = "Редактировать напоминание";
            label1.Text = "Редактировать напоминание";
        }

        private void Close()
        {
            var dialog = MessageBox.Show("Вы уверены, что хотите уйти с Создание напоминания?", "Предупреждение", MessageBoxButtons.YesNo);
            if (dialog != DialogResult.Yes)
                return;
            GlobalEvents.ShowReminderControl(this);
        }
        private async Task Add()
        {
            if (string.IsNullOrEmpty(textBox1.Text))
            {
                MessageBox.Show("Заполните имя напоминания");
                return;
            }
            var category = new ReminderEntity
            {
                Name = textBox1.Text,
                Comment = textBox2.Text,
                UserId = Program.CurrentUser,
                Frequency = (Frequency)comboBox1.SelectedValue,
                StartDate = dateTimePicker1.Value,
            };
            await Loader.Instance.ReminderRepository.Add(category);
            GlobalEvents.ShowReminderControl(this);
        }
        private async Task Update()
        {
            var dialog = MessageBox.Show("Вы уверены, что хотите изменить напоминание?", "Предупреждение", MessageBoxButtons.YesNo);
            if (dialog != DialogResult.Yes)
                return;
            if (string.IsNullOrEmpty(textBox1.Text))
            {
                MessageBox.Show("Заполните имя напоминания");
                return;
            }

            var category = new ReminderEntity
            {
                Id = _reminderEntity.Id,
                Name = textBox1.Text,
                Comment = textBox2.Text,
                Frequency = (Frequency)comboBox1.SelectedValue,
                StartDate = dateTimePicker1.Value,
            };
            await Loader.Instance.ReminderRepository.Update(category);
            GlobalEvents.ShowReminderControl(this);
        }
    }
}
