﻿using shershulya22.Models;

namespace shershulya22.Controls
{
    public partial class AddAccount: UserControl
    {
        private AccountEntity? _accountEntity;
        public AddAccount()
        {
            InitializeComponent();

            pictureBox1.Click += (s, e) => Close();
            SumTB.TextChanged += (s, e) => SumTB.Text = SumTB.Text.Replace('.', ',');
            AddBtn.Click += async (s, e) => await Add();
        }
        public AddAccount(Guid accountID)
        {
            InitializeComponent();
            Load += async (s, e) =>
            {
                AddBtn.Text = "Изменить счет";
                DeleteBtn.Visible = true;
                _accountEntity = await Loader.Instance.AccountRepository.GetById(accountID);
                if (_accountEntity == null)
                {
                    MessageBox.Show("Ошибка. Счет не найден");
                    GlobalEvents.ShowAccountControl(this);
                    return;
                }
                NameTB.Text = _accountEntity.Name;
                SumTB.Text = _accountEntity.Balance.ToString();
                checkBox1.Checked = _accountEntity.IsPublic;
            };
            pictureBox1.Click += (s, e) => Close();
            SumTB.TextChanged += (s, e) => SumTB.Text = SumTB.Text.Replace('.', ',');
            AddBtn.Click += async (s, e) => await Update();
            DeleteBtn.Click += async (s, e) =>
            {
                var dialog = MessageBox.Show("Вы уверены, что хотите удалить данный счет?", "Предупреждение", MessageBoxButtons.YesNo);
                if (dialog != DialogResult.Yes)
                    return;
                await Loader.Instance.AccountRepository.Delete(accountID);
                GlobalEvents.ShowAccountControl(this);
            };
        }
        private void Close()
        {
            var dialog = MessageBox.Show("Вы уверены, что хотите уйти с Добавление счета?", "Предупреждение", MessageBoxButtons.YesNo);
            if (dialog != DialogResult.Yes)
                return;
            GlobalEvents.ShowAccountControl(this);
        }
        private async Task Add()
        {
            if (string.IsNullOrEmpty(SumTB.Text) || string.IsNullOrEmpty(NameTB.Text))
            {
                MessageBox.Show("Заполните все поля");
                return;
            }
            var canParse = decimal.TryParse(SumTB.Text, out decimal amount);
            if (!canParse)
            {
                MessageBox.Show("Не могу понять сумму!");
                return;
            }
            if (amount <= 0)
            {
                MessageBox.Show("Сумма должна быть положительна");
                return;
            }
            var account = new AccountEntity
            {
                Name = NameTB.Text,
                Balance = amount,
                IsPublic = checkBox1.Checked,
                UserId = Program.CurrentUser
            };
            await Loader.Instance.AccountRepository.Add(account);
            GlobalEvents.ShowAccountControl(this);
        }
        private async Task Update()
        {
            if (string.IsNullOrEmpty(SumTB.Text) || string.IsNullOrEmpty(NameTB.Text))
            {
                MessageBox.Show("Заполните все поля");
                return;
            }
            var amount = decimal.Parse(SumTB.Text);
            var account = new AccountEntity
            {
                Id = _accountEntity!.Id,
                Name = NameTB.Text,
                Balance = amount,
                IsPublic = checkBox1.Checked
            };
            await Loader.Instance.AccountRepository.Update(account);
            if (amount != _accountEntity.Balance)
            {
                var difference = amount - _accountEntity.Balance;
                var transfer = new TransferEntity
                {
                    UserId = Program.CurrentUser,
                    Amount = difference,
                    Date = DateTime.Now,
                    FromAccountId = account.Id,
                    ToAccountId = account.Id,
                    Description = "Корректировка счета"
                };
                await Loader.Instance.TransferRepository.Add(transfer);
            }
            GlobalEvents.RecalculateBalance(this);
            GlobalEvents.ShowAccountControl(this);
        }
    }
}
