﻿namespace shershulya22.Controls
{
    public partial class SettingsControl: UserControl
    {
        public SettingsControl()
        {
            InitializeComponent();

            NameBtn.Click += async (s, e) =>
            {
                var dialog = MessageBox.Show("Вы уверенны, что хотите изменить имя пользователя?", "Предупреждение", MessageBoxButtons.YesNo);
                if (dialog != DialogResult.Yes)
                    return;
                if(string.IsNullOrEmpty(textBox1.Text))
                {
                    MessageBox.Show("Заполните поле имя");
                    return;
                }
                await Loader.Instance.UserRepository.UpdateName(Program.CurrentUser, textBox1.Text);
                GlobalEvents.ChangeName(this);
                textBox1.Text = string.Empty;
            };
            PasswordBtn.Click += async (s, e) =>
            {
                var dialog = MessageBox.Show("Вы уверенны, что хотите изменить пароль?", "Предупреждение", MessageBoxButtons.YesNo);
                if (dialog != DialogResult.Yes)
                    return;
                if (string.IsNullOrEmpty(textBox2.Text))
                {
                    MessageBox.Show("Заполните поле пароля");
                    return;
                }
                await Loader.Instance.UserRepository.UpdatePassword(Program.CurrentUser, textBox2.Text);
                textBox2.Text = string.Empty;
            };
            ExitBtn.Click += async (s, e) =>
            {
                var dialog = MessageBox.Show("Вы уверенны, что хотите выйти из профиля?", "Предупреждение", MessageBoxButtons.YesNo);
                if (dialog != DialogResult.Yes)
                    return;

                Application.OpenForms["LoginForm"]?.Show();
                Application.OpenForms["MainForm"]?.Close();
            };
        }
    }
}
