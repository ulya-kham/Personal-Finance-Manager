﻿namespace shershulya22.Controls
{
    partial class CategoryControl
    {
        /// <summary> 
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            label1 = new Label();
            AddBtn = new Button();
            MinusBtn = new Button();
            PlusBtn = new Button();
            dataGrid = new DataGridView();
            idDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            categoryNameDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            plannedAmountDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            categoryDTOBindingSource = new BindingSource(components);
            ((System.ComponentModel.ISupportInitialize)dataGrid).BeginInit();
            ((System.ComponentModel.ISupportInitialize)categoryDTOBindingSource).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Century Gothic", 26.25F, FontStyle.Bold);
            label1.Location = new Point(351, 36);
            label1.Name = "label1";
            label1.Size = new Size(205, 41);
            label1.TabIndex = 1;
            label1.Text = "Категории";
            // 
            // AddBtn
            // 
            AddBtn.BackColor = Color.FromArgb(226, 240, 217);
            AddBtn.FlatStyle = FlatStyle.Flat;
            AddBtn.Font = new Font("Century Gothic", 20.25F);
            AddBtn.Location = new Point(290, 659);
            AddBtn.Name = "AddBtn";
            AddBtn.Size = new Size(316, 50);
            AddBtn.TabIndex = 14;
            AddBtn.Text = "Добавить категорию";
            AddBtn.UseVisualStyleBackColor = false;
            // 
            // MinusBtn
            // 
            MinusBtn.BackColor = Color.FromArgb(251, 229, 214);
            MinusBtn.FlatAppearance.BorderSize = 0;
            MinusBtn.FlatStyle = FlatStyle.Flat;
            MinusBtn.Font = new Font("Century Gothic", 20.25F);
            MinusBtn.Location = new Point(103, 80);
            MinusBtn.Name = "MinusBtn";
            MinusBtn.Size = new Size(214, 49);
            MinusBtn.TabIndex = 15;
            MinusBtn.Text = "Расходы";
            MinusBtn.UseVisualStyleBackColor = false;
            // 
            // PlusBtn
            // 
            PlusBtn.BackColor = SystemColors.ControlLightLight;
            PlusBtn.FlatAppearance.BorderSize = 0;
            PlusBtn.FlatStyle = FlatStyle.Flat;
            PlusBtn.Font = new Font("Century Gothic", 20.25F);
            PlusBtn.Location = new Point(560, 80);
            PlusBtn.Name = "PlusBtn";
            PlusBtn.Size = new Size(214, 49);
            PlusBtn.TabIndex = 16;
            PlusBtn.Text = "Доходы";
            PlusBtn.UseVisualStyleBackColor = false;
            // 
            // dataGrid
            // 
            dataGrid.AutoGenerateColumns = false;
            dataGrid.BackgroundColor = Color.White;
            dataGrid.BorderStyle = BorderStyle.None;
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = SystemColors.Control;
            dataGridViewCellStyle1.Font = new Font("Century Gothic", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 204);
            dataGridViewCellStyle1.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            dataGrid.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            dataGrid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGrid.Columns.AddRange(new DataGridViewColumn[] { idDataGridViewTextBoxColumn, categoryNameDataGridViewTextBoxColumn, plannedAmountDataGridViewTextBoxColumn });
            dataGrid.DataSource = categoryDTOBindingSource;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = SystemColors.Window;
            dataGridViewCellStyle2.Font = new Font("Century Gothic", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            dataGridViewCellStyle2.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.False;
            dataGrid.DefaultCellStyle = dataGridViewCellStyle2;
            dataGrid.Location = new Point(41, 150);
            dataGrid.Name = "dataGrid";
            dataGrid.ReadOnly = true;
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = SystemColors.Control;
            dataGridViewCellStyle3.Font = new Font("Century Gothic", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            dataGridViewCellStyle3.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.True;
            dataGrid.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            dataGrid.RowHeadersVisible = false;
            dataGrid.Size = new Size(819, 503);
            dataGrid.TabIndex = 17;
            // 
            // idDataGridViewTextBoxColumn
            // 
            idDataGridViewTextBoxColumn.DataPropertyName = "Id";
            idDataGridViewTextBoxColumn.HeaderText = "Id";
            idDataGridViewTextBoxColumn.Name = "idDataGridViewTextBoxColumn";
            idDataGridViewTextBoxColumn.ReadOnly = true;
            idDataGridViewTextBoxColumn.Visible = false;
            // 
            // categoryNameDataGridViewTextBoxColumn
            // 
            categoryNameDataGridViewTextBoxColumn.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            categoryNameDataGridViewTextBoxColumn.DataPropertyName = "CategoryName";
            categoryNameDataGridViewTextBoxColumn.HeaderText = "Название";
            categoryNameDataGridViewTextBoxColumn.Name = "categoryNameDataGridViewTextBoxColumn";
            categoryNameDataGridViewTextBoxColumn.ReadOnly = true;
            categoryNameDataGridViewTextBoxColumn.Width = 127;
            // 
            // plannedAmountDataGridViewTextBoxColumn
            // 
            plannedAmountDataGridViewTextBoxColumn.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            plannedAmountDataGridViewTextBoxColumn.DataPropertyName = "PlannedAmount";
            plannedAmountDataGridViewTextBoxColumn.HeaderText = "Планируется тратить";
            plannedAmountDataGridViewTextBoxColumn.Name = "plannedAmountDataGridViewTextBoxColumn";
            plannedAmountDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // categoryDTOBindingSource
            // 
            categoryDTOBindingSource.DataSource = typeof(Models.CategoryDTO);
            // 
            // CategoryControl
            // 
            AutoScaleMode = AutoScaleMode.None;
            BackColor = Color.White;
            Controls.Add(dataGrid);
            Controls.Add(PlusBtn);
            Controls.Add(MinusBtn);
            Controls.Add(AddBtn);
            Controls.Add(label1);
            Font = new Font("Tahoma", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            Name = "CategoryControl";
            Size = new Size(886, 744);
            ((System.ComponentModel.ISupportInitialize)dataGrid).EndInit();
            ((System.ComponentModel.ISupportInitialize)categoryDTOBindingSource).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Button AddBtn;
        private Button MinusBtn;
        private Button PlusBtn;
        private DataGridView dataGrid;
        private BindingSource categoryDTOBindingSource;
        private DataGridViewTextBoxColumn idDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn categoryNameDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn plannedAmountDataGridViewTextBoxColumn;
    }
}
