﻿namespace shershulya22.Controls
{
    partial class TransactionControl
    {
        /// <summary> 
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TransactionControl));
            dataGrid = new DataGridView();
            idDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            dateDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            categoryDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            accountDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            amountDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            commentDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            transactionDTOBindingSource = new BindingSource(components);
            PlusBtn = new Button();
            MinusBtn = new Button();
            DatePanel = new Panel();
            DatePickPanel = new Panel();
            DateLabel = new Label();
            LeftArrow = new PictureBox();
            RightArrow = new PictureBox();
            PeriodPanel = new Panel();
            dateTimePicker2 = new DateTimePicker();
            label3 = new Label();
            dateTimePicker1 = new DateTimePicker();
            label2 = new Label();
            PeriodBtn = new Button();
            YearBtn = new Button();
            MonthBtn = new Button();
            WeekBtn = new Button();
            DayBtn = new Button();
            AddBtn = new Button();
            textBox1 = new TextBox();
            ((System.ComponentModel.ISupportInitialize)dataGrid).BeginInit();
            ((System.ComponentModel.ISupportInitialize)transactionDTOBindingSource).BeginInit();
            DatePanel.SuspendLayout();
            DatePickPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)LeftArrow).BeginInit();
            ((System.ComponentModel.ISupportInitialize)RightArrow).BeginInit();
            PeriodPanel.SuspendLayout();
            SuspendLayout();
            // 
            // dataGrid
            // 
            dataGrid.AllowUserToAddRows = false;
            dataGrid.AutoGenerateColumns = false;
            dataGrid.BackgroundColor = Color.White;
            dataGrid.BorderStyle = BorderStyle.None;
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = SystemColors.Control;
            dataGridViewCellStyle1.Font = new Font("Century Gothic", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 204);
            dataGridViewCellStyle1.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            dataGrid.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            dataGrid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGrid.Columns.AddRange(new DataGridViewColumn[] { idDataGridViewTextBoxColumn, dateDataGridViewTextBoxColumn, categoryDataGridViewTextBoxColumn, accountDataGridViewTextBoxColumn, amountDataGridViewTextBoxColumn, commentDataGridViewTextBoxColumn });
            dataGrid.DataSource = transactionDTOBindingSource;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = SystemColors.Window;
            dataGridViewCellStyle2.Font = new Font("Century Gothic", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            dataGridViewCellStyle2.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = SystemColors.Window;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.ControlText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.False;
            dataGrid.DefaultCellStyle = dataGridViewCellStyle2;
            dataGrid.Location = new Point(31, 239);
            dataGrid.Name = "dataGrid";
            dataGrid.ReadOnly = true;
            dataGrid.RowHeadersVisible = false;
            dataGrid.RowHeadersWidth = 51;
            dataGrid.Size = new Size(819, 435);
            dataGrid.TabIndex = 18;
            // 
            // idDataGridViewTextBoxColumn
            // 
            idDataGridViewTextBoxColumn.DataPropertyName = "Id";
            idDataGridViewTextBoxColumn.HeaderText = "Id";
            idDataGridViewTextBoxColumn.MinimumWidth = 6;
            idDataGridViewTextBoxColumn.Name = "idDataGridViewTextBoxColumn";
            idDataGridViewTextBoxColumn.ReadOnly = true;
            idDataGridViewTextBoxColumn.Visible = false;
            idDataGridViewTextBoxColumn.Width = 125;
            // 
            // dateDataGridViewTextBoxColumn
            // 
            dateDataGridViewTextBoxColumn.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dateDataGridViewTextBoxColumn.DataPropertyName = "Date";
            dateDataGridViewTextBoxColumn.HeaderText = "Дата";
            dateDataGridViewTextBoxColumn.MinimumWidth = 6;
            dateDataGridViewTextBoxColumn.Name = "dateDataGridViewTextBoxColumn";
            dateDataGridViewTextBoxColumn.ReadOnly = true;
            dateDataGridViewTextBoxColumn.Width = 86;
            // 
            // categoryDataGridViewTextBoxColumn
            // 
            categoryDataGridViewTextBoxColumn.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            categoryDataGridViewTextBoxColumn.DataPropertyName = "Category";
            categoryDataGridViewTextBoxColumn.HeaderText = "Категория";
            categoryDataGridViewTextBoxColumn.MinimumWidth = 6;
            categoryDataGridViewTextBoxColumn.Name = "categoryDataGridViewTextBoxColumn";
            categoryDataGridViewTextBoxColumn.ReadOnly = true;
            categoryDataGridViewTextBoxColumn.Width = 136;
            // 
            // accountDataGridViewTextBoxColumn
            // 
            accountDataGridViewTextBoxColumn.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            accountDataGridViewTextBoxColumn.DataPropertyName = "Account";
            accountDataGridViewTextBoxColumn.HeaderText = "Счет";
            accountDataGridViewTextBoxColumn.MinimumWidth = 6;
            accountDataGridViewTextBoxColumn.Name = "accountDataGridViewTextBoxColumn";
            accountDataGridViewTextBoxColumn.ReadOnly = true;
            accountDataGridViewTextBoxColumn.Width = 83;
            // 
            // amountDataGridViewTextBoxColumn
            // 
            amountDataGridViewTextBoxColumn.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            amountDataGridViewTextBoxColumn.DataPropertyName = "Amount";
            amountDataGridViewTextBoxColumn.HeaderText = "Сумма";
            amountDataGridViewTextBoxColumn.MinimumWidth = 6;
            amountDataGridViewTextBoxColumn.Name = "amountDataGridViewTextBoxColumn";
            amountDataGridViewTextBoxColumn.ReadOnly = true;
            amountDataGridViewTextBoxColumn.Width = 104;
            // 
            // commentDataGridViewTextBoxColumn
            // 
            commentDataGridViewTextBoxColumn.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            commentDataGridViewTextBoxColumn.DataPropertyName = "Comment";
            commentDataGridViewTextBoxColumn.HeaderText = "Комментарий";
            commentDataGridViewTextBoxColumn.MinimumWidth = 6;
            commentDataGridViewTextBoxColumn.Name = "commentDataGridViewTextBoxColumn";
            commentDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // transactionDTOBindingSource
            // 
            transactionDTOBindingSource.DataSource = typeof(Models.TransactionDTO);
            // 
            // PlusBtn
            // 
            PlusBtn.BackColor = SystemColors.ButtonHighlight;
            PlusBtn.FlatAppearance.BorderSize = 0;
            PlusBtn.FlatStyle = FlatStyle.Flat;
            PlusBtn.Font = new Font("Century Gothic", 20.25F);
            PlusBtn.Location = new Point(645, 30);
            PlusBtn.Name = "PlusBtn";
            PlusBtn.Size = new Size(205, 50);
            PlusBtn.TabIndex = 20;
            PlusBtn.Text = "Доходы";
            PlusBtn.UseVisualStyleBackColor = false;
            // 
            // MinusBtn
            // 
            MinusBtn.BackColor = Color.FromArgb(251, 229, 214);
            MinusBtn.FlatAppearance.BorderSize = 0;
            MinusBtn.FlatStyle = FlatStyle.Flat;
            MinusBtn.Font = new Font("Century Gothic", 20.25F);
            MinusBtn.Location = new Point(31, 30);
            MinusBtn.Name = "MinusBtn";
            MinusBtn.Size = new Size(205, 50);
            MinusBtn.TabIndex = 19;
            MinusBtn.Text = "Расходы";
            MinusBtn.UseVisualStyleBackColor = false;
            // 
            // DatePanel
            // 
            DatePanel.BackColor = SystemColors.ButtonHighlight;
            DatePanel.Controls.Add(DatePickPanel);
            DatePanel.Controls.Add(PeriodPanel);
            DatePanel.Controls.Add(PeriodBtn);
            DatePanel.Controls.Add(YearBtn);
            DatePanel.Controls.Add(MonthBtn);
            DatePanel.Controls.Add(WeekBtn);
            DatePanel.Controls.Add(DayBtn);
            DatePanel.Location = new Point(31, 95);
            DatePanel.Name = "DatePanel";
            DatePanel.Size = new Size(819, 100);
            DatePanel.TabIndex = 21;
            // 
            // DatePickPanel
            // 
            DatePickPanel.Controls.Add(DateLabel);
            DatePickPanel.Controls.Add(LeftArrow);
            DatePickPanel.Controls.Add(RightArrow);
            DatePickPanel.Dock = DockStyle.Bottom;
            DatePickPanel.Location = new Point(0, 0);
            DatePickPanel.Name = "DatePickPanel";
            DatePickPanel.Padding = new Padding(100, 0, 100, 0);
            DatePickPanel.Size = new Size(819, 50);
            DatePickPanel.TabIndex = 22;
            // 
            // DateLabel
            // 
            DateLabel.Dock = DockStyle.Fill;
            DateLabel.Font = new Font("Century Gothic", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 204);
            DateLabel.ForeColor = Color.FromArgb(140, 140, 140);
            DateLabel.Location = new Point(150, 0);
            DateLabel.Name = "DateLabel";
            DateLabel.Size = new Size(519, 50);
            DateLabel.TabIndex = 29;
            DateLabel.Text = "Март 2025 год";
            DateLabel.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // LeftArrow
            // 
            LeftArrow.Dock = DockStyle.Left;
            LeftArrow.Image = (Image)resources.GetObject("LeftArrow.Image");
            LeftArrow.Location = new Point(100, 0);
            LeftArrow.Name = "LeftArrow";
            LeftArrow.Size = new Size(50, 50);
            LeftArrow.SizeMode = PictureBoxSizeMode.Zoom;
            LeftArrow.TabIndex = 27;
            LeftArrow.TabStop = false;
            // 
            // RightArrow
            // 
            RightArrow.Dock = DockStyle.Right;
            RightArrow.Image = (Image)resources.GetObject("RightArrow.Image");
            RightArrow.Location = new Point(669, 0);
            RightArrow.Name = "RightArrow";
            RightArrow.Size = new Size(50, 50);
            RightArrow.SizeMode = PictureBoxSizeMode.Zoom;
            RightArrow.TabIndex = 28;
            RightArrow.TabStop = false;
            // 
            // PeriodPanel
            // 
            PeriodPanel.Controls.Add(dateTimePicker2);
            PeriodPanel.Controls.Add(label3);
            PeriodPanel.Controls.Add(dateTimePicker1);
            PeriodPanel.Controls.Add(label2);
            PeriodPanel.Dock = DockStyle.Bottom;
            PeriodPanel.Font = new Font("Century Gothic", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            PeriodPanel.Location = new Point(0, 50);
            PeriodPanel.Name = "PeriodPanel";
            PeriodPanel.Padding = new Padding(100, 10, 0, 0);
            PeriodPanel.Size = new Size(819, 50);
            PeriodPanel.TabIndex = 23;
            // 
            // dateTimePicker2
            // 
            dateTimePicker2.Dock = DockStyle.Left;
            dateTimePicker2.Location = new Point(499, 10);
            dateTimePicker2.Name = "dateTimePicker2";
            dateTimePicker2.Size = new Size(200, 31);
            dateTimePicker2.TabIndex = 3;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Dock = DockStyle.Left;
            label3.Location = new Point(389, 10);
            label3.Name = "label3";
            label3.Padding = new Padding(10, 0, 10, 0);
            label3.Size = new Size(110, 22);
            label3.TabIndex = 2;
            label3.Text = "Дата по:";
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Dock = DockStyle.Left;
            dateTimePicker1.Location = new Point(189, 10);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(200, 31);
            dateTimePicker1.TabIndex = 1;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Dock = DockStyle.Left;
            label2.Location = new Point(100, 10);
            label2.Name = "label2";
            label2.Padding = new Padding(0, 0, 10, 0);
            label2.Size = new Size(89, 22);
            label2.TabIndex = 0;
            label2.Text = "Дата с:";
            // 
            // PeriodBtn
            // 
            PeriodBtn.FlatAppearance.BorderSize = 0;
            PeriodBtn.FlatStyle = FlatStyle.Flat;
            PeriodBtn.Location = new Point(699, 0);
            PeriodBtn.Name = "PeriodBtn";
            PeriodBtn.Size = new Size(103, 31);
            PeriodBtn.TabIndex = 26;
            PeriodBtn.Text = "Период";
            PeriodBtn.UseVisualStyleBackColor = true;
            // 
            // YearBtn
            // 
            YearBtn.FlatAppearance.BorderSize = 0;
            YearBtn.FlatStyle = FlatStyle.Flat;
            YearBtn.Location = new Point(540, 3);
            YearBtn.Name = "YearBtn";
            YearBtn.Size = new Size(75, 31);
            YearBtn.TabIndex = 25;
            YearBtn.Text = "Год";
            YearBtn.UseVisualStyleBackColor = true;
            // 
            // MonthBtn
            // 
            MonthBtn.BackColor = Color.FromArgb(222, 235, 247);
            MonthBtn.FlatAppearance.BorderSize = 0;
            MonthBtn.FlatStyle = FlatStyle.Flat;
            MonthBtn.Location = new Point(367, 3);
            MonthBtn.Name = "MonthBtn";
            MonthBtn.Size = new Size(89, 31);
            MonthBtn.TabIndex = 24;
            MonthBtn.Text = "Месяц";
            MonthBtn.UseVisualStyleBackColor = false;
            // 
            // WeekBtn
            // 
            WeekBtn.FlatAppearance.BorderSize = 0;
            WeekBtn.FlatStyle = FlatStyle.Flat;
            WeekBtn.Location = new Point(176, 3);
            WeekBtn.Name = "WeekBtn";
            WeekBtn.Size = new Size(93, 31);
            WeekBtn.TabIndex = 23;
            WeekBtn.Text = "Неделя";
            WeekBtn.UseVisualStyleBackColor = true;
            // 
            // DayBtn
            // 
            DayBtn.FlatAppearance.BorderSize = 0;
            DayBtn.FlatStyle = FlatStyle.Flat;
            DayBtn.Location = new Point(3, 3);
            DayBtn.Name = "DayBtn";
            DayBtn.Size = new Size(75, 31);
            DayBtn.TabIndex = 22;
            DayBtn.Text = "День";
            DayBtn.UseVisualStyleBackColor = true;
            // 
            // AddBtn
            // 
            AddBtn.BackColor = Color.FromArgb(226, 240, 217);
            AddBtn.FlatStyle = FlatStyle.Flat;
            AddBtn.Font = new Font("Century Gothic", 18F, FontStyle.Regular, GraphicsUnit.Point, 204);
            AddBtn.Location = new Point(571, 680);
            AddBtn.Name = "AddBtn";
            AddBtn.Size = new Size(279, 49);
            AddBtn.TabIndex = 22;
            AddBtn.Text = "Экспорт в Excel";
            AddBtn.UseVisualStyleBackColor = false;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(31, 201);
            textBox1.Name = "textBox1";
            textBox1.PlaceholderText = "Фильтр";
            textBox1.Size = new Size(819, 31);
            textBox1.TabIndex = 23;
            textBox1.TextAlign = HorizontalAlignment.Center;
            // 
            // TransactionControl
            // 
            AutoScaleMode = AutoScaleMode.None;
            BackColor = SystemColors.ButtonHighlight;
            Controls.Add(textBox1);
            Controls.Add(AddBtn);
            Controls.Add(DatePanel);
            Controls.Add(PlusBtn);
            Controls.Add(MinusBtn);
            Controls.Add(dataGrid);
            Font = new Font("Century Gothic", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            Name = "TransactionControl";
            Size = new Size(886, 744);
            ((System.ComponentModel.ISupportInitialize)dataGrid).EndInit();
            ((System.ComponentModel.ISupportInitialize)transactionDTOBindingSource).EndInit();
            DatePanel.ResumeLayout(false);
            DatePickPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)LeftArrow).EndInit();
            ((System.ComponentModel.ISupportInitialize)RightArrow).EndInit();
            PeriodPanel.ResumeLayout(false);
            PeriodPanel.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGrid;
        private Button PlusBtn;
        private Button MinusBtn;
        private Panel DatePanel;
        private PictureBox LeftArrow;
        private Button PeriodBtn;
        private Button YearBtn;
        private Button MonthBtn;
        private Button WeekBtn;
        private Button DayBtn;
        private PictureBox RightArrow;
        private Label DateLabel;
        private Panel DatePickPanel;
        private Panel PeriodPanel;
        private DateTimePicker dateTimePicker2;
        private Label label3;
        private DateTimePicker dateTimePicker1;
        private Label label2;
        private Button AddBtn;
        private BindingSource transactionDTOBindingSource;
        private TextBox textBox1;
        private DataGridViewTextBoxColumn idDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn dateDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn categoryDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn accountDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn amountDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn commentDataGridViewTextBoxColumn;
    }
}
