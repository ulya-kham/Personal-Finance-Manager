﻿using shershulya22.Models;

namespace shershulya22.Controls
{
    public partial class AddTransfer: UserControl
    {
        public AddTransfer()
        {
            InitializeComponent();
            Load += async (s, e) =>
            {
                var accounts = await Loader.Instance.AccountRepository.GetAllForUser(Program.CurrentUser);
                var accounts1 = await Loader.Instance.AccountRepository.GetAllForUser(Program.CurrentUser);

                comboBox1.DataSource = accounts;
                comboBox1.DisplayMember = "Name";
                comboBox1.ValueMember = "Id";

                comboBox2.DataSource = accounts1;
                comboBox2.DisplayMember = "Name";
                comboBox2.ValueMember = "Id";
            };
            pictureBox1.Click += (s, e) => Close();
            textBox1.TextChanged += (s, e) => textBox1.Text = textBox1.Text.Replace('.', ',');
            AddBtn.Click += async (s, e) =>
            {
                var canParse = decimal.TryParse(textBox1.Text, out decimal amount);
                if (!canParse)
                {
                    MessageBox.Show("Не могу разобрать сумму");
                    return;
                }
                if(amount < 0)
                {
                    MessageBox.Show("Сумма должна быть положительной");
                    return;
                }
                var transfer = new TransferEntity
                {
                    FromAccountId = Guid.Parse(comboBox1.SelectedValue.ToString()),
                    ToAccountId = Guid.Parse(comboBox2.SelectedValue.ToString()),
                    Amount = amount,
                    UserId = Program.CurrentUser,
                    Date = dateTimePicker1.Value,
                    Description = textBox2.Text
                };
                await Loader.Instance.TransferRepository.Add(transfer);
                GlobalEvents.ChangeBalance(this, transfer.FromAccountId, -1 * transfer.Amount);
                GlobalEvents.ChangeBalance(this, transfer.ToAccountId, transfer.Amount);
                GlobalEvents.ShowAccountControl(this);
            };

        }

        private void Close()
        {
            var dialog = MessageBox.Show("Вы уверены, что хотите уйти с Создание перевода?", "Предупреждение", MessageBoxButtons.YesNo);
            if (dialog != DialogResult.Yes)
                return;
            GlobalEvents.ShowAccountControl(this);
        }
    }
}
