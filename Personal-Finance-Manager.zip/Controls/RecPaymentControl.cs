﻿namespace shershulya22.Controls
{
    public partial class RecPaymentControl: UserControl
    {
        public RecPaymentControl()
        {
            InitializeComponent();
            Load += async (s, e) =>
            {
                var recPayments = await Loader.Instance.RecPaymentRepository.GetAllForUser(Program.CurrentUser);
                dataGrid.DataSource = recPayments;
            };
            AddBtn.Click += (s, e) =>
            {
                GlobalEvents.ShowAddControl(this, GlobalEvents.GetRecPaymentAddControlHandler());
            };
            dataGrid.CellValueChanged += async (s, e) =>
            {
                var guid = Guid.Parse(dataGrid[0, e.RowIndex].Value.ToString());
                var isOff = bool.Parse(dataGrid[2, e.RowIndex].Value.ToString());
                await Loader.Instance.RecPaymentRepository.UpdateActivity(guid, isOff);
                MessageBox.Show("Значение изменено");
            };
            dataGrid.CellDoubleClick += (s, e) =>
            {
                var guid = Guid.Parse(dataGrid[0, e.RowIndex].Value.ToString());
                GlobalEvents.ShowEditControl(this, guid, GlobalEvents.GetRecPaymentEditControlHandler());
            };
        }
    }
}
