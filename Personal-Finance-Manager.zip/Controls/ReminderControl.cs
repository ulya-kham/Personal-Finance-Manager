﻿namespace shershulya22.Controls
{
    public partial class ReminderControl: UserControl
    {
        public ReminderControl()
        {
            InitializeComponent();
            Load += async (s, e) =>
            {
                var reminder = await Loader.Instance.ReminderRepository.GetAllForUser(Program.CurrentUser);
                dataGrid.DataSource = reminder;
            };
            AddBtn.Click += (s, e) =>
            {
                GlobalEvents.ShowAddControl(this, GlobalEvents.GetReminderAddControlHandler());
            };
            dataGrid.CellValueChanged += async (s, e) =>
            {
                var guid = Guid.Parse(dataGrid[0,e.RowIndex].Value.ToString());
                var isOff = bool.Parse(dataGrid[2, e.RowIndex].Value.ToString());
                await Loader.Instance.ReminderRepository.UpdateActivity(guid, isOff);
                MessageBox.Show("Значение изменено");
            };
            dataGrid.CellDoubleClick += (s, e) => 
            {
                var guid = Guid.Parse(dataGrid[0, e.RowIndex].Value.ToString());
                GlobalEvents.ShowEditControl(this, guid, GlobalEvents.GetReminderEditControlHandler());
            };
        }
    }
}
