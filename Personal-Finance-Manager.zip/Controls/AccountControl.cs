﻿namespace shershulya22.Controls
{
    public partial class AccountControl: UserControl
    {
        public AccountControl()
        {
            InitializeComponent();
            HistoryBtn.Click += (s, e) => GlobalEvents.ShowAddControl(this, GlobalEvents.GetHostoryControlHandler());
            CreateBtn.Click += (s, e) => GlobalEvents.ShowAddControl(this, GlobalEvents.GetTransferAddControlHandler());
            AddBtn.Click += (s, e) => GlobalEvents.ShowAddControl(this, GlobalEvents.GetAccountAddControlHandler());
            dataGrid.CellDoubleClick += (s, e) =>
            {
                var guid = Guid.Parse(dataGrid[0, e.RowIndex].Value.ToString());
                GlobalEvents.ShowEditControl(this, guid, GlobalEvents.GetAccountEditControlHandler());
            };
            Load += async (s, e) =>
            {
                var account = await Loader.Instance.AccountRepository.GetAllForUser(Program.CurrentUser);
                dataGrid.DataSource = account;
            };
        }
    }
}
