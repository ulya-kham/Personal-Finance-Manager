﻿using shershulya22.Models;

namespace shershulya22.Controls
{
    public partial class CreateRecurringPayment: UserControl
    {
        private RecurringPaymentEntity _recPayment;
        public CreateRecurringPayment()
        {
            InitializeComponent();
            pictureBox1.Click += (s, e) => Close();
            checkBox1.CheckedChanged += (s, e) => dateTimePicker2.Enabled = checkBox1.Checked;
            AddBtn.Click += async (s, e) => await Add();
            textBox2.TextChanged += (s, e) => textBox2.Text = textBox2.Text.Replace('.', ',');
            Load += async (s, e) => await LoadData();
        }
        public CreateRecurringPayment(Guid paymentId)
        {
            InitializeComponent();
            pictureBox1.Click += (s, e) => Close();
            checkBox1.CheckedChanged += (s, e) => dateTimePicker2.Enabled = checkBox1.Checked;
            AddBtn.Click += async (s, e) => await Update();
            DeleteBtn.Visible = true;
            AddBtn.Text = "Изменить платеж";
            label1.Text = "Редактировать платеж";
            textBox2.TextChanged += (s, e) => textBox2.Text = textBox2.Text.Replace('.', ',');
            DeleteBtn.Click += async (s, e) =>
            {
                var dialog = MessageBox.Show("Вы уверены, что хотите удалить платеж?", "Предупреждение", MessageBoxButtons.YesNo);
                if (dialog != DialogResult.Yes)
                    return;
                await Loader.Instance.RecPaymentRepository.Delete(paymentId);
                GlobalEvents.ShowRecPaymentControl(this);
            };
            Load += async (s, e) =>
            {
                await LoadData();
                _recPayment = await Loader.Instance.RecPaymentRepository.GetById(paymentId);
                textBox1.Text = _recPayment.Name;
                textBox2.Text = _recPayment.Amount.ToString();
                textBox3.Text = _recPayment.Comment;
                dateTimePicker1.Value = _recPayment.StartDate;
                dateTimePicker2.Value = _recPayment.EndDate.HasValue ? _recPayment.EndDate.Value : DateTime.Now;
                comboBox1.SelectedValue = _recPayment.AccountId;
                comboBox2.SelectedValue = _recPayment.Frequency;
                comboBox3.SelectedValue = _recPayment.CategoryId;
            };
        }
        private void Close()
        {
            var dialog = MessageBox.Show("Вы уверены, что хотите уйти с Создание регулярного платежа?", "Предупреждение", MessageBoxButtons.YesNo);
            if (dialog != DialogResult.Yes)
                return;
            GlobalEvents.ShowRecPaymentControl(this);
        }
        private async Task LoadData()
        {
            var accounts = await Loader.Instance.AccountRepository.GetAllForUser(Program.CurrentUser);
            var categories = await Loader.Instance.CategoryRepository.GetAllForUserByType(Program.CurrentUser, CategoryType.Minus);

            comboBox1.DataSource = accounts;
            comboBox1.DisplayMember = "Name";
            comboBox1.ValueMember = "Id";

            comboBox2.DataSource = EnumHelper.GetEnumListWithDescription(typeof(Frequency));
            comboBox2.DisplayMember = "Value";
            comboBox2.ValueMember = "Key";

            comboBox3.DataSource = categories;
            comboBox3.DisplayMember = "CategoryName";
            comboBox3.ValueMember = "Id";
        }
        private async Task Add()
        {
            if (string.IsNullOrEmpty(textBox1.Text))
            {
                MessageBox.Show("Заполните название");
                return;
            }
            var canParse = decimal.TryParse(textBox2.Text, out decimal amount);
            if (!canParse && !string.IsNullOrEmpty(textBox2.Text))
            {
                MessageBox.Show("Не могу понять сумму!");
                return;
            }
            if (amount <= 0)
            {
                MessageBox.Show("Сумма должна быть положительна");
                return;
            }
            var category = new RecurringPaymentEntity
            {
                Name = textBox1.Text,
                CategoryId = Guid.Parse(comboBox3.SelectedValue.ToString()),
                Comment=textBox3.Text,
                Amount = amount,
                UserId = Program.CurrentUser,
                AccountId = Guid.Parse(comboBox1.SelectedValue.ToString()),
                Frequency = (Frequency)comboBox2.SelectedValue,
                StartDate = dateTimePicker1.Value,
                EndDate = checkBox1.Checked ? dateTimePicker2.Value : null
            };
            await Loader.Instance.RecPaymentRepository.Add(category);
            GlobalEvents.ShowRecPaymentControl(this);
        }
        private async Task Update()
        {
            var dialog = MessageBox.Show("Вы уверены, что хотите изменить платеж?", "Предупреждение", MessageBoxButtons.YesNo);
            if (dialog != DialogResult.Yes)
                return;

            if (string.IsNullOrEmpty(textBox1.Text))
            {
                MessageBox.Show("Заполните название");
                return;
            }
            var canParse = decimal.TryParse(textBox2.Text, out decimal amount);
            if (!canParse && !string.IsNullOrEmpty(textBox2.Text))
            {
                MessageBox.Show("Не могу понять сумму!");
                return;
            }
            if (amount < 0)
            {
                MessageBox.Show("Сумма должна быть положительна");
                return;
            }
            var category = new RecurringPaymentEntity
            {
                Id = _recPayment.Id,
                Name = textBox1.Text,
                CategoryId = Guid.Parse(comboBox3.SelectedValue.ToString()),
                Comment = textBox3.Text,
                Amount = amount,
                AccountId = Guid.Parse(comboBox1.SelectedValue.ToString()),
                Frequency = (Frequency)comboBox2.SelectedValue,
                StartDate = dateTimePicker1.Value,
                EndDate = checkBox1.Checked ? dateTimePicker2.Value : null
            };
            await Loader.Instance.RecPaymentRepository.Update(category);
            GlobalEvents.ShowRecPaymentControl(this);
        }
    }
}
