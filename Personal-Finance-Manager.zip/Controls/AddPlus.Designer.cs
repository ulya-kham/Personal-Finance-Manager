﻿namespace shershulya22.Controls
{
    partial class AddPlus
    {
        /// <summary> 
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddPlus));
            AddBtn = new Button();
            label5 = new Label();
            label4 = new Label();
            label2 = new Label();
            dateTimePicker1 = new DateTimePicker();
            comboBox3 = new ComboBox();
            comboBox1 = new ComboBox();
            textBox3 = new TextBox();
            textBox2 = new TextBox();
            pictureBox1 = new PictureBox();
            label1 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // AddBtn
            // 
            AddBtn.BackColor = Color.FromArgb(226, 240, 217);
            AddBtn.FlatStyle = FlatStyle.Flat;
            AddBtn.Font = new Font("Century Gothic", 20.25F);
            AddBtn.Location = new Point(300, 626);
            AddBtn.Name = "AddBtn";
            AddBtn.Size = new Size(292, 50);
            AddBtn.TabIndex = 36;
            AddBtn.Text = "Добавить доходы";
            AddBtn.UseVisualStyleBackColor = false;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(170, 415);
            label5.Name = "label5";
            label5.Size = new Size(72, 30);
            label5.TabIndex = 35;
            label5.Text = "Дата";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(170, 266);
            label4.Name = "label4";
            label4.Size = new Size(135, 30);
            label4.TabIndex = 34;
            label4.Text = "Категория";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(170, 185);
            label2.Name = "label2";
            label2.Size = new Size(69, 30);
            label2.TabIndex = 33;
            label2.Text = "Счет";
       //     label2.Click += this.label2_Click;
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Location = new Point(170, 448);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(281, 37);
            dateTimePicker1.TabIndex = 32;
            // 
            // comboBox3
            // 
            comboBox3.FormattingEnabled = true;
            comboBox3.Location = new Point(170, 299);
            comboBox3.Name = "comboBox3";
            comboBox3.Size = new Size(553, 38);
            comboBox3.TabIndex = 31;
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Location = new Point(170, 218);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(553, 38);
            comboBox1.TabIndex = 30;
            comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(170, 512);
            textBox3.Name = "textBox3";
            textBox3.PlaceholderText = "Комментарий";
            textBox3.Size = new Size(553, 37);
            textBox3.TabIndex = 29;
            // 
            // textBox2
            // 
            textBox2.Font = new Font("Century Gothic", 18F, FontStyle.Bold, GraphicsUnit.Point, 204);
            textBox2.Location = new Point(170, 364);
            textBox2.Name = "textBox2";
            textBox2.PlaceholderText = "Сумма платежа";
            textBox2.Size = new Size(553, 37);
            textBox2.TabIndex = 28;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(3, 4);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(48, 48);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 27;
            pictureBox1.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Century Gothic", 26.25F, FontStyle.Bold);
            label1.Location = new Point(235, 68);
            label1.Name = "label1";
            label1.Size = new Size(398, 41);
            label1.TabIndex = 26;
            label1.Text = "Добавление доходов";
            // 
            // AddPlus
            // 
            AutoScaleMode = AutoScaleMode.None;
            BackColor = Color.White;
            Controls.Add(AddBtn);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label2);
            Controls.Add(dateTimePicker1);
            Controls.Add(comboBox3);
            Controls.Add(comboBox1);
            Controls.Add(textBox3);
            Controls.Add(textBox2);
            Controls.Add(pictureBox1);
            Controls.Add(label1);
            Font = new Font("Century Gothic", 18F);
            Name = "AddPlus";
            Size = new Size(886, 744);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button AddBtn;
        private Label label5;
        private Label label4;
        private Label label2;
        private DateTimePicker dateTimePicker1;
        private ComboBox comboBox3;
        private ComboBox comboBox1;
        private TextBox textBox3;
        private TextBox textBox2;
        private PictureBox pictureBox1;
        private Label label1;
    }
}
