﻿namespace shershulya22.Controls
{
    partial class AccountControl
    {
        /// <summary> 
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            label1 = new Label();
            dataGrid = new DataGridView();
            idDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            userIdDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            nameDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            balanceDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            isPublicDataGridViewCheckBoxColumn = new DataGridViewCheckBoxColumn();
            userDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            transactionsDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            accountEntityBindingSource = new BindingSource(components);
            AddBtn = new Button();
            HistoryBtn = new Button();
            CreateBtn = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGrid).BeginInit();
            ((System.ComponentModel.ISupportInitialize)accountEntityBindingSource).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Century Gothic", 26.25F, FontStyle.Bold);
            label1.Location = new Point(361, 39);
            label1.Name = "label1";
            label1.Size = new Size(128, 41);
            label1.TabIndex = 0;
            label1.Text = "Счета";
            // 
            // dataGrid
            // 
            dataGrid.AutoGenerateColumns = false;
            dataGrid.BackgroundColor = Color.White;
            dataGrid.BorderStyle = BorderStyle.None;
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = SystemColors.Control;
            dataGridViewCellStyle1.Font = new Font("Century Gothic", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 204);
            dataGridViewCellStyle1.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            dataGrid.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            dataGrid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGrid.Columns.AddRange(new DataGridViewColumn[] { idDataGridViewTextBoxColumn, userIdDataGridViewTextBoxColumn, nameDataGridViewTextBoxColumn, balanceDataGridViewTextBoxColumn, isPublicDataGridViewCheckBoxColumn, userDataGridViewTextBoxColumn, transactionsDataGridViewTextBoxColumn });
            dataGrid.DataSource = accountEntityBindingSource;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = SystemColors.Window;
            dataGridViewCellStyle2.Font = new Font("Century Gothic", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            dataGridViewCellStyle2.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.False;
            dataGrid.DefaultCellStyle = dataGridViewCellStyle2;
            dataGrid.Location = new Point(17, 168);
            dataGrid.Name = "dataGrid";
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = SystemColors.Control;
            dataGridViewCellStyle3.Font = new Font("Century Gothic", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            dataGridViewCellStyle3.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.True;
            dataGrid.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            dataGrid.RowHeadersVisible = false;
            dataGrid.RowHeadersWidth = 51;
            dataGrid.Size = new Size(853, 459);
            dataGrid.TabIndex = 1;
            // 
            // idDataGridViewTextBoxColumn
            // 
            idDataGridViewTextBoxColumn.DataPropertyName = "Id";
            idDataGridViewTextBoxColumn.HeaderText = "Id";
            idDataGridViewTextBoxColumn.MinimumWidth = 6;
            idDataGridViewTextBoxColumn.Name = "idDataGridViewTextBoxColumn";
            idDataGridViewTextBoxColumn.Visible = false;
            idDataGridViewTextBoxColumn.Width = 125;
            // 
            // userIdDataGridViewTextBoxColumn
            // 
            userIdDataGridViewTextBoxColumn.DataPropertyName = "UserId";
            userIdDataGridViewTextBoxColumn.HeaderText = "UserId";
            userIdDataGridViewTextBoxColumn.MinimumWidth = 6;
            userIdDataGridViewTextBoxColumn.Name = "userIdDataGridViewTextBoxColumn";
            userIdDataGridViewTextBoxColumn.Visible = false;
            userIdDataGridViewTextBoxColumn.Width = 125;
            // 
            // nameDataGridViewTextBoxColumn
            // 
            nameDataGridViewTextBoxColumn.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            nameDataGridViewTextBoxColumn.DataPropertyName = "Name";
            nameDataGridViewTextBoxColumn.HeaderText = "Наименование";
            nameDataGridViewTextBoxColumn.MinimumWidth = 6;
            nameDataGridViewTextBoxColumn.Name = "nameDataGridViewTextBoxColumn";
            nameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // balanceDataGridViewTextBoxColumn
            // 
            balanceDataGridViewTextBoxColumn.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            balanceDataGridViewTextBoxColumn.DataPropertyName = "Balance";
            balanceDataGridViewTextBoxColumn.HeaderText = "Баланс";
            balanceDataGridViewTextBoxColumn.MinimumWidth = 6;
            balanceDataGridViewTextBoxColumn.Name = "balanceDataGridViewTextBoxColumn";
            balanceDataGridViewTextBoxColumn.ReadOnly = true;
            balanceDataGridViewTextBoxColumn.Width = 105;
            // 
            // isPublicDataGridViewCheckBoxColumn
            // 
            isPublicDataGridViewCheckBoxColumn.DataPropertyName = "IsPublic";
            isPublicDataGridViewCheckBoxColumn.HeaderText = "IsPublic";
            isPublicDataGridViewCheckBoxColumn.MinimumWidth = 6;
            isPublicDataGridViewCheckBoxColumn.Name = "isPublicDataGridViewCheckBoxColumn";
            isPublicDataGridViewCheckBoxColumn.Visible = false;
            isPublicDataGridViewCheckBoxColumn.Width = 125;
            // 
            // userDataGridViewTextBoxColumn
            // 
            userDataGridViewTextBoxColumn.DataPropertyName = "User";
            userDataGridViewTextBoxColumn.HeaderText = "User";
            userDataGridViewTextBoxColumn.MinimumWidth = 6;
            userDataGridViewTextBoxColumn.Name = "userDataGridViewTextBoxColumn";
            userDataGridViewTextBoxColumn.Visible = false;
            userDataGridViewTextBoxColumn.Width = 125;
            // 
            // transactionsDataGridViewTextBoxColumn
            // 
            transactionsDataGridViewTextBoxColumn.DataPropertyName = "Transactions";
            transactionsDataGridViewTextBoxColumn.HeaderText = "Transactions";
            transactionsDataGridViewTextBoxColumn.MinimumWidth = 6;
            transactionsDataGridViewTextBoxColumn.Name = "transactionsDataGridViewTextBoxColumn";
            transactionsDataGridViewTextBoxColumn.Visible = false;
            transactionsDataGridViewTextBoxColumn.Width = 125;
            // 
            // accountEntityBindingSource
            // 
            accountEntityBindingSource.DataSource = typeof(Models.AccountEntity);
            // 
            // AddBtn
            // 
            AddBtn.BackColor = Color.FromArgb(226, 240, 217);
            AddBtn.FlatStyle = FlatStyle.Flat;
            AddBtn.Font = new Font("Century Gothic", 20.25F);
            AddBtn.Location = new Point(311, 657);
            AddBtn.Name = "AddBtn";
            AddBtn.Size = new Size(258, 54);
            AddBtn.TabIndex = 2;
            AddBtn.Text = "Добавить счет";
            AddBtn.UseVisualStyleBackColor = false;
            // 
            // HistoryBtn
            // 
            HistoryBtn.BackColor = Color.FromArgb(222, 235, 247);
            HistoryBtn.FlatStyle = FlatStyle.Flat;
            HistoryBtn.Font = new Font("Century Gothic", 20.25F);
            HistoryBtn.Location = new Point(103, 99);
            HistoryBtn.Name = "HistoryBtn";
            HistoryBtn.Size = new Size(200, 50);
            HistoryBtn.TabIndex = 3;
            HistoryBtn.Text = "История переводов";
            HistoryBtn.UseVisualStyleBackColor = false;
            // 
            // CreateBtn
            // 
            CreateBtn.BackColor = Color.FromArgb(255, 242, 204);
            CreateBtn.FlatStyle = FlatStyle.Flat;
            CreateBtn.Font = new Font("Century Gothic", 20.25F);
            CreateBtn.Location = new Point(554, 99);
            CreateBtn.Name = "CreateBtn";
            CreateBtn.Size = new Size(272, 50);
            CreateBtn.TabIndex = 4;
            CreateBtn.Text = "Создать перевод";
            CreateBtn.UseVisualStyleBackColor = false;
            // 
            // AccountControl
            // 
            AutoScaleMode = AutoScaleMode.None;
            BackColor = Color.White;
            Controls.Add(CreateBtn);
            Controls.Add(HistoryBtn);
            Controls.Add(AddBtn);
            Controls.Add(dataGrid);
            Controls.Add(label1);
            Font = new Font("Tahoma", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            Name = "AccountControl";
            Size = new Size(886, 744);
            ((System.ComponentModel.ISupportInitialize)dataGrid).EndInit();
            ((System.ComponentModel.ISupportInitialize)accountEntityBindingSource).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private DataGridView dataGrid;
        private Button AddBtn;
        private Button HistoryBtn;
        private Button CreateBtn;
        private BindingSource accountEntityBindingSource;
        private DataGridViewTextBoxColumn idDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn userIdDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn balanceDataGridViewTextBoxColumn;
        private DataGridViewCheckBoxColumn isPublicDataGridViewCheckBoxColumn;
        private DataGridViewTextBoxColumn userDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn transactionsDataGridViewTextBoxColumn;
    }
}
