﻿namespace shershulya22.Controls
{
    partial class CreateReminder
    {
        /// <summary> 
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CreateReminder));
            pictureBox1 = new PictureBox();
            label1 = new Label();
            textBox1 = new TextBox();
            comboBox1 = new ComboBox();
            dateTimePicker1 = new DateTimePicker();
            textBox2 = new TextBox();
            label2 = new Label();
            label3 = new Label();
            DeleteBtn = new Button();
            AddBtn = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(8, 6);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(48, 48);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 6;
            pictureBox1.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Century Gothic", 26.25F, FontStyle.Bold);
            label1.Location = new Point(210, 50);
            label1.Name = "label1";
            label1.Size = new Size(442, 41);
            label1.TabIndex = 5;
            label1.Text = "Создание напоминания";
            // 
            // textBox1
            // 
            textBox1.Font = new Font("Century Gothic", 18F);
            textBox1.Location = new Point(100, 161);
            textBox1.Name = "textBox1";
            textBox1.PlaceholderText = "Имя напоминания";
            textBox1.Size = new Size(636, 37);
            textBox1.TabIndex = 7;
            // 
            // comboBox1
            // 
            comboBox1.Font = new Font("Century Gothic", 18F);
            comboBox1.FormattingEnabled = true;
            comboBox1.Location = new Point(100, 263);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(636, 38);
            comboBox1.TabIndex = 8;
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Font = new Font("Century Gothic", 18F);
            dateTimePicker1.Location = new Point(100, 352);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(636, 37);
            dateTimePicker1.TabIndex = 9;
            // 
            // textBox2
            // 
            textBox2.Font = new Font("Century Gothic", 18F);
            textBox2.Location = new Point(100, 430);
            textBox2.Name = "textBox2";
            textBox2.PlaceholderText = "Комментарий";
            textBox2.Size = new Size(636, 37);
            textBox2.TabIndex = 10;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Century Gothic", 18F);
            label2.Location = new Point(100, 230);
            label2.Name = "label2";
            label2.Size = new Size(199, 30);
            label2.TabIndex = 11;
            label2.Text = "Периодичность";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Century Gothic", 18F);
            label3.Location = new Point(100, 319);
            label3.Name = "label3";
            label3.Size = new Size(338, 30);
            label3.TabIndex = 12;
            label3.Text = "Дата начала напоминания";
            // 
            // DeleteBtn
            // 
            DeleteBtn.BackColor = Color.FromArgb(251, 229, 214);
            DeleteBtn.FlatStyle = FlatStyle.Flat;
            DeleteBtn.Font = new Font("Century Gothic", 20.25F);
            DeleteBtn.Location = new Point(536, 504);
            DeleteBtn.Name = "DeleteBtn";
            DeleteBtn.Size = new Size(200, 50);
            DeleteBtn.TabIndex = 21;
            DeleteBtn.Text = "Удалить";
            DeleteBtn.UseVisualStyleBackColor = false;
            DeleteBtn.Visible = false;
            // 
            // AddBtn
            // 
            AddBtn.BackColor = Color.FromArgb(226, 240, 217);
            AddBtn.FlatStyle = FlatStyle.Flat;
            AddBtn.Font = new Font("Century Gothic", 20.25F);
            AddBtn.Location = new Point(100, 504);
            AddBtn.Name = "AddBtn";
            AddBtn.Size = new Size(359, 50);
            AddBtn.TabIndex = 20;
            AddBtn.Text = "Добавить напоминание";
            AddBtn.UseVisualStyleBackColor = false;
            // 
            // CreateReminder
            // 
            AutoScaleMode = AutoScaleMode.None;
            BackColor = Color.White;
            Controls.Add(DeleteBtn);
            Controls.Add(AddBtn);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(textBox2);
            Controls.Add(dateTimePicker1);
            Controls.Add(comboBox1);
            Controls.Add(textBox1);
            Controls.Add(pictureBox1);
            Controls.Add(label1);
            Font = new Font("Century Gothic", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            Name = "CreateReminder";
            Size = new Size(886, 744);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private Label label1;
        private TextBox textBox1;
        private ComboBox comboBox1;
        private DateTimePicker dateTimePicker1;
        private TextBox textBox2;
        private Label label2;
        private Label label3;
        private Button DeleteBtn;
        private Button AddBtn;
    }
}
