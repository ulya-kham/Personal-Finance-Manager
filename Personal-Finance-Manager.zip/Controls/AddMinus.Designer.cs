﻿namespace shershulya22.Controls
{
    partial class AddMinus
    {
        /// <summary> 
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddMinus));
            label1 = new Label();
            pictureBox1 = new PictureBox();
            label5 = new Label();
            label4 = new Label();
            label2 = new Label();
            dateTimePicker1 = new DateTimePicker();
            comboBox3 = new ComboBox();
            comboBox1 = new ComboBox();
            textBox3 = new TextBox();
            textBox2 = new TextBox();
            AddBtn = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Century Gothic", 26.25F, FontStyle.Bold);
            label1.Location = new Point(241, 67);
            label1.Name = "label1";
            label1.Size = new Size(421, 41);
            label1.TabIndex = 2;
            label1.Text = "Добавление расходов";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(3, 3);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(48, 48);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 3;
            pictureBox1.TabStop = false;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(170, 418);
            label5.Name = "label5";
            label5.Size = new Size(72, 30);
            label5.TabIndex = 24;
            label5.Text = "Дата";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(170, 265);
            label4.Name = "label4";
            label4.Size = new Size(135, 30);
            label4.TabIndex = 23;
            label4.Text = "Категория";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(170, 174);
            label2.Name = "label2";
            label2.Size = new Size(69, 30);
            label2.TabIndex = 22;
            label2.Text = "Счет";
          //  label2.Click += this.label2_Click;
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Location = new Point(170, 451);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(281, 37);
            dateTimePicker1.TabIndex = 21;
            // 
            // comboBox3
            // 
            comboBox3.FormattingEnabled = true;
            comboBox3.Location = new Point(170, 298);
            comboBox3.Name = "comboBox3";
            comboBox3.Size = new Size(553, 38);
            comboBox3.TabIndex = 20;
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Location = new Point(170, 207);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(553, 38);
            comboBox1.TabIndex = 19;
            comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(170, 513);
            textBox3.Name = "textBox3";
            textBox3.PlaceholderText = "Комментарий";
            textBox3.Size = new Size(553, 37);
            textBox3.TabIndex = 18;
            // 
            // textBox2
            // 
            textBox2.Font = new Font("Century Gothic", 18F, FontStyle.Bold, GraphicsUnit.Point, 204);
            textBox2.Location = new Point(170, 363);
            textBox2.Name = "textBox2";
            textBox2.PlaceholderText = "Сумма платежа";
            textBox2.Size = new Size(553, 37);
            textBox2.TabIndex = 17;
            // 
            // AddBtn
            // 
            AddBtn.BackColor = Color.FromArgb(226, 240, 217);
            AddBtn.FlatStyle = FlatStyle.Flat;
            AddBtn.Font = new Font("Century Gothic", 20.25F);
            AddBtn.Location = new Point(310, 623);
            AddBtn.Name = "AddBtn";
            AddBtn.Size = new Size(286, 55);
            AddBtn.TabIndex = 25;
            AddBtn.Text = "Добавить расходы";
            AddBtn.UseVisualStyleBackColor = false;
            // 
            // AddMinus
            // 
            AutoScaleMode = AutoScaleMode.None;
            BackColor = Color.White;
            Controls.Add(AddBtn);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label2);
            Controls.Add(dateTimePicker1);
            Controls.Add(comboBox3);
            Controls.Add(comboBox1);
            Controls.Add(textBox3);
            Controls.Add(textBox2);
            Controls.Add(pictureBox1);
            Controls.Add(label1);
            Font = new Font("Century Gothic", 18F, FontStyle.Regular, GraphicsUnit.Point, 204);
            Name = "AddMinus";
            Size = new Size(886, 744);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private PictureBox pictureBox1;
        private Label label5;
        private Label label4;
        private Label label2;
        private DateTimePicker dateTimePicker1;
        private ComboBox comboBox3;
        private ComboBox comboBox1;
        private TextBox textBox3;
        private TextBox textBox2;
        private Button AddBtn;
    }
}
