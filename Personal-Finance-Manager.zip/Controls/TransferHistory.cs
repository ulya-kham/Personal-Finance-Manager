﻿namespace shershulya22.Controls
{
    public partial class TransferHistory : UserControl
    {
        private List<Models.TransferHistory> _history;
        public TransferHistory()
        {
            InitializeComponent();
            Load += async (s, e) =>
            {
                _history = await Loader.Instance.TransferRepository.GetHistory(Program.CurrentUser);
                dataGrid.DataSource = _history;
            };
            AddBtn.Click += (s, e) =>
            {
                ExcelHelper.Create(_history);
            };
            pictureBox1.Click += (s, e) => Close();
        }
        private void Close()
        {
            var dialog = MessageBox.Show("Вы уверены, что хотите уйти с История переводов?", "Предупреждение", MessageBoxButtons.YesNo);
            if (dialog != DialogResult.Yes)
                return;
            GlobalEvents.ShowAccountControl(this);
        }

        private void TransferHistory_Load(object sender, EventArgs e)
        {

        }
    }
}
