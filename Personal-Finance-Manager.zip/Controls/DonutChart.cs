﻿using LiveChartsCore;
using LiveChartsCore.SkiaSharpView;
using LiveChartsCore.SkiaSharpView.Painting;
using LiveChartsCore.SkiaSharpView.WinForms;
using SkiaSharp;
using System.Data;

namespace shershulya22.Controls
{
    public partial class DonutChart: UserControl
    {
        public DonutChart(List<(string CategoryName, string Percent)> data)
        {
            InitializeComponent();
            var series = data.Select(d => new PieSeries<double>
            {
                Name = d.CategoryName,
                Values = new[] { double.Parse(d.Percent.Replace("%","")) },
                InnerRadius = 60,
                DataLabelsSize = 14,
                DataLabelsPaint = new SolidColorPaint(SKColors.Black),
                DataLabelsFormatter = point =>
                    $"{point.Context.Series.Name} ({point.Coordinate.PrimaryValue:F2}%)"
            }).ToList<ISeries>();

            var pieChart = new PieChart
            {
                Series = series,
                Dock = DockStyle.Fill,
                LegendPosition = LiveChartsCore.Measure.LegendPosition.Right
            };

            Controls.Add(pieChart);
        }
    }
}
