﻿namespace shershulya22.Controls
{
    partial class AddTransfer
    {
        /// <summary> 
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddTransfer));
            pictureBox1 = new PictureBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            dateTimePicker1 = new DateTimePicker();
            comboBox1 = new ComboBox();
            comboBox2 = new ComboBox();
            AddBtn = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(9, 10);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(48, 48);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 4;
            pictureBox1.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Century Gothic", 26.25F, FontStyle.Bold);
            label1.Location = new Point(245, 59);
            label1.Name = "label1";
            label1.Size = new Size(378, 41);
            label1.TabIndex = 3;
            label1.Text = "Создание перевода";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(196, 152);
            label2.Name = "label2";
            label2.Size = new Size(233, 30);
            label2.TabIndex = 5;
            label2.Text = "Перевод со счета";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(196, 237);
            label3.Name = "label3";
            label3.Size = new Size(215, 30);
            label3.TabIndex = 6;
            label3.Text = "Перевод на счет";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(196, 388);
            label4.Name = "label4";
            label4.Size = new Size(199, 30);
            label4.TabIndex = 7;
            label4.Text = "Дата перевода";
            // 
            // textBox1
            // 
            textBox1.Font = new Font("Century Gothic", 18F, FontStyle.Bold, GraphicsUnit.Point, 204);
            textBox1.Location = new Point(196, 336);
            textBox1.Name = "textBox1";
            textBox1.PlaceholderText = "Сумма перевода руб.";
            textBox1.Size = new Size(477, 37);
            textBox1.TabIndex = 8;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(196, 491);
            textBox2.Name = "textBox2";
            textBox2.PlaceholderText = "Комментарий";
            textBox2.Size = new Size(477, 37);
            textBox2.TabIndex = 9;
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Location = new Point(196, 421);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(477, 37);
            dateTimePicker1.TabIndex = 10;
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Location = new Point(196, 185);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(477, 38);
            comboBox1.TabIndex = 11;
            // 
            // comboBox2
            // 
            comboBox2.FormattingEnabled = true;
            comboBox2.Location = new Point(196, 270);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(477, 38);
            comboBox2.TabIndex = 12;
            // 
            // AddBtn
            // 
            AddBtn.BackColor = Color.FromArgb(226, 240, 217);
            AddBtn.FlatStyle = FlatStyle.Flat;
            AddBtn.Font = new Font("Century Gothic", 20.25F);
            AddBtn.Location = new Point(280, 625);
            AddBtn.Name = "AddBtn";
            AddBtn.Size = new Size(320, 50);
            AddBtn.TabIndex = 13;
            AddBtn.Text = "Добавить перевод";
            AddBtn.UseVisualStyleBackColor = false;
            // 
            // AddTransfer
            // 
            AutoScaleMode = AutoScaleMode.None;
            BackColor = Color.White;
            Controls.Add(AddBtn);
            Controls.Add(comboBox2);
            Controls.Add(comboBox1);
            Controls.Add(dateTimePicker1);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(pictureBox1);
            Controls.Add(label1);
            Font = new Font("Century Gothic", 18F, FontStyle.Regular, GraphicsUnit.Point, 204);
            Name = "AddTransfer";
            Size = new Size(886, 744);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private TextBox textBox1;
        private TextBox textBox2;
        private DateTimePicker dateTimePicker1;
        private ComboBox comboBox1;
        private ComboBox comboBox2;
        private Button AddBtn;
    }
}
