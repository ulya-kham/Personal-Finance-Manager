﻿using System.ComponentModel;

namespace shershulya22
{
    public static class EnumHelper
    {
        public static string GetDescription(Enum value)
        {
            var field = value.GetType().GetField(value.ToString());
            var attr = (DescriptionAttribute)Attribute.GetCustomAttribute(field, typeof(DescriptionAttribute));
            return attr?.Description ?? value.ToString();
        }

        public static List<KeyValuePair<Enum, string>> GetEnumListWithDescription(Type enumType)
        {
            return Enum.GetValues(enumType)
                       .Cast<Enum>()
                       .Select(e => new KeyValuePair<Enum, string>(e, GetDescription(e)))
                       .ToList();
        }
    }
}
