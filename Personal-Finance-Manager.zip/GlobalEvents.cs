﻿using shershulya22.Controls;
using shershulya22.Models;

namespace shershulya22
{
    public static class GlobalEvents
    {
        public static event EventHandler<BalanceChangedEventArgs> OnBalanceChanged;
        public static event EventHandler OnNeedBalanceRecalculate;
        public static event EventHandler OnNameChanged;

        public static event EventHandler<TransactionShowEventArgs> OnTansactionControlNeedShow;
        public static event EventHandler OnMainControlNeedShow;
        public static event EventHandler OnAccountControlNeedShow;
        public static event EventHandler OnCategoryControlNeedShow;
        public static event EventHandler OnRecPaymentControlNeedShow;
        public static event EventHandler OnReminderControlNeedShow;

        #region PlusMinus
        public static event EventHandler OnMinusAddControlNeedShow;
        public static EventHandler GetMinusAddControlHandler() => OnMinusAddControlNeedShow;
        public static event EventHandler OnPlusAddControlNeedShow;
        public static EventHandler GetPlusAddControlHandler() => OnPlusAddControlNeedShow;
        #endregion
        #region Account
        public static event EventHandler OnHistoryControlNeedShow;
        public static EventHandler GetHostoryControlHandler() => OnHistoryControlNeedShow;
        public static event EventHandler OnTransferAddControlNeedShow;
        public static EventHandler GetTransferAddControlHandler() => OnTransferAddControlNeedShow;
        public static event EventHandler OnAccountAddControlNeedShow;
        public static EventHandler GetAccountAddControlHandler() => OnAccountAddControlNeedShow;

        public static event EventHandler<EventArgsWithGuid> OnAccountEditControlNeedShow;
        public static EventHandler<EventArgsWithGuid> GetAccountEditControlHandler() => OnAccountEditControlNeedShow;
        #endregion
        #region Category
        public static event EventHandler OnCategoryAddControlNeedShow;
        public static EventHandler GetCategoryAddControlHandler() => OnCategoryAddControlNeedShow;

        public static event EventHandler<EventArgsWithGuid> OnCategoryEditControlNeedShow;
        public static EventHandler<EventArgsWithGuid> GetCategoryEditControlHandler() => OnCategoryEditControlNeedShow;
        #endregion
        #region RecPayments
        public static event EventHandler OnRecPaymentAddControlNeedShow;
        public static EventHandler GetRecPaymentAddControlHandler() => OnRecPaymentAddControlNeedShow;

        public static event EventHandler<EventArgsWithGuid> OnRecPaymentEditControlNeedShow;
        public static EventHandler<EventArgsWithGuid> GetRecPaymentEditControlHandler() => OnRecPaymentEditControlNeedShow;
        #endregion
        #region Reminders
        public static event EventHandler OnReminderAddControlNeedShow;
        public static EventHandler GetReminderAddControlHandler() => OnReminderAddControlNeedShow;

        public static event EventHandler<EventArgsWithGuid> OnReminderEditControlNeedShow;
        public static EventHandler<EventArgsWithGuid> GetReminderEditControlHandler() => OnReminderEditControlNeedShow;
        #endregion

        public static void ShowMainControl(object sender, EventArgs args = null)
        {
            OnMainControlNeedShow?.Invoke(sender, args);
        }
        public static void ShowAccountControl(object sender, EventArgs args = null)
        {
            OnAccountControlNeedShow?.Invoke(sender, args);
        }
        public static void ShowCategoryControl(object sender, EventArgs args = null)
        {
            OnCategoryControlNeedShow?.Invoke(sender, args);
        }
        public static void ShowRecPaymentControl(object sender, EventArgs args = null)
        {
            OnRecPaymentControlNeedShow?.Invoke(sender, args);
        }
        public static void ShowReminderControl(object sender, EventArgs args = null)
        {
            OnReminderControlNeedShow?.Invoke(sender, args);
        }
        public static void ChangeBalance(object sender, Guid accountId, decimal balance)
        {
            OnBalanceChanged?.Invoke(sender, new BalanceChangedEventArgs(accountId, balance));
        }
        public static void RecalculateBalance(object sender, EventArgs args = null)
        {
            OnNeedBalanceRecalculate?.Invoke(sender, args);
        }
        public static void ChangeName(object sender, EventArgs args = null)
        {
            OnNameChanged?.Invoke(sender, args);
        }

        public static void ShowEditControl(object sender, Guid id, EventHandler<EventArgsWithGuid> handler)
        {
            handler?.Invoke(sender, new EventArgsWithGuid(id));
        }
        public static void ShowAddControl(object sender, EventHandler handler)
        {
            handler?.Invoke(sender, new EventArgs());
        }

        public static void ShowTransactionControl(object sender, CategoryType type, DatePeriod period, DateTime start, DateTime end, bool isPeriod)
        {
            OnTansactionControlNeedShow?.Invoke(sender, new TransactionShowEventArgs(type, period, start, end, isPeriod));
        }
    }

    public class EventArgsWithGuid
    {
        public Guid Id { get; private set; }
        public EventArgsWithGuid(Guid guid)
        {
              Id = guid;  
        }
    }
    public class BalanceChangedEventArgs
    {
        public Guid AccountId { get; private set; }
        public decimal Amount { get; private set; }
        public BalanceChangedEventArgs(Guid guid, decimal balance)
        {
            AccountId = guid;
            Amount = balance;
        }
    }
    public class TransactionShowEventArgs
    {
        public CategoryType Type { get; private set; }
        public DatePeriod Period { get; private set; }
        public DateTime Start { get; private set; }
        public DateTime End { get; private set; }
        public bool IsPeriod { get; private set; }
        public TransactionShowEventArgs(CategoryType type, DatePeriod period, DateTime start, DateTime end, bool isPeriod)
        {
            Type = type; 
            Period = period; 
            Start = start; 
            End = end; 
            IsPeriod = isPeriod;
        }
    }
}
